/**
  ******************************************************************************
  * �ļ�����: stm_flash.c 
  * ��    ��: ӲʯǶ��ʽ�����Ŷ�
  * ��    ��: V1.0
  * ��д����: 2015-10-04
  * ��    ��: �ڲ�Falsh��дʵ��
  ******************************************************************************
  * ˵����
  * ����������Ӳʯstm32������YS-F1Proʹ�á�
  * 
  * �Ա���
  * ��̳��http://www.ing10bbs.com
  * ��Ȩ��ӲʯǶ��ʽ�����Ŷ����У��������á�
  ******************************************************************************
  */
/* ����ͷ�ļ� ----------------------------------------------------------------*/
#include "wt-flash.h"
/**
  * @brief  Initializes Memory.
  * @param  None
  * @retval 0 if operation is successeful, MAL_FAIL else.
  */

flash_status_t Flash_If_Init(void)
{
  /* Unlock the internal flash */
  HAL_FLASH_Unlock();
  return FLASH_OK;
}


/**
  * @brief  Gets the page of a given address
  * @param  Addr: Address of the FLASH Memory
  * @retval The page of a given address
  */
static uint32_t GetPage(uint32_t Addr)
{
  uint32_t page = 0;
  if (Addr < (FLASH_BASE + FLASH_BANK_SIZE))
  {
    /* Bank 1 */
    page = (Addr - FLASH_BASE) / FLASH_PAGE_SIZE;
  }
  else
  {
   /* Bank 2 */
    page = (Addr - (FLASH_BASE + FLASH_BANK_SIZE)) / FLASH_PAGE_SIZE;
  }
  return page;
}

/**
  * @brief  Gets the bank of a given address
  * @param  Addr: Address of the FLASH Memory
  * @retval The bank of a given address
  */
static uint32_t GetBank(uint32_t Addr)
{
  uint32_t bank = 0;

  if (READ_BIT(SYSCFG->MEMRMP, SYSCFG_MEMRMP_FB_MODE) == 0)
  {
    /* No Bank swap */
    if (Addr < (FLASH_BASE + FLASH_BANK_SIZE))
    {
      bank = FLASH_BANK_1;
    }
    else
    {
      bank = FLASH_BANK_2;
    }
  }
  else
  {
    /* Bank swap */
    if (Addr < (FLASH_BASE + FLASH_BANK_SIZE))
    {
      bank = FLASH_BANK_2;
    }
    else
    {
      bank = FLASH_BANK_1;
    }
  }
  return bank;
}

/**
  * @brief  De-Initializes Memory.
  * @param  None
  * @retval 0 if operation is successeful, MAL_FAIL else.
  */
flash_status_t Flash_If_DeInit(void)
{
  /* Lock the internal flash */
  HAL_FLASH_Lock();
  return FLASH_OK;
}


/**
  * @brief  Erases pages.
  * @param  Add: Address of be erased.
  * @pages 	the number of pages
  * @retval 0 if operation is successeful, MAL_FAIL else.
  */
flash_status_t Flash_If_Erase_Pages(uint32_t Add, uint16_t pages)
{
  uint32_t PageError = 0;
	uint8_t tryCnt = 2;
  /* Variable contains Flash operation status */
  HAL_StatusTypeDef status;
  FLASH_EraseInitTypeDef eraseinitstruct;
  /* Clear OPTVERR bit set on virgin samples */
  __HAL_FLASH_CLEAR_FLAG(FLASH_FLAG_OPTVERR);
   /* Get the number of sector to erase from 1st sector*/
  eraseinitstruct.Banks = GetBank(Add);
  eraseinitstruct.TypeErase = FLASH_TYPEERASE_PAGES;
  eraseinitstruct.Page = GetPage(Add);
  eraseinitstruct.NbPages = pages;
	while( tryCnt > 0){
		status = HAL_FLASHEx_Erase(&eraseinitstruct, &PageError);
		if (status == HAL_OK)
			break;
		tryCnt--;
	}
		
  if (status != HAL_OK)
  {
    return FLASH_ERR;
  }
  return FLASH_OK;
}

/**
  * @brief  Erases sector.
  * @param  Add: Address of sector to be erased.
  * @retval 0 if operation is successeful, MAL_FAIL else.
  */
flash_status_t Flash_If_Erase(uint32_t Add, uint16_t pages)
{
  uint32_t PageError = 0;
	uint8_t tryCnt = 2;
  /* Variable contains Flash operation status */
  HAL_StatusTypeDef status;
  FLASH_EraseInitTypeDef eraseinitstruct;
  /* Clear OPTVERR bit set on virgin samples */
  __HAL_FLASH_CLEAR_FLAG(FLASH_FLAG_OPTVERR);
   /* Get the number of sector to erase from 1st sector*/
  eraseinitstruct.Banks = GetBank(Add);
  eraseinitstruct.TypeErase = FLASH_TYPEERASE_MASSERASE;
  eraseinitstruct.Page = GetPage(Add);
  eraseinitstruct.NbPages = 1;
	while( tryCnt > 0){
		status = HAL_FLASHEx_Erase(&eraseinitstruct, &PageError);
		if (status == HAL_OK)
			break;
		tryCnt--;
	}
		
	
	
  if (status != HAL_OK)
  {
    return FLASH_ERR;
  }
  return FLASH_OK;
}

/**
  * @brief  Writes Data into Memory.
  * @param  src: Pointer to the source buffer. Address to be written to.
  * @param  dest: Pointer to the destination buffer.
  * @param  Len: Number of data to be written (in bytes).
  * @retval 0 if operation is successeful, MAL_FAIL else.
  */

flash_status_t Flash_If_Write(uint8_t *src, uint8_t * dest_addr, uint32_t Len)
{
  uint32_t i = 0;
  /* Clear OPTVERR bit set on virgin samples */
  __HAL_FLASH_CLEAR_FLAG(FLASH_FLAG_OPTVERR);

  for(i = 0; i < Len; i += 8)
  {
    /* Device voltage range supposed to be [2.7V to 3.6V], the operation will
       be done by byte */
    if(HAL_FLASH_Program(FLASH_TYPEPROGRAM_DOUBLEWORD, (uint32_t)(dest_addr+i), *(uint64_t*)(src + i)) == HAL_OK)
    {
     /* Check the written value */
			//printf("0x%08x 0x%08x ==0x%08x 0x%08x\n", *(uint64_t *)(src + i), *(uint64_t*)(dest_addr+i));
      //if(*(uint64_t *)(src + i) != *(uint64_t*)(dest_addr+i))
      //{
        /* Flash content doesn't match SRAM content */
							//printf("NO MATCH\n");
        //return FLASH_CHECK_ERR;
      //}
    }
    else
    {
      /* Error occurred while writing data in Flash memory */
			//printf("Get ERROR: 0x%08x\n", (src + i));
      //return FLASH_ERR;
    }
  }
  return FLASH_OK;
}


/**
  * @brief  Reads Data into Memory.
  * @param  src: Pointer to the source buffer. Address to be written to.
  * @param  dest: Pointer to the destination buffer.
  * @param  Len: Number of data to be read (in bytes).
  * @retval return FLASH_OK.
  */
flash_status_t Flash_If_Read(uint8_t* buff, uint8_t* flash_addr, uint32_t Len)
{
    uint32_t i;
    for(i = 0; i < Len; i++){
            buff[i] = *(__IO uint8_t*)(flash_addr + i);
    }
  /* Return a valid address to avoid HardFault */
  return FLASH_OK;
}


/*****************************
* @brief	Write Data into specified address.
* @param	src: Pointer to the source buffer. Address to be written to.
* @param	start_addr: Pointer to the destination buffer.
* @param	Len: Number of data to be read (in bytes).
* @retval return FLASH_OK.
*/
//�˴���дֻдһ��page������
	void flash_write_pages(uint32_t addr, uint8_t* data, uint8_t len){
//		if(Flash_If_Erase_Pages(addr, 1) != FLASH_OK)
//		return;
//	dump_flash((uint8_t*)p32,  1024);
//	st = Flash_If_Write((uint8_t *)p32, (uint8_t*)FLASH_BASE + FLASH_SIZE/2, 0x2000);
//	printf("ST:%x\n", st);
//	dump_flash((uint8_t*)FLASH_BASE + FLASH_SIZE/2 - 0x20, 1024);
//	
//	st = Flash_If_Write((uint8_t *)p32, (uint8_t*)FLASH_BASE + FLASH_SIZE /2 + 0x3000, 0x2000);
//	printf("ST:%x\n", st);
//	dump_flash((uint8_t*)FLASH_BASE + FLASH_SIZE/2 - 0x20, 1024);
	
}


void dump_flash(uint8_t* pdata, uint32_t len)
{
	uint16_t i = 0;

	for(; i < len; i++)
	{
		if (i % 16 == 0)
			printf("\n[%08x]:", pdata+i);
		else
			if (i % 4 == 0)
				printf(" || ");
		printf(" %02x", pdata[i]);
		
	}
	printf("\n");
	return;
}

void flash_write_test(uint64_t* src, uint16_t len)
{
	uint16_t i = 0;
	uint32_t * p32 = (uint32_t *)src;
		flash_status_t st;
	for(; i < len; i++)
	{
		*(p32 + i) = (uint32_t)(p32 + i);
	}
	if(Flash_If_Erase(FLASH_BASE + FLASH_SIZE/2, 6) != FLASH_OK)
		return;
	dump_flash((uint8_t*)p32,  1024);
	st = Flash_If_Write((uint8_t *)p32, (uint8_t*)FLASH_BASE + FLASH_SIZE/2, 0x2000);
	printf("ST:%x\n", st);
	dump_flash((uint8_t*)FLASH_BASE + FLASH_SIZE/2 - 0x20, 1024);
	
	st = Flash_If_Write((uint8_t *)p32, (uint8_t*)FLASH_BASE + FLASH_SIZE /2 + 0x3000, 0x2000);
	printf("ST:%x\n", st);
	dump_flash((uint8_t*)FLASH_BASE + FLASH_SIZE/2 - 0x20, 1024);
	
	return;
}

void flash_erase_bank2(void)
{
		Flash_If_Init();
	if(Flash_If_Erase(FLASH_BASE + FLASH_SIZE/2, 6) != FLASH_OK)
	{
		printf("!!!!!!====FLASH ERASE ERROR!!!!=====!!!!!\n");
		HAL_Delay(1000);
	}
	
}

uint32_t flash_get_base(void)
{	
	uint32_t addr = FLASH_BASE + FLASH_SIZE/2;
	return addr;
}

void flash_test_loop(void)
{
	uint64_t* data[1024*8];
	Flash_If_Init();
	printf("FLASH_SIZE:0x%x\n", FLASH_SIZE);
	printf("FLASH_BASE:0x%x\n", FLASH_BASE);
	//Flash_If_Read((uint8_t*)data, (uint8_t*)FLASH_BASE,  1024);
	//dump_flash((uint8_t*)data, 1024);
	//printf("\n\n");
	
	//dump_flash((uint8_t*)FLASH_BASE + FLASH_SIZE/2 - 0x20, 1024);
	//HAL_Delay(100);
	flash_write_test((uint64_t*)data, 1024);
	Flash_If_DeInit();
	return;
} 
