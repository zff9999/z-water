
from gevent import monkey
monkey.patch_all()
import socket
import gevent
import time
import threading



class WT_HTTPServer(object):
    def __init__(self, port):
        server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        server_socket.bind(('', port))
        server_socket.listen(128)
        self.server_socket = server_socket

    def run_while(self):
        print('Server is running!!!')
        while True:
            new_socket, new_addr = self.server_socket.accept()
            gevent.spawn(self.deal_with_request, new_socket, new_addr)

    def dumpData(self, lstData):
        return

    def save_data_thread(self, filename, rawdata):
        print(str(int(time.time() * 1000)%100000),":Start   thread!!");
        save_th = threading.Thread(target=self.save_data_2_file, args=(filename, rawdata))
        save_th.start()
        print("save_th OVERRRRR");

    def save_data_2_file(self, filename, rawdata):
        datalen = len(rawdata);
        print("Write len " + str(datalen) + " to file " + filename) 
        with open('/home/aimlab01/wt-data/'+ filename ,'wb') as f:
            f.write(rawdata)
            f.close()
        print("[%s]: [%s]! Save Done" % (str(int(time.time() * 1001)%1000), filename))
    #check if data includes packet header
    #the header: time stamp, station ID, msg id and data size
    #before receive data, need to get the length of data
    def check_header(self, lstData):
        lenth = len(lstData)
        if lenth < 28 or lenth > 50:
            print("Invalide header data!!!!!")
            return "", 0
        # first need to change the bytes to string
        lst = []
        #bytes to int
        for itm in lstData:
            lst.append(chr(itm))
        print(lst)

        #check magic
        if( lst[0] == 'X' and lst[1] == 'X' and
                lst[2] == 'X' and lst[3] == 'X'):
            pass
        else:
            print("Not Header!!!")
            return "", 0
        
        pos = 4
        cnt = 12
        timeStp = "".join(lst[pos : pos + cnt])
        pos += cnt
        cnt = 4
        stID = "".join(lst[pos : pos + cnt])
        pos += cnt
        print("POS:", pos)
        length = ord(lst[pos])
        print(length)
        length += ord(lst[pos+1]) << 8
        print(length)
        length += ord(lst[pos+2]) << 16
        print(length)
        length += ord(lst[pos+3]) << 24
        print(length)
        pos += 4
        cnt = 2
        msgID = "".join(lst[pos : pos + cnt])
        pos += cnt
        cnt = 2
        
        fileName = timeStp + "-" + stID + "-" + msgID
        print(fileName, length)

        return fileName, length


    def check_request_end(self, client_socket):
        # Check and parser the request data!!!!
        recv_data = b''
        total=0
        rdheader = 1
        rcvSize = 28
        while True:
            recv_data_s = client_socket.recv(rcvSize)
            if rdheader == 1:
                print(recv_data_s[0:26])
                #lstData = recv_data_s.decode()
                lstData = recv_data_s
                print('Len:', len(lstData))
                self.dumpData(lstData[0:26])
                filename, datasize = self.check_header(lstData)
                if datasize != 0:
                    print("Will receive total: ", datasize);
                    rdheader = 0
                    recv_data = b''
                    total = 0
                    rcvSize = 2048

            else:
                lenth = len(recv_data_s)
                total += lenth
                print(".", end = ' ')
                #aGet:{} Total:{}".format(lenth, total))
                recv_data += recv_data_s
                if total >= datasize:
                    print("Save data!!!!")
                    #start to read pkg header!!!!
                    self.save_data_thread(filename, recv_data)
                    #self.save_data_3_file(filename, recv_data)
                    rdheader = 1


                    rcvSize = 28
                    datasize = 0

    def deal_with_request(self, client_socket, client_addr):
        print("Accept %s request!!!" % str(client_addr))
        content_entity = self.check_request_end(client_socket)
        tm_stmp = time.strftime("%H%M%S", time.localtime())
        with open('/home/aimlab01/wt-data/'+ tm_stmp ,'wb') as f:
             f.write(content_entity)
             f.close()
        print("CLOSE!!")
        client_socket.close()
        return	

def main():
    wt_server = WT_HTTPServer(8805)
    wt_server.run_while()


if __name__ == '__main__':
    main()
