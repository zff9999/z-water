# -*- coding: utf-8 -*-

"""
Spyder 编辑器

这是一个临时脚本文件。
"""
import os
import sys
import pickle
import struct
import numpy as np
import binascii
from pydub import AudioSegment
import time


def raw2wav (raw, wav):

    # .raw声音文件转.wav格式
    data1 = AudioSegment.from_file(raw, format='raw', 
                                   frame_rate=8192, channels=2, sample_width=2)
    print(data1.raw_data)

    sound = AudioSegment(
        data=data1.raw_data,        # 原始音频数据 (bytes类型)
        sample_width=2,              # 2 byte (16 bit)采样
        frame_rate=8192,
        channels=2)         # 立体声
    wavname11 = 'D:\working-dir\python-code\project\STN.wav1111'
    final = data1.export(wavname, format='wav')
    final2 = sound.export(wavname11, format='wav')
    
    #song = AudioSegment.from_wav("D:\working-dir\python-code\project\STN.raw", )
    
    #final = AudioSegment.from_file(filename, format='raw', frame_rate=8192, channels=1, sample_width=2).export(
    #    'result.wav', format='wav')
    #



def str_to_hexStr(string):
    str_bin = string.encode('utf-8')
    return binascii.hexlify(str_bin).decode('utf-8')


def str_to_hex(s):
    return ' '.join([hex(ord(c)).replace('0x', '') for c in s])

txtfile = "D:\working-dir\python-code\project\STN11.txt"
dstRaw="D:\working-dir\python-code\project\STN.bin"

def txt2bin(srcfile, binfile):

    fileOrg=open(srcfile, 'r')

    fileNew=open(binfile, 'wb')

    lines=fileOrg.readlines()

    for line in lines:
        #print(line)
        line.strip()
        line.replace('\r\n', "")
        curLine=line.split(' ')
        #print(curLine)
        for itm in curLine:
            if itm =='\n' or itm == '':
                continue
            #data = int(itm, 16)
            data = itm
            #print(itm, "===>", hex(data), "type:", type(data))
            a = struct.pack('B', itm)
            #np.array([data]).tofile(fileNew)
            fileNew.write(a)
 

    fileNew.close()

    fileOrg.close()
# end of rxr2bin
#####################################
import serial
import serial.tools.list_ports

class Communication():

    #初始化
    def __init__(self,com,bps,timeout):
        self.port = com
        self.bps = bps
        self.timeout = timeout
        self.connect = 0
        self.hexList = []
        self.rxThrd = 0x100000  #接收数据的长度限制
        self.tryCnt = 1000000  #接收数据的长度限制
        global Ret
        try:
            # 打开串口，并得到串口对象
             self.main_engine= serial.Serial(self.port,self.bps,timeout=self.timeout)
            # 判断是否打开成功
             if (self.main_engine.is_open):
               self.connect = True
        except Exception as e:
            print("---异常---：", e)

    # 打印设备基本信息
    def Print_Name(self):
        print(self.main_engine.name) #设备名字
        print(self.main_engine.port)#读或者写端口
        print(self.main_engine.baudrate)#波特率
        print(self.main_engine.bytesize)#字节大小
        print(self.main_engine.parity)#校验位
        print(self.main_engine.stopbits)#停止位
        print(self.main_engine.timeout)#读超时设置
        print(self.main_engine.writeTimeout)#写超时
        print(self.main_engine.xonxoff)#软件流控
        print(self.main_engine.rtscts)#软件流控
        print(self.main_engine.dsrdtr)#硬件流控
        print(self.main_engine.interCharTimeout)#字符间隔超时

    #打开串口
    def Open_Engine(self):
        self.main_engine.open()

    #关闭串口
    def Close_Engine(self):
        self.main_engine.close()
        print(self.main_engine.is_open)  # 检验串口是否打开
        return

    # 打印可用串口列表
    @staticmethod
    def Print_Used_Com():
        port_list = list(serial.tools.list_ports.comports())
        print(port_list)





    #接收指定大小的数据
    #从串口读size个字节。如果指定超时，则可能在超时后返回较少的字节；如果没有指定超时，则会一直等到收完指定的字节数。
    def Read_Size(self,size):
        return self.main_engine.read(size=size)

    #接收一行数据
    # 使用readline()时应该注意：打开串口时应该指定超时，否则如果串口没有收到新行，则会一直等待。
    # 如果没有超时，readline会报异常。
    def Read_Line(self):
        return self.main_engine.readline()

    #发数据
    def Send_data(self,data):
        self.main_engine.write(data)

    #更多示例
    # self.main_engine.write(chr(0x06).encode("utf-8"))  # 十六制发送一个数据
    # print(self.main_engine.read().hex())  #  # 十六进制的读取读一个字节
    # print(self.main_engine.read())#读一个字节
    # print(self.main_engine.read(10).decode("gbk"))#读十个字节
    # print(self.main_engine.readline().decode("gbk"))#读一行
    # print(self.main_engine.readlines())#读取多行，返回列表，必须匹配超时（timeout)使用
    # print(self.main_engine.in_waiting)#获取输入缓冲区的剩余字节数
    # print(self.main_engine.out_waiting)#获取输出缓冲区的字节数
    # print(self.main_engine.readall())#读取全部字符。

    #接收数据
    #一个整型数据占两个字节
    #一个字符占一个字节

    def Recive_data(self, way = 1, cbkfunc = None):
        # 循环接收数据，此为死循环，可用线程实现
        print("开始接收数据：", way)
        dataCnt = 0
        datalist = []
        tryCnt = 0
        while True:
            tryCnt = tryCnt + 1
            if(tryCnt > self.tryCnt):
                #print("Try count !!!!!!")
                print(time.strftime("%Y-%m-%d-%H%M%S", time.localtime()))
                if(cbkfunc == None):
                    return
                tryCnt = 0
                if(len(self.hexList) != 0):
                    cbkfunc(self.hexList)
                self.hexList.clear()
                tryCnt = 0
                dataCnt = 0
                
            try:
                # 一个字节一个字节的接收
                if self.main_engine.in_waiting:
                    tryCnt = 0
                    if(way == 0):

                        for i in range(self.main_engine.in_waiting):
                            #print("接收ascii数据："+str(self.Read_Size(1)))
                            #为加快处理速度，不做数据处理，直接放到列表中保存
                            data1 = self.Read_Size(1)
                            self.hexList.append(data1)                          
                            #print("[{}] ".format(data1.hex()), end='')
                            #data2 = int(data1,16)#转为十进制
                            #print("收到数据十六进制："+data1+"  收到数据十进制："+str(data2))

                            dataCnt = dataCnt + 1
                            if (dataCnt >= 0x800000):
                                print("\nOver!\n", self.hexList)
                                return                           
                        print("\nGet 0x%x DATA" % (dataCnt))
                        

                    if(way == 1):
                        #整体接收
                        # data = self.main_engine.read(self.main_engine.in_waiting).decode("utf-8")#方式一
                        data = self.main_engine.read_all()
                        #方式二
                        print("接收ascii数据：", data)
                        #if()
            except Exception as e:
                print("异常报错：",e)

def comm_main(port, bdrt):
    Communication.Print_Used_Com()
    Ret =False #是否创建成功标志
    Engine1 = Communication("com6",115200,0.5)
    if (Engine1.connect == True):
        Engine1.Recive_data(0)
        Engine1.Close_Engine()
        if len(Engine1.hexList) > 0:
            DumpDataList(Engine1.hexList)
            genAudioFromRaw(Engine1.hexList)
            print("OK!!!")
            

    print("=======>OVER")




def DumpDataList(listDt, length):
    dataCnt = 0
    for data1 in listDt:
        if (dataCnt % 16 == 0):
            print("\n[0x%08x] " % dataCnt, end='')
        elif (dataCnt % 4 == 0):
            print("|| ", end='')
        
        print("[{}] ".format(data1.hex()), end='')
        
        dataCnt = dataCnt+1
        if (dataCnt > length):
            break
    print("")
        

def save2bin(lstData):
    fname = "D:\working-dir\python-code\project\STN.111"
    f = open(fname,'wb')
    ss = b''
    #print(type(lstData[0]))
    #lstData = [239, 255, 0, 0, 238, 255, 0, 0, 237, 255, 0, 0, 235, 255, 0, 0, 239, 255, 0, 0, 239, 255, 0, 0, 238, 255, 0, 0, 240, 255, 0, 0, 238, 255]
    for itm in lstData:
        #data = int(itm, 16)
        data = itm
        print(data)
        a = struct.pack('B', data)
        ss = ss + a
        print(a,"====",ss)
        #np.array([data]).tofile(fileNew)
        f.write(a)
    f.close()

def genAudioFromRaw(rawlist, datasize = 2, frmrate = 8192, chnls=2):
    tm_stmp = time.strftime("%Y-%m-%d-%H%M%S", time.localtime())
    dirname = os.getcwd() + "\\"
    outraw = dirname + tm_stmp+".raw"
    outwav = dirname + tm_stmp+".wav"
    outtxt = dirname + tm_stmp+".txt"

    print("datasize = %d, frmrate = %d, chnls=%d" %(datasize , frmrate, chnls))
    totallen = (len(rawlist) // (int(datasize) * int(chnls))) * (int(datasize) * int(chnls))
    print("Get a total eln:%d[0x%x] data!!!" % (totallen, totallen))
    ss = b''
    hexlst = []
    #转化成bytes流，好像也可以使用bytes(list_nums)来强制转化
    print("Type:", type(rawlist[3]))
    for itm in rawlist[:totallen]:
        #data0 = int(itm.hex(), 16)
        #a0 = struct.pack('B', data0)
        ss = ss + itm
        hexlst.append(itm.hex())
    #print(ss)
    #生成音频数据对象
    sound = AudioSegment(
        data=ss,                    # 原始音频数据 (bytes类型)
        sample_width=datasize,    # 2 byte (16 bit)采样
        frame_rate=frmrate,       # 帧速率
        channels=chnls)        # 立体声
    #输出文件
    final = sound.export(outwav, format='wav')
    #输出RAW
    final = sound.export(outraw, format='raw')
    
    txtf = open(outtxt, "w") #以原先的文件名称并且加上.bin后缀后打开文件
    txtf.writelines(str(hexlst)) #写byte数组写入到二进制文件中
    txtf.close()
    
    print("Created \n%s\n%s\n%s\n" % (outraw, outwav, outtxt))
    return

def Handle_Comm_Data(datalst):
    dataLen = len(datalst)
    if dataLen <= 0:
        return
    print("Get total:0x%x ", dataLen)
    #显示部分数据
    DumpDataList(datalst, 0x1000)
    #开始转换数据，存放到raw和wav文件中
    genAudioFromRaw(datalst)
    return

def capture_raw_2_wav():
    Communication.Print_Used_Com()
    #Ret = False #是否创建成功标志
    #初始化com口
    Engine1 = Communication("com6",115200,0.5)
    #判断链接建立
    if (Engine1.connect == False):
        return
    #单字节接收 way = 0
    Engine1.Recive_data(0)
    #接收结束
    Engine1.Close_Engine()
    
    #判断接收到的数据
    dataLen = len(Engine1.hexList)
    if dataLen <= 0:
        return
    print("Get total:0x%x ", dataLen)
    #显示部分数据
    DumpDataList(Engine1.hexList, 0x1000)
    #开始转换数据，存放到raw和wav文件中
    genAudioFromRaw(Engine1.hexList)
    
    print("OK!!!")
    print("=======>OVER")
    
#####################################
'''
rawname = 'D:\working-dir\python-code\project\\2020-05-24-2300.raw'
wavname = 'D:\working-dir\python-code\project\\2020-05-24-2300.wav'
dirname = 'D:\working-dir\python-code\project\\'
tm_stmp = time.strftime("%Y-%m-%d-%H%M%S", time.localtime())
outraw = dirname + tm_stmp+".raw"
outwav = dirname + tm_stmp+".wav"
outtxt = dirname + tm_stmp+".txt"
rawlist= ['FA','FB','FA','FB','FA','FB','FA','FB','FA','FB','FA','FB','FA','FB']
txtf = open(outtxt, "w") #以原先的文件名称并且加上.bin后缀后打开文件
txtf.writelines(rawlist) #写byte数组写入到二进制文件中
txtf.close()

'''

def ParserHeader(dataOrg):
    print(dataOrg)
    data = dataOrg.decode()
    print(data)
    headerLen = len(data)
    if headerLen <= 16:
        return "", 0
    timeStp = data[0:6]
    stID = data[6:10]
    msgID = data[10:12]
    
    length = data[12:16]
    
    fileName = timeStp + "-" + stID + "-" + msgID
    print(fileName)
    print(int(length))
    return fileName, length


if __name__ == '__main__':
    print("Start_RUN")
    ParserHeader(b'201001ST010112A4')
    #save2bin(None)
    #capture_raw_2_wav()
    #txt2bin(txtfile, dstRaw)

    #raw2wav(rawname, wavname)