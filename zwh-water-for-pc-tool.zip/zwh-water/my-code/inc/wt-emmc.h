/**
  ******************************************************************************
  * File Name          : wt-emmc.h
  * Description        : This file provides code for the configuration
  *                      of the emmc instances.
  ******************************************************************************
  *
  ******************************************************************************
  */
/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __WT_EMMC_H
#define __WT_EMMC_H
#ifdef __cplusplus
 extern "C" {
#endif
#include "wt-common.h"

#define BLOCK_SIZE            512         // SD�����С     

#define NUMBER_OF_BLOCKS      1           // ���Կ�����(С��15)

#define WRITE_READ_ADDRESS    0x00002000  // ���Զ�д��ַ

 typedef enum {FAILED = 0, PASSED = !FAILED} TestStatus;

/* ˽�б��� ------------------------------------------------------------------*/

HAL_StatusTypeDef MMC_Test(uint32_t);
HAL_StatusTypeDef MMC_Erase_Test(uint32_t address, uint32_t blocks);
HAL_StatusTypeDef MMC_Read_Test(uint32_t address, uint32_t blocks);
HAL_StatusTypeDef MMC_Write_Test(uint32_t address, uint32_t blocks);
#endif
