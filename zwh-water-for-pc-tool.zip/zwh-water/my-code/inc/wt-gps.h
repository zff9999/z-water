/**
  ******************************************************************************
  * File Name          : wt-gps.h
  * Description        : This header file provides code for gps
  ******************************************************************************
  *
  ******************************************************************************
  */
/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __WT_GPS_H
#define __WT_GPS_H
#ifdef __cplusplus
 extern "C" {
#endif
#include <string.h>
#include <stdio.h>

#include "wt-common.h"
#include "main.h"
#include "usart.h"
#define RXBUFF_LEN 1024
typedef struct
{
	uint8_t PositionOk;
	char     NS;				/* γ�Ȱ���N�������򣩻�S���ϰ��� */
	uint16_t WeiDu_Du;			/* γ�ȣ��� */
	uint32_t WeiDu_Fen;			/* γ�ȣ���. 232475��  С�����4λ, ��ʾ 23.2475 �� */
	
	uint8_t	 dmy;
	char     EW;				/* ���Ȱ���E����������W�������� */
	uint16_t JingDu_Du;			/* ���ȣ���λ�� */
	uint32_t JingDu_Fen;		/* ���ȣ���λ�� */

	uint16_t Year;				/* ���� 120598 ddmmyy */
	uint8_t  Month;
	uint8_t  Day;
	uint8_t  Hour;				/* UTC ʱ�䡣 hhmmss.sss */
	uint8_t  Min;				/* �� */
	uint16_t  Sec;				/* �� */
	uint16_t mSec;				/* ���� */		
	
}GPS;

typedef struct
{
	uint16_t Year_Local;				/* ���� 120598 ddmmyy */
	uint8_t  Month_Local;
	uint8_t  Day_Local;
	uint8_t  Hour_Local;				/* UTC ʱ�䡣 hhmmss.sss */
}GPS_Local;

typedef struct
{
	uint16_t syear;
	uint8_t smonth;
	uint8_t sday;
	uint8_t shour;
	uint8_t smin;
	uint8_t ssec;
}GPS_RTC;

extern GPS myGPS;
//extern GPS myGPS_Local;

//extern GPS myGPS_Local;
extern GPS_RTC myRTC;

uint8_t itoa(uint8_t i);
uint8_t wt_gen_gps_cmd(uint8_t *data);
uint8_t WT_GPS_Rec(void);
void GPS_Send_Cmd(char *cmd);

uint8_t WT_Passion_PMTK_Init(void);
uint8_t WT_GPS_PMTK_Init(void);
uint8_t WT_PPS_PMTK_Init(void);
//void WT_GPS_PMTKInit(void);
void WT_GPS_PMTK_Warm_Start(void);
void GPS_Data_Test(void);

void GPS_Parser_GNRMC(void);
int32_t StrToIntFix1(char *_pStr, uint8_t _ucLen);
uint32_t gps_FenToDu(uint32_t _fen);
uint16_t gps_FenToMiao(uint32_t _fen);
void UTCDate(void);
void DispGPSStatus(void);
void rtc_test(void);
void rtc_update(void);
void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin);
void WT_GPS_Init(void);
#endif

