/**
  ******************************************************************************
  * File Name          : wt-lte.h
  * Description        : This header file provides code for lte
  ******************************************************************************
  */
/* Define to prevent recursive inclusion -------------------------------------*/

#ifndef __WT_LTE_H
#define __WT_LTE_H
#ifdef __cplusplus
 extern "C" {
#endif
#include <string.h>
#include <stdio.h>

#include "wt-common.h"
#include "main.h"
#include "usart.h"

//�洢���������ص�����
extern char AtRxBuffer[RXBUFF_LEN];  
//LTE��ʼ����־��1 ��ʾ������0 ��ʾ��ʼ�����ɹ�
extern int8_t status; 
//�ر����ӣ�1����ʾ�����ر� ��0����ʾ�����ж�
extern uint8_t qiclosed; 

//extern uint8_t uartcmd[1024]; //��������
extern uint8_t g_lte_status;
extern uint32_t lte_datalen;
//from wt-common.c
extern WT_Header header;

int wt_lte_handle(void);
int wt_lte_test(void);
int wt_lte_sleep(uint8_t flag);
void WT_LTE_Init(void);

int wt_lte_at(void);
int wt_lte_sim(void);
int wt_lte_connectser_http(void);
int wt_lte_connectser_tcp(void);
int wt_lte_close(void);
void lte_uart_cmd(uint8_t *cmd);

void LTE_GPIO_Init(void);
void LTE_Power_Pulse(void);
void LTE_Reset(void);

void get_csq(char *data);
void wt_lte_tcp_test(void);
void Uart1_Rec(UART_HandleTypeDef *huart);
void LTE_Set_Conn_Type(uint8_t conntype);
int wt_lte_connect(void);
//int LTE_Send_Data(uint8_t *data ,uint32_t len);
int LTE_Send_Data(uint8_t *data ,uint32_t len);

void LTE_Send_Cmd(char *cmd);
void LTE_Rec_Data(void);
void LTE_Send_Data_Http(uint8_t *data ,uint32_t len);
int LTE_Send_Data_Tcp(uint8_t *data ,uint32_t len);

//extern void Set_Pkt_Header(char * timestr, uint8_t MsgID, uint32_t data_Size);
#endif
