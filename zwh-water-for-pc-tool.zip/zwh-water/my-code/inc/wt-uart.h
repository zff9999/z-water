/**
  ******************************************************************************
  * File Name          : wt-uart.h
  * Description        : This file provides code for the configuration
  *                      of the USART instances.
  ******************************************************************************
  *
  ******************************************************************************
  */
/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __WT_UART_H
#define __WT_UART_H
#ifdef __cplusplus
 extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
//#include "stm32f4xx_hal.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>

#include "wt-common.h"
#include "main.h"

//���ﶨ����ĿҪʹ�õĴ���
#ifdef WT_LTE
#define WATER_UART1		//LTE
//������ڽ���LTEģ�鷢�͹��������� ����wt_LTE.c
extern char AtRxBuffer[RXBUFF_LEN];
#endif
//#define WATER_UART2		//
//#define WATER_UART3
#define WATER_UART4		//DEBUG PORT
extern uint8_t aUart4Buffer[100];	//yart4�Ľ�������
#ifdef WT_GPS_1PPS
#define WATER_LPUART1	//1PPS GPS
#endif
////////////////////////////////////////////////
//the length of buffer for RX/TX
#define BUF_LEN	1024

//#define RECEIVELEN 1024
#define UART_DMA_TX_BUSY 1	//����δ���
#define UART_DMA_TX_DONE 0	//�������
typedef struct{
	uint8_t rx_flag:1;		//���н��ձ��
	uint8_t tx_flag:1;		//������ɱ��
	uint16_t rx_len;			//���ճ���
	uint16_t tx_len;

	uint8_t rx_buf[BUF_LEN];	//���ջ���
	uint8_t tx_buf[BUF_LEN];	//���ͻ���
	uint8_t rx_dma_buf[BUF_LEN];//DMA���ջ���
	uint8_t tx_dma_buf[BUF_LEN];
	UART_HandleTypeDef * huart;
	DMA_HandleTypeDef *hdma_uart_rx;
	DMA_HandleTypeDef *hdma_uart_tx;
}MT_UART_dma_st; 


//#define WT_DEBUG(fmt,args...) 
//Initial uart: enable RCV DMA and IDLE int
void WT_UART_DMA_Init(UART_HandleTypeDef *huart);
//handler for RCV IDLE interrupt, save data received to rx_buffer
void WT_USART_Receive_IDLE(UART_HandleTypeDef *huart);
//process receive data and clear the rx_buff
void WT_Handle_Received_Data(UART_HandleTypeDef *huart);
void WT_DMA_Uart_Send(UART_HandleTypeDef *huart, uint8_t *, uint8_t);
void WT_Handle_DMA_TX(void);
void WT_Handle_UART_IDLE(UART_HandleTypeDef *huart);
void WT_Uart_MainLoop_Test(void);
void WT_Enable_Uart_Receive_DMA(UART_HandleTypeDef *huart);
void WT_Init_Uarts_DMA_Port(void);
MT_UART_dma_st * WT_Get_Uart_DMA_Port(UART_HandleTypeDef *huart);
uint8_t Check_Uart_Send_Done11(UART_HandleTypeDef * huart);
//////////////////////////////////////////////////////////
//DEBUG PORT (UART4) FUNCTION
void Handle_Debug_Port_Data(void);
void WT_Debug_Port_Start_Rcv(void);
void WT_Debug_Port_Send(uint8_t * tx_buf, uint32_t len);
void WT_Debug_Port_RxCpltCallback(void);
void WT_Debug_Port_Handle_Data(void);
//////////////////////////////////////////////////////////
void lte_loop_test(char * cmd);
uint8_t gen_gps_cmd(uint8_t *data);

enum RX_FLAG { RX_DOING, RX_DONE };
enum TX_FLAG { TX_DOING, TX_DONE };
enum DBG_CMD_TYPE { NOCMD, AT_CMD, GPS_CMD, I2C_CMD, ADC_CMD, 
					EMMC_CMD, WT_CMD, PCM_CMD, I2S_CMD, CMD_END};

////////////////////////////////////////////////
// UART2 for EC20
#define EC20_USART2_TXBUF_LEN 1536
#define EC20_USART2_RXBUF_LEN  1024 //256 

////////////////////////////////////////////////////////
//// UART2 for EC20

void ec20_init_uart(void);
void lte_loop_test(char *);
void l70_loop_test(void);
void ec20_usart2_init(uint32_t bound); 
void ec20_USART2_sendstr(char *data);
void ec20_clear_buf_uart2(void);
void ec20_USART2_senddata(char *data,int len);
//void ec20_UART2_SendChar(char ch);
//void ec20_USART2_SendChar(char ch);
void DGB_printf(const char *fmt, ...);
void lpuart_send(uint8_t *data);

#endif
