#ifndef __DELAY_H
#define __DELAY_H 			   
#include <stdint.h>	  
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;

void delay_init(uint8_t SYSCLK);
void delay_ms(uint16_t nms);
void delay_us(uint32_t nus);

#endif

