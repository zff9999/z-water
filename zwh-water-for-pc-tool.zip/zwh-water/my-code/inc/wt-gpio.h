/**
  ******************************************************************************
  * @file    wt-gpio.h
  * @author  xxxxxx Team
  * @brief   WATER gpio functions
  *
  *          The file is the unique include file that the application programmer
  *          is using in the C source code, usually in main.c. This file contains:

  *
  ******************************************************************************/
  
  
#ifndef __WT_GPIO_H
#define __WT_GPIO_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/

#include "main.h"

#include "wt-common.h"

//1PPS GPS(L76) pins
//#define GPS_POWER_Pin GPIO_PIN_8
//#define GPS_POWER_GPIO_Port GPIOD
//#define GPS_RESET_Pin GPIO_PIN_8
//#define GPS_RESET_GPIO_Port GPIOA
//#define GPS_PPS_Pin GPIO_PIN_15
//#define GPS_PPS_GPIO_Port GPIOA

//#define GPS_POWER_PD8_Pin GPIO_PIN_8
//#define GPS_POWER_PD8_GPIO_Port GPIOD
//#define GPS_RESET_PA8_Pin GPIO_PIN_8
//#define GPS_RESET_PA8_GPIO_Port GPIOA
//#define GPS_PPS_PA15_Pin GPIO_PIN_15
//#define GPS_PPS_PA15_GPIO_Port GPIOA



// LTE GPIO pins
#define LTE_POWER_PE15_Pin 		GPIO_PIN_15
#define LTE_POWER_GPIO_Port 	GPIOE
#define LTE_RESET_PB13_Pin 		GPIO_PIN_13
#define LTE_RESET_GPIO_Port 	GPIOB

#define LTE_RI_PC2_Pin 			GPIO_PIN_2
#define LTE_RI_PC2_GPIO_Port 	GPIOC
#define LTE_W_DISABLE_PE13_Pin 	GPIO_PIN_13
#define LTE_W_DISABLE_PE13_GPIO_Port GPIOE
#define LTE_MCU_WAKE_PE14_Pin 	GPIO_PIN_14
#define LTE_MCU_WAKE_PE14_GPIO_Port GPIOE
#define LTE_PWR_KEY_PE15_Pin 	GPIO_PIN_15
#define LTE_PWR_KEY_PE15_GPIO_Port 	GPIOE
#define LTE_DCD_PB15_Pin 		GPIO_PIN_15
#define LTE_DCD_PB15_GPIO_Port 		GPIOB
#define LTE_DTR_PC13_Pin 		GPIO_PIN_13
#define LTE_DTR_PC13_GPIO_Port 	GPIOC
#define LTE_RESET_PB13_Pin 		GPIO_PIN_13
#define LTE_RESET_PB13_GPIO_Port 	GPIOB
/////////////////////FM GPIO//////////////////////
#define FM_RESET_PD7_Pin 				GPIO_PIN_7
#define FM_RESET_PD7_GPIO_Port 	GPIOD
#define FM_MCO_PA8_Pin 					GPIO_PIN_8
#define FM_MCO_PA8_GPIO_Port 		GPIOA
////////////////////////////////////////////

/////TEMP and HUM SENSOR GPIO///////////////
// POWER HIGH ENABLE
#define TH_POWER_PE1_Pin 				GPIO_PIN_1
#define TH_POWER_PE1_GPIO_Port 	GPIOE
#define TH_INT_PD13_Pin 				GPIO_PIN_13
#define TH_INT_PD13_GPIO_Port 	GPIOD


///////////////////////////////////////////
//HYDRO  GPIO
#define HYD_POWER_EN_PE0_Pin				GPIO_PIN_0
#define HYD_POWER_EN_PE0_GPIO_Port 	GPIOE
#define HYD_POWER_ST_PB5_Pin 				GPIO_PIN_5
#define HYD_POWER_ST_PB5_GPIO_Port 	GPIOB
////////////////////////////////////////////

#define USB_PWR_EN_PB12_Pin 		GPIO_PIN_12
#define USB_PWR_EN_PB12_GPIO_Port 	GPIOB

//#define EMERGEOFF_RESET_PB13_Pin GPIO_PIN_13
//#define EMERGEOFF_RESET_PB13_GPIO_Port GPIOB

#define EMMC_RESET_PD15_Pin 		GPIO_PIN_15
#define EMMC_RESET_PD15_GPIO_Port 	GPIOD

#define POWER_ON 	GPIO_PIN_SET
#define POWER_OFF 	GPIO_PIN_RESET

#define SENSOR2_POWER_PE1_Pin 				GPIO_PIN_1
#define SENSOR2_POWER_PE1_GPIO_Port		GPIOE

#define SENSOR1_POWER_PE12_Pin 				GPIO_PIN_12
#define SENSOR1_POWER_PE12_GPIO_Port	GPIOE

#define PRESSURE_POWER_PD12_Pin 				GPIO_PIN_12
#define PRESSURE_POWER_PD12_GPIO_Port	GPIOD

void GPS_Reset(void);
void GPS_GPIO_Init(void);
void GPS_Power_down(void);

void LTE_Power_on(void);
void LTE_Reset(void);
void WT_GPIO_Init(void);

#endif
