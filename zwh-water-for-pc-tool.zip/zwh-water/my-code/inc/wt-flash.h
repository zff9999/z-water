#ifndef __STMFLASH_H__
#define __STMFLASH_H__

/* ����ͷ�ļ� ----------------------------------------------------------------*/
#include "stm32l4xx_hal.h"

/* ���Ͷ��� ------------------------------------------------------------------*/
/* �궨�� --------------------------------------------------------------------*/
typedef enum
{
	FLASH_OK,
	FLASH_ERR,
	FLASH_CHECK_ERR
}flash_status_t;

flash_status_t Flash_If_Init(void);
flash_status_t Flash_If_DeInit(void);
flash_status_t Flash_If_Erase(uint32_t Add, uint16_t pages);
flash_status_t Flash_If_Write(uint8_t *src, uint8_t * dest_addr, uint32_t Len);
flash_status_t Flash_If_Read(uint8_t* buff, uint8_t * dest_addr, uint32_t Len);
uint32_t flash_get_base(void);
void flash_erase_bank2(void);
flash_status_t Flash_If_Erase_Pages(uint32_t Add, uint16_t pages);

#endif /* __STMFLASH_H__ */

