/**
  ******************************************************************************
  * File Name          : wt-fm.h
  * Description        : This header file provides code for fm
  ******************************************************************************
  */
/* Define to prevent recursive inclusion -------------------------------------*/

#ifndef __WT_FM_H
#define __WT_FM_H
#ifdef __cplusplus
 extern "C" {
#endif
#include <string.h>
#include <stdio.h>

#include "wt-common.h"
#include "i2c.h"
#include "gpio.h"

void tune_test(void);
void uart_cmd(uint8_t *cmd);
void WT_FM_Init(void);
void fm_encrystal(void);
void fm_powerup(void);
void fm_powerdown(void);
int8_t fm_seek(uint16_t chan_seeked[]);
uint8_t freq_chan(uint16_t freq);
int8_t fm_tune(uint16_t freq);
//void fm_tune(uint16_t freq);
void fm_set_volume(uint8_t volume);
void fm_set_mono(uint8_t mono);
uint8_t fm_is_mono(void);
void Dump_Fm_Regs(uint8_t *addr);
void FM_GPIO_Init(void);
uint8_t fm_mfg_test(void);
void FM_Reset(void);
void FM_Power_down(void);
uint16_t fm_reg_write(uint8_t *data,  uint16_t size);
uint16_t fm_reg_read(uint8_t *data,  uint16_t size);

#endif
