/**
  ******************************************************************************
  * File Name          : wt-uart.c
  * Description        : This file provides code for the configuration
  *                      of the USART instances.
  ******************************************************************************
  WT_Init_Uarts_DMA_Port  ==> put main()
  WT_UART_DMA_Init()  ==> to enable DMA IDLE should be call after uart init
  WT_Uart_MainLoop_Test();	  ===> deal with rx data ==> put main loop
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "wt-uart.h"
#include "usart.h"

/*
//the flag for receive a total data(with the end:0xa0xd)
uint8_t usart_rx_flag = RX_DOING;			//1:get /r/n chars ; 0:not get /r/n

uint8_t uart_dma_port->rx_buf[BUF_LEN];
uint8_t usart_rx_len = 0;
uint8_t usart_tx_buffer[BUF_LEN];
uint8_t usart_rx_dma_buf[BUF_LEN];
uint8_t usart_tx_dma_buf[BUF_LEN];

uint16_t usart_tx_len = 0;
uint16_t usart_DMA_RxSize = 0;
uint16_t usart_tx_status = 0;	//0: txing 1: Tx Complete

*/

#define WATER_UART2
#define WATER_UART3

uint8_t  EC20_USART2_TxBuf[EC20_USART2_TXBUF_LEN];
uint16_t USART2_TxHead = 0;
uint16_t USART2_TxTail = 0;
uint8_t  EC20_USART2_RxBuf[EC20_USART2_RXBUF_LEN];
uint16_t USART2_RxHead = 0;
uint16_t USART2_RxTail = 0;

uint8_t WT_Check_Debug_CMD_Type(char *buff);
void WT_Debug_Port_Get_Data(void);
/* USER CODE BEGIN Private defines */

#ifdef WATER_UART1
MT_UART_dma_st UART1_DMA;
extern UART_HandleTypeDef huart1;
extern DMA_HandleTypeDef hdma_usart1_rx;
extern DMA_HandleTypeDef hdma_usart1_tx;
/***********
uint8_t uart1_rx_buf[BUF_LEN];	//���ջ���
uint8_t uart1_tx_buf[BUF_LEN];	//���ͻ���
uint8_t uart1_rx_dma_buf[BUF_LEN];//DMA���ջ���
uint8_t uart1_tx_dma_buf[BUF_LEN];
************/
#endif

#ifdef WATER_UART2
//_485
MT_UART_dma_st UART2_DMA;
extern UART_HandleTypeDef huart2;
extern DMA_HandleTypeDef hdma_usart2_rx;
//extern DMA_HandleTypeDef hdma_usart2_tx;
#endif

#ifdef WATER_UART3
//_485
MT_UART_dma_st UART3_DMA;
extern UART_HandleTypeDef huart3;
extern DMA_HandleTypeDef hdma_usart3_rx;
//extern DMA_HandleTypeDef hdma_usart3_tx;
#endif


#ifdef WATER_UART4
MT_UART_dma_st UART4_DMA;
extern UART_HandleTypeDef huart4;
//extern DMA_HandleTypeDef hdma_uart4_rx;
extern DMA_HandleTypeDef hdma_uart4_tx;
//uint8_t uartcmd[100];
#endif

#ifdef WATER_LPUART1
MT_UART_dma_st LPUART1_DMA;
extern UART_HandleTypeDef hlpuart1;
extern DMA_HandleTypeDef hdma_lpuart_rx;
extern DMA_HandleTypeDef hdma_lpuart_tx;
#endif
/********
*
*/
extern void MX_USART2_485_UART_Init(void);
/* initialize self-port structure
*	��ʹ��DMA�Ľ��գ�����ʹ��uart4���Դ��ڵĽ����ж�
*/
void WT_Init_Uarts_DMA_Port(void)
{
	// for uart1 LTE
#ifdef WATER_UART1
	MX_USART1_UART_Init();
	UART1_DMA.huart = &huart1;
	UART1_DMA.hdma_uart_rx = &hdma_usart1_rx;
	UART1_DMA.hdma_uart_tx = &hdma_usart1_tx;
	WT_Enable_Uart_Receive_DMA(&huart1);
#endif
	
#ifdef WATER_UART21
	MX_USART2_485_UART_Init();
	UART2_DMA.huart = &huart2;
	UART2_DMA.hdma_uart_rx = &hdma_usart2_rx;
	//UART2_DMA.hdma_uart_tx = &hdma_usart2_tx;
	//WT_Enable_Uart_Receive_DMA(&huart2);
#endif
	
#ifdef WATER_UART31
	MX_USART3_485_UART_Init();
	UART3_DMA.huart = &huart3;
	UART3_DMA.hdma_uart_rx = &hdma_usart3_rx;
	//UART3_DMA.hdma_uart_tx = &hdma_usart3_tx;
	//WT_Enable_Uart_Receive_DMA(&huart3);
#endif

#ifdef WATER_UART4
	MX_UART4_Init();
	UART4_DMA.huart = &huart4;
	UART4_DMA.hdma_uart_tx = &hdma_uart4_tx;
	//uart4 rx use IT Not DMA
	//WT_Enable_Uart_Receive_DMA(&huart4);
	//enable rx IT
	WT_Debug_Port_Start_Rcv();
#endif

#ifdef WATER_LPUART1
	MX_LPUART1_UART_Init();
	LPUART1_DMA.huart = &hlpuart1;
	LPUART1_DMA.hdma_uart_rx = &hdma_lpuart_rx;
	LPUART1_DMA.hdma_uart_tx = &hdma_lpuart_tx;
	WT_Enable_Uart_Receive_DMA(&hlpuart1);
#endif
	return;
}

/*
* get uart port index according para:huart
*/
uint8_t WT_Get_Uart_Port_Idx(UART_HandleTypeDef *huart)
{
	uint8_t port = 0;
	if(huart->Instance == UART4){
		port = 4;
	}
	else if(huart->Instance == USART1){
		port = 1;
	}
	else if(huart->Instance == USART2){
		port = 2;
	}
	else if(huart->Instance == USART3){
		port = 3;
	}
	else if(huart->Instance == LPUART1){
		port = 11;
	}
	return port;
}

/* get self-define uart port according to UART_HandleTypeDef
*
*/
MT_UART_dma_st * WT_Get_Uart_DMA_Port(UART_HandleTypeDef *huart)
{
#ifdef WATER_UART1
	if (huart->Instance == USART1)
		return &UART1_DMA;
#endif

#ifdef WATER_UART2
	if (huart->Instance == USART2)
		return &UART2_DMA;
#endif

#ifdef WATER_UART3
	if (huart->Instance == USART3)
		return &UART3_DMA;
#endif

#ifdef WATER_UART4
	if (huart->Instance == UART4)
		return &UART4_DMA;
#endif

#ifdef WATER_LPUART1
	if (huart->Instance == LPUART1)
		return &LPUART1_DMA;
#endif

	// for other uart, u can add your code like uart1
	return NULL;
}

/*
* just HAL_UART_Receive_DMA's ENCAP
* when init uart port, need to run the function first
* otherwise uart can get the first data from outside
*/
void WT_Enable_Uart_Receive_DMA(UART_HandleTypeDef *huart){
	
	MT_UART_dma_st * uart_dma_port = WT_Get_Uart_DMA_Port(huart);
	if(uart_dma_port == NULL)
		return;
	
	HAL_UART_Receive_DMA(uart_dma_port->huart,
						(uint8_t *)uart_dma_port->rx_dma_buf,BUF_LEN);
	return;
}
/**
* @brief  Initial uart: enable RCV DMA and IDLE int
*  			the function called by HAL_UART_MspInit in USART.c
* @param  uart: uart channel
  * @retval 
  */
void WT_UART_DMA_Init(UART_HandleTypeDef *huart){
	
	MT_UART_dma_st * uart_dma_port = WT_Get_Uart_DMA_Port(huart);
	if(uart_dma_port == NULL)
		return;
    /* USART���� */
    if(HAL_UART_Receive_DMA(huart,(uint8_t *)uart_dma_port->tx_dma_buf, BUF_LEN) != HAL_OK)    
		Error_Handler();
    /* �������н����ж� */
    __HAL_UART_ENABLE_IT(huart, UART_IT_IDLE);

	return;
}

/* ���ڽ��տ����ж� */
//����ÿ�ν��պ�ֱ����ת�洦����û�н����жϣ��µ����ݵ��ˣ�ֱ�Ӹ���iԭ������
void UART_Rcv_Idle_One_Time(MT_UART_dma_st * uart_dma_port)
{
	uint16_t rxSize = BUF_LEN - __HAL_DMA_GET_COUNTER(uart_dma_port->hdma_uart_rx);;
	uart_dma_port->rx_len = rxSize;
	//printf("Size:%d\n", rxSize);
	memcpy(uart_dma_port->rx_buf, uart_dma_port->rx_dma_buf, rxSize);
	uart_dma_port->rx_flag = 0;
	WT_RTC_GetTime(NULL);
	printf("[%d==>] [%s]\r\n", HAL_GetTick(), uart_dma_port->rx_buf);
	
	memset(uart_dma_port->rx_dma_buf, 0x00, BUF_LEN);
	return;
}
//��Ҫ�������Ƿ�����жϣ��������"\r\n",û����ʱ�������ۼƱ���;
//����û���������������ݱ��棬ֱ������
//������ݳ��������С���������ݽ�������
void UART_Rcv_Idle_Check_End(MT_UART_dma_st * uart_dma_port)
{
	uint16_t rxSize = BUF_LEN - __HAL_DMA_GET_COUNTER(uart_dma_port->hdma_uart_rx);
	if(uart_dma_port->rx_flag == 0){
		if (BUF_LEN <= (uart_dma_port->rx_len + rxSize)) {
			uart_dma_port->rx_flag = 1;
			rxSize = BUF_LEN - uart_dma_port->rx_len;
			printf("BUFFER FULL!![%d]!!!\r\n", BUF_LEN);
		}
		//ת������
		memcpy(uart_dma_port->rx_buf + uart_dma_port->rx_len, uart_dma_port->rx_dma_buf, rxSize);
		//���»��峤��
		uart_dma_port->rx_len += rxSize;
		//�ж������Ƿ������������ݽ����Ļ�������־λrx_flag��Ϊ1����֪ͨ����������
		// for lte module , we need read data multi time until get /r/d
		//get return char; get a total string from RX);
		
		if ((uart_dma_port->rx_buf[uart_dma_port->rx_len - 1] == 0xa) 
						&& (uart_dma_port->rx_buf[uart_dma_port->rx_len - 2] == 0xd))
				uart_dma_port->rx_flag = 1;
		
	}
	return;
  
}
/**
* @brief  Handler of RCV�� Copy data from DMA buffer to usr buffer
		 if get a string with the end of /r/n, then stop current rx process
* @param  uart: uart channel
* @retval 
  */
void WT_USART_Receive_IDLE(UART_HandleTypeDef *huart)  
{
	uint32_t tmp = 0;
	uint8_t port = 0;
	MT_UART_dma_st * uart_dma_port = WT_Get_Uart_DMA_Port(huart);
	if(uart_dma_port == NULL)
		return;
	port = WT_Get_Uart_Port_Idx(uart_dma_port->huart);
	WT_DEBUG("=== UART[%d] \r\n", port);
	//WT_DEBUG("RX==:[%s]", uart_dma_port->rx_dma_buf);
	
	tmp = __HAL_UART_GET_FLAG(huart,UART_FLAG_IDLE);
	if( tmp != RESET )
  {
		uint32_t i = 0;
		__HAL_UART_CLEAR_IDLEFLAG(uart_dma_port->huart);	//�����־λ
		//���״̬�Ĵ���SR,��ȡSR�Ĵ�������ʵ�����SR�Ĵ����Ĺ���
		//i = huart->Instance->ISR;   //L4 is ISR
		i = uart_dma_port->huart->Instance->ISR;
		//��ȡ���ݼĴ����е�����
		//i = huart->Instance->RDR;    //L4 is RDR
		i = uart_dma_port->huart->Instance->RDR;
		//i = hdma_uart_rx.Instance->CNDTR; 
		i = uart_dma_port->hdma_uart_rx->Instance->CNDTR;
		//WT_DEBUG("Get COUNT: %d\n", i);
		HAL_UART_DMAStop(uart_dma_port->huart);
		switch(port)
		{
			case 9:
			case 2: //485
			case 3:	//485
			case 11://GPS
			{
				printf("Get data:@@@@@@%s@@@@@@\r\n", uart_dma_port->rx_dma_buf);
				//memset(uart_dma_port->rx_dma_buf,0x00, BUF_LEN);
				//printf("=================Get data:!!!!!%s!!!!!===================\r\n", uart_dma_port->rx_dma_buf);
				UART_Rcv_Idle_One_Time(uart_dma_port);
				//uart_dma_port->rx_flag = 0;
				break;
			}
			case 1:	//LTE
			{
				UART_Rcv_Idle_Check_End(uart_dma_port);
				if(uart_dma_port->rx_flag == 1)
				{
					//������ת�浽AT��ר��BUFFER
					memset(AtRxBuffer,0x00, RXBUFF_LEN);  	
					memcpy(AtRxBuffer, uart_dma_port->rx_buf, uart_dma_port->rx_len);
					printf("uart1 rec : %s\r\n",AtRxBuffer);	
					memset(uart_dma_port->rx_buf, 0, BUF_LEN);	
					uart_dma_port->rx_len = 0;
					uart_dma_port->rx_flag = 0;
					memset(uart_dma_port->rx_dma_buf,0x00, BUF_LEN);
				}
				break;
			}
		}
		/* ��ջ��棬���½��� */
		memset(uart_dma_port->rx_dma_buf,0x00, BUF_LEN);
		//// ����DMA���� ��DMA���գ����ݴ���rx_buffer������
		if (uart_dma_port->rx_flag == 0)
		{	//continue to read data !!!!!!
			HAL_UART_Receive_DMA(huart,(uint8_t *)uart_dma_port->rx_dma_buf,BUF_LEN);
		}
		
		return;
	}
}

//		//else
//		/* �˵��������ݣ���Ҫ�ǿ�������λ��־λ */
//		//if(uart_dma_port->huart->Instance == UART4)
//		{
//			/* // ��ȡDMA�д�������ݸ��� */
//			usart_DMA_RxSize = BUF_LEN - __HAL_DMA_GET_COUNTER(uart_dma_port->hdma_uart_rx);
//			WT_DEBUG("Get COUNT: %d ===== usart_rx_flag:%d \n", usart_DMA_RxSize, uart_dma_port->rx_flag);
//			if(uart_dma_port->rx_flag == 0)
//      {	//copy data from r_buffer into 
//				//WT_DEBUG("Get data(len:%d)\n",  (uart_dma_port->rx_len + usart_DMA_RxSize));
//				if (BUF_LEN <= (uart_dma_port->rx_len + usart_DMA_RxSize)) {
//					uart_dma_port->rx_flag = 1;
//					usart_DMA_RxSize = BUF_LEN - uart_dma_port->rx_len;
//					printf("OVER FLOW! !!==>%d!", uart_dma_port->rx_len + usart_DMA_RxSize);
//				}
//                memcpy(uart_dma_port->rx_buf + uart_dma_port->rx_len, 
//							uart_dma_port->rx_dma_buf, usart_DMA_RxSize);
//				
//				//WT_DEBUG("uart_dma_port->rx_buf:%s", uart_dma_port->rx_dma_buf);
//				uart_dma_port->rx_len += usart_DMA_RxSize;
//				if(port == 11){
//					//for gps uart only read data one time!!!!
//					uart_dma_port->rx_flag = 0;
//					printf("====>%s\n", uart_dma_port->rx_dma_buf);
//					//LPUART1_Rec(&hlpuart1);
//				}
//				else {
//				// for lte module , we need read data multi time until get /r/d
//				//get return char; get a total string from RX);
//					if ((uart_dma_port->rx_buf[uart_dma_port->rx_len - 1] == 0xa) 
//						&& (uart_dma_port->rx_buf[uart_dma_port->rx_len - 2] == 0xd))
//						uart_dma_port->rx_flag = 1;
//				}
//				//WT_DEBUG("[0x%x  0x%x]", uart_dma_port->rx_buf[uart_dma_port->rx_len - 2], 
//				//			uart_dma_port->rx_buf[uart_dma_port->rx_len - 1]);
//				//WT_DEBUG("%s:Get FLAG:[%d] [%d]===>[%s]", __FUNCTION__, usart_DMA_RxSize, 
//				//			uart_dma_port->rx_len, uart_dma_port->rx_dma_buf);
//				//for(int i = 0; i < usart_DMA_RxSize;i++){
//				//	printf(" %02x", uart_dma_port->rx_dma_buf[i]);
//				//}
//				//printf("\r\n!!!!Flag:%d!!\r\n", uart_dma_port->rx_flag);
//				
//      }
//			else
//			{
//				WT_DEBUG("RX==:[%s]", uart_dma_port->rx_dma_buf);
//			}
//			/* ��ջ��棬���½��� */
//            memset(uart_dma_port->rx_dma_buf,0x00, BUF_LEN);
//			//// ����DMA���� ��DMA���գ����ݴ���rx_buffer������
//			if (uart_dma_port->rx_flag == 0)
//			{	//continue to read data !!!!!!
//				//WT_DEBUG("RX==DMA===>");
//				HAL_UART_Receive_DMA(huart,(uint8_t *)uart_dma_port->rx_dma_buf,BUF_LEN);
//			}
//    }
//	}
//}  

/**
* @brief  ://process receive data and clear the rx_buff
* @param  :
*			uart port: huart
* @retval :void
  */
void WT_Handle_Received_Data(UART_HandleTypeDef *huart)
{
	MT_UART_dma_st * uart_dma_port = WT_Get_Uart_DMA_Port(huart);
	if(uart_dma_port == NULL)
		return;	
	if (uart_dma_port->rx_len != 0){
		/* just print buffer */
		WT_DEBUG("Get data:0x%s", uart_dma_port->rx_buf);
		memset(uart_dma_port->rx_buf, 0x00, BUF_LEN);
	}
		
	return;
}

/**
  * @brief  deal with UART IDLE interrupt
  *         Check the uart which triger IDLE interrupt 
  *         Then handle receive data from DMA
  * @param  None
  * @retval None
  */
void WT_Handle_UART_IDLE(UART_HandleTypeDef *huart)
{
    if(__HAL_UART_GET_FLAG(huart,UART_FLAG_IDLE)) {
        WT_USART_Receive_IDLE(huart);
	}
	return;
}


//��֪��ΪʲôDMA���ж��������Σ���������һ��ʱ����һ�Σ�
//�������һ�Ρ�����ֻ���ûص������жϷ��ͽ���
//DMA��������жϻص�����
void WT_UART_TxCpltCallback(UART_HandleTypeDef *huart)
{
	MT_UART_dma_st * uart_dma_port = WT_Get_Uart_DMA_Port(huart);
		uint32_t tickstart = HAL_GetTick();
	if(uart_dma_port == NULL)
		return;
	
	//__HAL_DMA_DISABLE(huart->hdmatx); //���ͽ����󣬼���ʹ���ж�
	//���ͽ�������״̬ΪDone
	uart_dma_port->tx_flag = UART_DMA_TX_DONE;
	WT_DEBUG("\n[%d]:TX DONE", tickstart);
	//��ʵ��һ��Ҫ���tx_buff
	//memset(uart_dma_port->tx_buf, 0x0, BUF_LEN);
	//}
	return;
}

//self define weak function: UART_TCCallBack
void HAL_UART_TxCpltCallback(UART_HandleTypeDef *huart)
{	
	WT_UART_TxCpltCallback(huart);
	return;
}

/**
  * @brief  Rx Transfer completed callback
  * @param  UartHandle: UART handle
  * @note   This example shows a simple way to report end of DMA Rx transfer, and 
  *         you can add your own implementation.
  * @retval None
  */
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
	uint8_t port = WT_Get_Uart_Port_Idx(huart);
	//WT_DEBUG("uart[%d]", port);
	//MT_UART_dma_st * uart_dma_port = WT_Get_Uart_DMA_Port(huart);
	switch(port)
		{
		case 1:
			break;
		case 2:
			break;
		case 3:
			break;
		case 4:
			WT_Debug_Port_RxCpltCallback();
			break;
		}
	return;
  /* Set transmission flag: transfer complete */
  
}

//Send data through DMA channel of UART
void WT_DMA_Uart_Send(UART_HandleTypeDef *huart, uint8_t * tx_buf, uint8_t len) 
{
	uint8_t txlen = strlen((const char *)tx_buf);
	MT_UART_dma_st * uart_dma_port = WT_Get_Uart_DMA_Port(huart);
	if(uart_dma_port == NULL)
		return;

	if(uart_dma_port->tx_flag == UART_DMA_TX_DONE){
		memcpy(uart_dma_port->tx_buf, tx_buf, txlen);
		uart_dma_port->tx_len = txlen;
		WT_DEBUG("TX start!!!!!!");
		uart_dma_port->tx_flag = UART_DMA_TX_BUSY;
		if(HAL_UART_Transmit_DMA(uart_dma_port->huart, uart_dma_port->tx_buf, txlen)!= HAL_OK)
			Error_Handler();
	}
	else
		WT_DEBUG("TX busy!!!!!!");
	WT_DEBUG("WT_DMA_Uart_Send!! OVER!!!!");
	return;
}
///////////////////UART4 HANDLE///////////////
uint8_t aUart4Buffer[100];
//UART�Ľ��ջص�����
void WT_Debug_Port_RxCpltCallback(void)
{
	//printf("Get =====>>>>UART4 [%s]\n", UART4_DMA.rx_dma_buf);
	UART4_DMA.rx_buf[UART4_DMA.rx_len] = UART4_DMA.rx_dma_buf[0];
	UART4_DMA.rx_len ++;
	Handle_Debug_Port_Data();
	//������һ��RX IT
	WT_Debug_Port_Start_Rcv();
	return;
}

//��鴮�������Ƿ��Ѿ��������
uint8_t Check_Uart_Send_Done(UART_HandleTypeDef * huart)
{
	//printf("======%s------\n", __FUNCTION__);
	MT_UART_dma_st * uart_dma_port = WT_Get_Uart_DMA_Port(huart);
	//printf("Get tx_flag : 0x%x\n", uart_dma_port->tx_flag);
	if(uart_dma_port->tx_flag == UART_DMA_TX_DONE)
		return 1;
	return 0;

}

//��鴮�������Ƿ��Ѿ��������
uint8_t Check_Uart_TX_Done(UART_HandleTypeDef * huart)
{
	//printf("======%s------\n", __FUNCTION__);
	MT_UART_dma_st * uart_dma_port = WT_Get_Uart_DMA_Port(huart);
	//printf("Get tx_flag : 0x%x\n", uart_dma_port->tx_flag);
	if(uart_dma_port->tx_flag == UART_DMA_TX_DONE)
		return 1;
	return 0;

}

void WT_Port_Send_Data(UART_HandleTypeDef *huart, uint8_t * tx_buf, uint16_t len) 
{
	MT_UART_dma_st * uart_dma_port = WT_Get_Uart_DMA_Port(huart);
	uint32_t tickstart = HAL_GetTick();
	if(uart_dma_port->tx_flag == UART_DMA_TX_DONE){
		//memcpy(uart_dma_port->tx_buf, tx_buf, txlen);
		uart_dma_port->tx_len = len;
		uart_dma_port->tx_flag = UART_DMA_TX_BUSY;
		printf("\n[%d]  TX start!![0x%08x]![0x%x]!!!\r\n", tickstart, tx_buf, len);
		if(HAL_UART_Transmit_DMA(uart_dma_port->huart, tx_buf, len)!= HAL_OK)
			Error_Handler();
			//uart_dma_port->tx_flag = UART_DMA_TX_DONE;
	}
	else
		printf("\r\n\n\n@@@@@@@@@TX busy!!!!!!");
	WT_DEBUG("WT_Port_Send_Data!! OVER!!!!");
	return;
}

//UART4 ͨ��DMA���з�������
//������Դ�����tx_buff, ���ﲻ�ٽ����ݰ��Ƶ�ԭ����TX_DMA_BUFF��
void WT_Debug_Port_Send(uint8_t * tx_buf, uint32_t len) 
{
	//WT_Port_Send_Data(&huart4, tx_buf, len);
	MT_UART_dma_st * uart_dma_port = WT_Get_Uart_DMA_Port(&huart4);
	uint32_t tickstart = HAL_GetTick();
	if(uart_dma_port->tx_flag == UART_DMA_TX_DONE){
		//memcpy(uart_dma_port->tx_buf, tx_buf, txlen);
		uart_dma_port->tx_len = len;
		uart_dma_port->tx_flag = UART_DMA_TX_BUSY;
		printf("\n[%d]  TX start!![0x%08x]![0x%x]!!!\r\n", tickstart, tx_buf, len);
		if(HAL_UART_Transmit_DMA(&huart4, tx_buf, len)!= HAL_OK)
			Error_Handler();
	}
	else
		printf("\r\n\n\n@@@@@@@@@TX busy!!!!!!");
	WT_DEBUG("WT_Debug_Port_Send!! OVER!!!!");
	return;
}
char chData;
//enable RX IT: only get one char
void WT_Debug_Port_Start_Rcv(void)
{
	//only get one char
	while(HAL_UART_Receive_IT(&huart4, UART4_DMA.rx_dma_buf, 1) == HAL_OK);
	return;	
}

void DGB_printf(const char *fmt, ...)
{
  char text[512];
	uint16_t len;
  va_list ap;
  va_start(ap, fmt);
  len = sprintf(text, fmt, ap);
  va_end(ap);
  WT_DMA_Uart_Send(&huart4, (uint8_t *)text, len);
	return;
}


////END OF DEBUG PORT FUNCTION/////////////////////////////

void WT_Handle_CMD_Function(char *buff)
{
	uint8_t cmdType = 0;

	cmdType = WT_Check_Debug_CMD_Type(buff);
	switch(cmdType)
		{
		case AT_CMD:
			#ifdef WT_LTE
				//send at command to LTE"
				WT_DEBUG("Send **%s*** to LTE\r\n", buff);
				lte_uart_cmd(aUart4Buffer); // ���ڿ���EC20
				//WT_DMA_Uart_Send(&huart1, (uint8_t*)buff, strlen((const char *)aUart4Buffer));
			#endif
			break;
		case GPS_CMD:	//GPS command
			#ifdef WT_GPS_1PPS
				//send at command to GPS"
				wt_gen_gps_cmd(aUart4Buffer);
				WT_DEBUG("Send **%s*** to GPS\n", buff);
				WT_DMA_Uart_Send(&hlpuart1, (uint8_t*)buff, strlen((const char *)buff));
				WT_DMA_Uart_Send(&huart4, (uint8_t*)buff, strlen((const char *)buff));
			#endif
			break;
		case WT_CMD:
			break;
		case I2C_CMD:
			break;
		case I2S_CMD:
			//Handle_SAI_cmds(UART4_DMA.rx_buf);
			break;
		case ADC_CMD:
			break;
		case EMMC_CMD:
			break;
		case PCM_CMD:
			break;
		case NOCMD:
			break;
	}
	memset(buff,0, 100);
}

/*
*�������Դ���uart4���͹���������Ҫ��"\r\n"��β
*/
void Handle_Debug_Port_Data(void)
{
	if (UART4_DMA.rx_len < 2)
		return;
	if(UART4_DMA.rx_len > 100)
	{
		//��������
		printf("Get [%d]: %s\r\n", UART4_DMA.rx_len, UART4_DMA.rx_buf);
		UART4_DMA.rx_len = 0;
	  //������ջ���ͱ�־
		memset(UART4_DMA.rx_buf, 0, BUF_LEN);
		UART4_DMA.rx_len = 0;
		UART4_DMA.rx_flag = 1;
	}
	else {
		if( (UART4_DMA.rx_buf[UART4_DMA.rx_len-1] == 0xa) &&
				(UART4_DMA.rx_buf[UART4_DMA.rx_len-2] == 0xd))
		{
			////��debug uart���յ������ݱ���������AT/GPS/Debug command
			UART4_DMA.rx_buf[UART4_DMA.rx_len] = 0;
			strcpy((char *)aUart4Buffer, (char *)UART4_DMA.rx_buf);
			//when get /r/n; then handle the RX data
			//������ջ���ͱ�־
			memset(UART4_DMA.rx_buf, 0, BUF_LEN);
			UART4_DMA.rx_len = 0;
			UART4_DMA.rx_flag = 1;
		}	
	}
}

//�Խ��յ����ݽ��з�������
void WT_Debug_Port_Handle_Data(void)
{
	WT_Handle_CMD_Function((char *)aUart4Buffer);
	return;
}

void WT_Debug_Port_Text(void)
{
	while(1)
	{
		HAL_Delay(100);
		//DGB_printf("=TEST UART4 TX<===\n");
		WT_Debug_Port_Handle_Data();
		if( strstr((char *)UART4_DMA.rx_buf, "exit"))
			break;
	}
}
/**************
* parse the string get from uart4
* 1: AT command send to LTE;
* 2: $xxxx command send to GPS with 1pps
* 3: Debug commands
* 0: others
**/
uint8_t WT_Check_Debug_CMD_Type(char *buff)
{
	uint8_t cmdType = 0;
	uint8_t len = 0;
	len = strlen(buff);
	if ( len <= 2)
		return 0;
		
	if( buff[0] == 'E' && buff[1] == 'C' )
		cmdType = AT_CMD;
	else if (buff[0] == 'G' && buff[1] == 'P')
		cmdType = GPS_CMD;
	else if (buff[0] == 'W' && buff[1] == 'T')
		cmdType = WT_CMD;
	else if (buff[0] == 'I' && buff[1] == 'C')
		cmdType = I2C_CMD;
	else if (buff[0] == 'I' && buff[1] == 'S')
		cmdType = I2S_CMD;
	else
		cmdType = NOCMD;
	if( buff[len-1] != 0xa || buff[len-2] != 0xd )
		cmdType = NOCMD;
	
	return cmdType;
}
/*
* CMD foramt�� IC [1/2] [w/r][b/w] [reg] [data]
*/
void Handle_I2C_CMD(const char *buff)
{
	uint8_t rdFlag = 0;
	uint8_t reg = 0x0;
	uint8_t size = 0;
	uint8_t ch = 0;		//I2C channel
	uint16_t data;
	char * ptr = (char *)buff+3;// point [1/2]
	if(*ptr == '1')	//16bit
		ch = 1;
	else if( *ptr == '2')
		ch = 2;
	else
		return;
	// check write or read
	ptr = strstr(buff, " w");
	if (ptr != 0)
		rdFlag = 0;
	else 
		ptr = strstr(buff, " r");
		if (ptr != 0)
			rdFlag = 1;
		else
			return;
	// check size of data
	ptr = ptr + 2;
	if(*ptr == 'h')	//16bit
		size = 2;
	else if( *ptr == 'b')
		size = 1;
	else
		return;
	
	ptr ++;
	// get reg 0xzz
	reg = strtoul(ptr, &ptr, 16);
	if (rdFlag == 0)
		data = strtoul(ptr, &ptr, 16);
		
	if( rdFlag == 0)
		I2C_Read(ch, reg, size);
	else
		I2C_Write(ch, reg, size, data);
	
	return;
}



//void Handle_Debug_Cmd(const char * buff)
//{
//	uint8_t cmdType = NOCMD;
//	cmdType = WT_Check_Debug_CMD_Type((char *)buff);
//	
//}

void Handle_LPUART1_Data(void)
{
	GPS_Data_Test();
}
void WT_UART_Main_Loop(void)
{
	//�ȴ���GPS����
#ifdef WATER_LPUART1
	Handle_LPUART1_Data();
#endif
	//LTE����
#ifdef WATER_UART1

#endif
//485����
#ifdef WATER_UART2

#endif

#ifdef WATER_UART3

#endif
//��������Դ���
#ifdef WATER_UART4

#endif
}
///////////////////////////////////////////////////
// the following code is handle data from UART
// includes test code 
//////////////////////////////////////////////////

  /* Buffer used for reception */

//����������ڴ�����Ӧ���ڵĽ�������
void WT_Uart_Main_Test(UART_HandleTypeDef *huart)
{
	uint8_t port = 0;
	MT_UART_dma_st * uart_dma_port = WT_Get_Uart_DMA_Port(huart);
	if(uart_dma_port == NULL)
		return;
	port = WT_Get_Uart_Port_Idx(huart);
	//���ݽ�����ɣ����ɴ�������
	if (uart_dma_port->rx_flag == 1)
	{	
		if(port == 4)
		{
			Handle_Debug_Port_Data();
			//��debug uart���յ������ݱ���������AT/GPS/Debug command
//			uint8_t len = strlen((const char *)uart_dma_port->rx_buf);
//			memcpy(aUart4Buffer, uart_dma_port->rx_buf, uart_dma_port->rx_len);
//			WT_DEBUG("==>[%s]\r\n%s", uart_dma_port->rx_buf, aUart4Buffer);
		}
		else if(port == 1){
			//handle data from LTE module
			printf("[UART1]:[%s]\r\n", uart_dma_port->rx_buf);
			WT_DMA_Uart_Send(&huart4, (uint8_t*)uart_dma_port->rx_buf, strlen(uart_dma_port->rx_buf));
		}
		else if(port == 11){
			//GPS����ͦ�࣬����ת����debug port��
			printf("[LPUART1]:[%s]\r\n", uart_dma_port->rx_buf);
		}
		//������ջ���ͱ�־
		memset(uart_dma_port->rx_buf, 0, BUF_LEN);
		uart_dma_port->rx_len = 0;
		uart_dma_port->rx_flag = 0;

		//enable RX DMA function for get data
		HAL_UART_Receive_DMA(huart,(uint8_t *)uart_dma_port->rx_dma_buf,BUF_LEN);
	}
	
	return;
}

///////////////////////////////////////////////////////

uint8_t WT_Check_AT_Command(char * buff)
{
	uint8_t len = strlen(buff);
	if( len <= 1)
		return 1;
	if( buff[0] == 'A' && buff[1] == 'T' ) {
		if( buff[len-1] == 0xa && buff[len-2] == 0xd )
			return 0;
		else
			return 2;
		return 1;
	}
	return 3;
}



/***
* to handle recieve data from uart.
* uart4 is debug port, used to send command to other uarts(LTE/GPS) 
* 			and show debug message
* uart1 is LTE module: show return data!!!
* WT_Uart_MainLoop_Test: called in main loop
*/
void WT_Uart_MainLoop_Test(void)
{
	uint8_t cmdType = 0;
	WT_Uart_Main_Test(&huart4);

#ifdef WT_GPS_1PPS
	WT_Uart_Main_Test(&hlpuart1);
#endif
#ifdef WT_LTE
	WT_Uart_Main_Test(&huart1);
#endif
//	cmdType = WT_Check_Debug_CMD_Type((char*)aUart4Buffer);
//	switch (cmdType) {
//		case AT_CMD:	//AT command
////		#ifdef WT_LTE
////			//send at command to LTE"
////			WT_DEBUG("Send **%s*** to LTE\n", aUart4Buffer);
////			WT_DMA_Uart_Send(&huart1, (uint8_t*)aUart4Buffer, strlen((const char *)aUart4Buffer));
////		#endif
////			break;
////		case GPS_CMD:	//GPS command
////		#ifdef WT_GPS_1PPS
////			//send at command to GPS"
////			wt_gen_gps_cmd(aUart4Buffer);
////			WT_DEBUG("Send **%s*** to GPS\n", aUart4Buffer);
////			WT_DMA_Uart_Send(&hlpuart1, (uint8_t*)aUart4Buffer, strlen((const char *)aUart4Buffer));
////			WT_DMA_Uart_Send(&huart4, (uint8_t*)aUart4Buffer, strlen((const char *)aUart4Buffer));

//		#endif
//			break;
//		case 3:
//			break;
	//}

	//memset(aUart4Buffer,0, 100);

	//l70_loop_test();
}


/* Exported macro ------------------------------------------------------------*/
//#define COUNTOF(__BUFFER__)   (sizeof(__BUFFER__) / sizeof(*(__BUFFER__)))
/* Exported functions ------------------------------------------------------- */

/* Size of Reception buffer */
//#define RXBUFFERSIZE                      TXBUFFERSIZE
  /* Buffer used for reception */
//uint8_t aRxBuffer[100];

#ifdef WT_LTE
//send the at command get from debug port
void lte_loop_test(char * cmd)
{
	
	uint8_t len;// = strlen(aATBuffer);
	//if(len != 0)
	//	cmd = aATBuffer;
	len = strlen(cmd);
	if(len == 0)
		return;
	if ( WT_Check_AT_Command(cmd) != 0)
		return;
	
	printf("send AT:[%s]\r\n", cmd);
	//send at command to LTE"
	if(HAL_UART_Transmit(&huart1, (uint8_t*)cmd, 100, 5000)!= HAL_OK)
		Error_Handler();   
	//clear the at command buffer
	memset(cmd,0, len);
	return;
}
#else
void lte_loop_test(char * cmd){
	printf(">>>>>LTE disable:<<<<<<<<<");
	return;
}
#endif



#ifdef WT_GPS_1PPS
#define POLY        0x1021
/*
$GNRMC,000128.870,V,,,,,0.00,0.00,060180,,,N*58
$GNVTG,0.00,T,,M,0.00,N,0.00,K,N*2C
$GNGGA,000128.870,,,,,0,0,,,M,,M,,*52
*/
//uint16_t crc16(unsigned char *addr, int num, uint16_t crc)  
//{  
//	int i;  
//	for (; num > 0; num--)              /* Step through bytes in memory */  
//	{  
//		crc = crc ^ (*addr++ << 8);     /* Fetch byte from memory, XOR into CRC top byte*/  
//		for (i = 0; i < 8; i++)             /* Prepare to rotate 8 bits */  
//		{  
//			if (crc & 0x8000)            /* b15 is set... */  
//				crc = (crc << 1) ^ POLY;    /* rotate and XOR with polynomic */  
//			else                          /* b15 is clear... */  
//				crc <<= 1;                  /* just rotate */  
//		}                             /* Loop for 8 bits */  
//		crc &= 0xFFFF;                  /* Ensure CRC remains 16-bit value */  
//	}                               /* Loop until num=0 */  
//	return(crc);                    /* Return updated CRC */  
//}



void lpuart_send(uint8_t *data)
{
//	uint8_t len = strlen((const char *)data);
//	int i = 0;
//	uint16_t crc = 0;
//	uint8_t cmdType = WT_Check_Debug_CMD_Type((char*)data);
//	
//	if(cmdType == GPS_CMD)
//	{
//		crc = data[1];
//		
//		for( i = 2; i <= len-3; i++) 
//		{
//			printf("%c[%02x] ", data[i], data[i]);
//			crc = crc ^ data[i];
//		}
//		printf("CRC:%x\n", crc);
//	}

//	
//	return;
}

void l70_loop_test(void)
{
//	uint8_t aGPSTxBuf[] = "$PDTINFO*4e\r\n";
//	uint8_t len = (COUNTOF(aGPSTxBuf) - 1);
//	WT_DEBUG("send GPS[%d]:{%s}", len, aGPSTxBuf);
//	//if(HAL_UART_Transmit_IT(&huart4, (uint8_t*)aGPSTxBuf, len, 5000)!= HAL_OK)
//  {
//    Error_Handler();   
//  }
//  
//  HAL_Delay(1000);
//  /*##-3- Put UART peripheral in reception process ###########################*/  
//  if(HAL_UART_Receive_IT(&huart4, (uint8_t *)aRxBuffer, 100) != HAL_OK)
//  {
//    Error_Handler();  
//  }
//  
//  WT_DEBUG("Get ===>:[%x]\r\n", huart4.Instance->ISR);
//  return;
}

#endif
