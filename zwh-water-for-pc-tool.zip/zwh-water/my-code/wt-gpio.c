/**
  ******************************************************************************
  * File Name          : wt-gpio.c
  * Description        : This file provides code for the configuration
  *                      of the GPIOS.
  ******************************************************************************
  WT_Init_Uarts_DMA_Port  ==> put main()
  WT_UART_DMA_Init()  ==> to enable DMA IDLE should be call after uart init
  WT_Uart_MainLoop_Test();	  ===> deal with rx data ==> put main loop
  ******************************************************************************
  */
  
 /* Includes ------------------------------------------------------------------*/
#include "wt-gpio.h"
#include "main.h"
#include "wt-common.h"

#ifdef WT_LTE
void LTE_GPIO1_Init(void)
{	
  GPIO_InitTypeDef GPIO_InitStruct = {0};
	/*Configure GPIO pin Output Level */
	/*Configure GPIO pins : PEPin PEPin PEPin */
	GPIO_InitStruct.Pin = LTE_W_DISABLE_PE13_Pin|LTE_MCU_WAKE_PE14_Pin|LTE_PWR_KEY_PE15_Pin;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(GPIOE, &GPIO_InitStruct);

	GPIO_InitStruct.Pin = LTE_DTR_PC13_Pin;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(LTE_DTR_PC13_GPIO_Port, &GPIO_InitStruct);

	/*Configure GPIO Input pins : DCD/RI PBPin */
	GPIO_InitStruct.Pin = LTE_DCD_PB15_Pin;
	GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	HAL_GPIO_Init(LTE_DCD_PB15_GPIO_Port, &GPIO_InitStruct);

	GPIO_InitStruct.Pin = LTE_RI_PC2_Pin;
	GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	HAL_GPIO_Init(LTE_RI_PC2_GPIO_Port, &GPIO_InitStruct);


	HAL_GPIO_WritePin(GPIOE, LTE_W_DISABLE_PE13_Pin|LTE_MCU_WAKE_PE14_Pin|LTE_PWR_KEY_PE15_Pin, GPIO_PIN_RESET);
	HAL_GPIO_WritePin(LTE_DTR_PC13_GPIO_Port, LTE_DTR_PC13_Pin, GPIO_PIN_RESET);
}

/* Send a same pulse to toggle the LTE power status */
void LTE_PowerCycle(void)
{
	/*Configure GPIO pin Output Level-->high */
	HAL_GPIO_WritePin(LTE_PWR_KEY_PE15_GPIO_Port, LTE_PWR_KEY_PE15_Pin, GPIO_PIN_RESET);
	/*Configure GPIO pin Output Level */
	HAL_GPIO_WritePin(LTE_PWR_KEY_PE15_GPIO_Port, LTE_PWR_KEY_PE15_Pin, GPIO_PIN_RESET);
	HAL_Delay(100);
	HAL_GPIO_WritePin(LTE_PWR_KEY_PE15_GPIO_Port, LTE_PWR_KEY_PE15_Pin, GPIO_PIN_SET);
	HAL_Delay(500);
	HAL_GPIO_WritePin(LTE_PWR_KEY_PE15_GPIO_Port, LTE_PWR_KEY_PE15_Pin, GPIO_PIN_RESET);
	return;
}

void LTE_Reset1(void)
{
	/*Configure GPIO pin Output Level-->high */
	HAL_GPIO_WritePin(LTE_RESET_GPIO_Port, LTE_RESET_PB13_Pin, GPIO_PIN_RESET);

	/*Configure GPIO pin Output Level */
	HAL_GPIO_WritePin(LTE_RESET_GPIO_Port, LTE_RESET_PB13_Pin, GPIO_PIN_RESET);
	HAL_Delay(100);
	HAL_GPIO_WritePin(LTE_RESET_GPIO_Port, LTE_RESET_PB13_Pin, GPIO_PIN_SET);
	HAL_Delay(500);
	HAL_GPIO_WritePin(LTE_RESET_GPIO_Port, LTE_RESET_PB13_Pin, GPIO_PIN_RESET);
	return;
}
#endif

///////////////////////////////////////////////////////////
#ifdef WT_GPS_1PPS
/*************************************************/
#define GPS_POWER_PIN 		GPIO_PIN_8
#define GPS_POWER_PORT		GPIOD
#define GPS_PPS_PA15_Pin 	GPIO_PIN_15
#define GPS_PPS_PA15_GPIO_Port GPIOA
//HW 02 Change GPS reset from PA8 to PD6
#define HW_VERSION_02 1
#ifdef HW_VERSION_02
#define GPS_RESET_PIN 	GPIO_PIN_6
#define GPS_RESET_PORT 	GPIOD
#else
#define GPS_RESET_PIN 	GPIO_PIN_8
#define GPS_RESET_PORT 	GPIOA
#endif

//#define GPS_POWER_PD8_Pin GPIO_PIN_8
//#define GPS_POWER_PD8_GPIO_Port GPIOD
//#define GPS_RESET_PA8_Pin GPIO_PIN_8
//#define GPS_RESET_PA8_GPIO_Port GPIOA
//#define GPS_PPS_PA15_Pin GPIO_PIN_15
//#define GPS_PPS_PA15_GPIO_Port GPIOA


///************************************************/
//#define HW_VERSION_02 1
//#ifdef HW_VERSION_02
//#define GPS_RESET_PD6_Pin GPIO_PIN_6
//#define GPS_RESET_PD6_GPIO_Port GPIOD
//#else
//#define GPS_RESET_Pin GPIO_PIN_8
//#define GPS_RESET_GPIO_Port GPIOA
//#endif
/*****************************************************************************
 * Function 		 : GPS_Init_1PPS_Pin
 * Description	 : ����1PPS���ŵĹ���; 0:���ģʽ 1���ⲿ�ж�
									 
 * Input				 : uint8_t enable  
 * Output 			 : None
 * Return 			 : 
 * Others 			 : 
 * Record
 * 1.Date 			 : 20200619
 *	 Author 		 : zhangwh
 *	 Modification: Created function

*****************************************************************************/
void GPS_Init_1PPS_Pin(uint8_t enable)
{
	GPIO_InitTypeDef GPIO_InitStruct = {0};
	/* GPIO Ports Clock Enable */
	__HAL_RCC_GPIOA_CLK_ENABLE();

	if(enable == 1)
	{ //set to input mode as a interrupt source
		/*Configure GPIO pin : pulse */
		GPIO_InitStruct.Pin = GPS_PPS_PA15_Pin;
		GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
		GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
		GPIO_InitStruct.Pull = GPIO_PULLDOWN;
		HAL_GPIO_Init(GPS_PPS_PA15_GPIO_Port, &GPIO_InitStruct);
		
		HAL_NVIC_SetPriority(EXTI15_10_IRQn, 2, 0);
		HAL_NVIC_EnableIRQ(EXTI15_10_IRQn);
	} else {
		
		GPIO_InitStruct.Pin = GPS_PPS_PA15_Pin;
		GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
		GPIO_InitStruct.Pull = GPIO_NOPULL;
		GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
		HAL_GPIO_Init(GPS_PPS_PA15_GPIO_Port, &GPIO_InitStruct);
		
		HAL_GPIO_WritePin(GPS_PPS_PA15_GPIO_Port, GPS_PPS_PA15_Pin, GPIO_PIN_RESET);
	}
			
	return;
}

//��ʼ��GPS�����ţ� power ��reset
void GPS_GPIO_Init(void)
{

  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();

  /*Configure GPIO pin : PtPin */
  GPIO_InitStruct.Pin = GPS_POWER_PIN;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
  HAL_GPIO_Init(GPS_POWER_PORT, &GPIO_InitStruct);

  /*Configure GPIO pin : PtPin */
  GPIO_InitStruct.Pin = GPS_RESET_PIN;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
  HAL_GPIO_Init(GPS_RESET_PORT, &GPIO_InitStruct);
  
  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPS_POWER_PORT, GPS_POWER_PIN, GPIO_PIN_SET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPS_RESET_PORT, GPS_RESET_PIN, GPIO_PIN_RESET);

	//GPS_Init_1PPS_Pin(0);
  //GPS_Reset();
  //HAL_NVIC_SetPriority(EXTI15_10_IRQn, 2, 0);
  //HAL_NVIC_EnableIRQ(EXTI15_10_IRQn);


}




void GPS_Set_Power(uint8_t level)
{
	if (level == 1)
		/*Configure GPIO pin Output Level */
  	HAL_GPIO_WritePin(GPS_POWER_PORT, GPS_POWER_PIN, GPIO_PIN_SET);
	else{
		HAL_GPIO_WritePin(GPS_POWER_PORT, GPS_POWER_PIN, GPIO_PIN_RESET);
		GPS_Init_1PPS_Pin(0);
		}

	return;
		
}

//����GPS reset�ź� high > 10ms
void GPS_Reset(void)
{
	/*Configure GPIO pin Output Level-->high */
	printf("= RESET entry==\r\n");
	WT_DEBUG("=entry==");
	/*Configure GPIO pin Output Level */
	HAL_GPIO_WritePin(GPS_RESET_PORT, GPS_RESET_PIN, GPIO_PIN_RESET);
	HAL_Delay(300);
	HAL_GPIO_WritePin(GPS_RESET_PORT, GPS_RESET_PIN, GPIO_PIN_SET);
	HAL_Delay(300);
	HAL_GPIO_WritePin(GPS_RESET_PORT, GPS_RESET_PIN, GPIO_PIN_RESET);
				printf("=OVER==");

}


//��GPS��POWER���input�����ĵ�һЩ
void GPS_Power_down(void)
{
	GPIO_InitTypeDef GPIO_InitStruct = {0};
	/*Configure GPIO pin Output Level */
	GPIO_InitStruct.Pin = GPS_POWER_PIN;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPS_POWER_PORT, &GPIO_InitStruct);
}

#endif

#ifdef WT_USB_CLIENT
void USB_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOB_CLK_ENABLE();
  /*Configure GPIO pin : PtPin */
  GPIO_InitStruct.Pin = USB_PWR_EN_PB12_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
  HAL_GPIO_Init(USB_PWR_EN_PB12_GPIO_Port, &GPIO_InitStruct);
	/*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(USB_PWR_EN_PB12_GPIO_Port, USB_PWR_EN_PB12_Pin, GPIO_PIN_RESET);
  
  return;
}

void USB_PowerOn(uint8_t on){
	if( on == POWER_ON)
		HAL_GPIO_WritePin(USB_PWR_EN_PB12_GPIO_Port, USB_PWR_EN_PB12_Pin, GPIO_PIN_SET);
	else
		HAL_GPIO_WritePin(USB_PWR_EN_PB12_GPIO_Port, USB_PWR_EN_PB12_Pin, GPIO_PIN_RESET);
	
	return;
}

#endif

void EMMC_GPIO_Init(void)
{			WT_DEBUG("=entry==");
	GPIO_InitTypeDef GPIO_InitStruct = {0};
	//return;
	/* GPIO Ports Clock Enable */
	__HAL_RCC_GPIOD_CLK_ENABLE();
	/*Configure GPIO pin : PtPin */
	GPIO_InitStruct.Pin = EMMC_RESET_PD15_Pin;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
	HAL_GPIO_Init(EMMC_RESET_PD15_GPIO_Port, &GPIO_InitStruct);
	/*Configure GPIO pin Output Level */
	HAL_GPIO_WritePin(EMMC_RESET_PD15_GPIO_Port, EMMC_RESET_PD15_Pin, GPIO_PIN_RESET);

	return;
}
//High >200us
void EMMC_Reset(void){
				WT_DEBUG("=entry==");
	/*Configure GPIO pin Output Level-->high */
	HAL_GPIO_WritePin(EMMC_RESET_PD15_GPIO_Port, EMMC_RESET_PD15_Pin, GPIO_PIN_SET);
	/*Configure GPIO pin Output Level */
	HAL_GPIO_WritePin(EMMC_RESET_PD15_GPIO_Port, EMMC_RESET_PD15_Pin, GPIO_PIN_SET);
	HAL_Delay(100);
	HAL_GPIO_WritePin(EMMC_RESET_PD15_GPIO_Port, EMMC_RESET_PD15_Pin, GPIO_PIN_RESET);
	HAL_Delay(100);
	HAL_GPIO_WritePin(EMMC_RESET_PD15_GPIO_Port, EMMC_RESET_PD15_Pin, GPIO_PIN_SET);
	HAL_Delay(100);
	return;	
}

void Sensor2_GPIO_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStruct = {0};
	//return;
	/* GPIO Ports Clock Enable */
	__HAL_RCC_GPIOE_CLK_ENABLE();
	/*Configure GPIO pin : PtPin */
	GPIO_InitStruct.Pin = SENSOR2_POWER_PE1_Pin;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
	HAL_GPIO_Init(SENSOR2_POWER_PE1_GPIO_Port, &GPIO_InitStruct);
	/*Configure GPIO pin Output Level */
	HAL_GPIO_WritePin(SENSOR2_POWER_PE1_GPIO_Port, SENSOR2_POWER_PE1_Pin, GPIO_PIN_SET);
}

void Sensor1_GPIO_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStruct = {0};
	//return;
	/* GPIO Ports Clock Enable */
	__HAL_RCC_GPIOE_CLK_ENABLE();
	/*Configure GPIO pin : PtPin */
	GPIO_InitStruct.Pin = SENSOR1_POWER_PE12_Pin;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
	HAL_GPIO_Init(SENSOR1_POWER_PE12_GPIO_Port, &GPIO_InitStruct);
	/*Configure GPIO pin Output Level */
	HAL_GPIO_WritePin(SENSOR1_POWER_PE12_GPIO_Port, SENSOR1_POWER_PE12_Pin, GPIO_PIN_SET);

}

void Pressure_GPIO_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStruct = {0};
	//return;
	/* GPIO Ports Clock Enable */
	__HAL_RCC_GPIOE_CLK_ENABLE();
	/*Configure GPIO pin : PtPin */
	GPIO_InitStruct.Pin = PRESSURE_POWER_PD12_Pin;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
	HAL_GPIO_Init(PRESSURE_POWER_PD12_GPIO_Port, &GPIO_InitStruct);
	/*Configure GPIO pin Output Level */
	HAL_GPIO_WritePin(PRESSURE_POWER_PD12_GPIO_Port, PRESSURE_POWER_PD12_Pin, GPIO_PIN_SET);

}

void Sensors_PowerOn(uint8_t sensors, GPIO_PinState enable)
{
	/*Configure GPIO pin Output Level */
	//bit 0: pressure bit 1: sensor1(Flow); bit 2: sensor2-4
	
	if( sensors & 0x1)
		HAL_GPIO_WritePin(PRESSURE_POWER_PD12_GPIO_Port, PRESSURE_POWER_PD12_Pin, enable);
	else if(sensors & 0x2)
		HAL_GPIO_WritePin(SENSOR1_POWER_PE12_GPIO_Port, SENSOR1_POWER_PE12_Pin, enable);
	else if(sensors & 0x4)
		HAL_GPIO_WritePin(SENSOR2_POWER_PE1_GPIO_Port, SENSOR2_POWER_PE1_Pin, enable);
	
	return;
}


void Sensors_GPIO_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStruct = {0};
	//return;
	/* GPIO Ports Clock Enable */
	__HAL_RCC_GPIOE_CLK_ENABLE();
	/*Configure GPIO pin : */
	//PE1 ==> for Sensor2/3/4 and battery */
	//PE12 ==> for Sensor1
	GPIO_InitStruct.Pin = SENSOR1_POWER_PE12_Pin;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
	HAL_GPIO_Init(SENSOR2_POWER_PE1_GPIO_Port, &GPIO_InitStruct);
	GPIO_InitStruct.Pin = SENSOR1_POWER_PE12_Pin;
	HAL_GPIO_Init(SENSOR1_POWER_PE12_GPIO_Port, &GPIO_InitStruct);
	/*Configure GPIO pin Output Level */
	//HAL_GPIO_WritePin(SENSORS_POWER_PE_GPIO_Port, SENSOR1_POWER_PE12_Pin, GPIO_PIN_RESET);

	/*Configure GPIO pin :  */
	//
	GPIO_InitStruct.Pin = PRESSURE_POWER_PD12_Pin;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
	HAL_GPIO_Init(PRESSURE_POWER_PD12_GPIO_Port, &GPIO_InitStruct);
	/*Configure GPIO pin Output Level */
	//HAL_GPIO_WritePin(SENSORS_POWER_PE_GPIO_Port, SENSOR2_POWER_PE1_Pin, GPIO_PIN_RESET);
	Sensors_PowerOn(0x7, GPIO_PIN_RESET);
	
}

void WT_GPIO_Init(void)
{
	//LTE INIT
#ifdef WT_LTE1
	LTE_GPIO_Init();
	LTE_Reset();
	LTE_PowerCycle();
#endif

#ifdef WT_GPS_1PPS
	//GPS_GPIO_Init();
	//GPS_Reset();
#endif
#ifdef WT_USB_CLIENT
	USB_GPIO_Init();
#endif
#ifdef WT_EMMC
	EMMC_GPIO_Init();
#endif
	
//	FM_GPIO_Init();
//	FM_RESET();
	
	Sensor2_GPIO_Init();
	Sensor1_GPIO_Init();
	Pressure_GPIO_Init();
	return;
}
