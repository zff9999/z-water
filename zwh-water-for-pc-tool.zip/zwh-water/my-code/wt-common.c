/**
  ******************************************************************************
  * File Name          : my-common.c
  * Description        : This file provides code for common function
  ******************************************************************************
  * @attention
  *
  *
  *
  ******************************************************************************
  */
  
/* Includes ------------------------------------------------------------------*/
#include "main.h"

#include "stdio.h"
#include "wt-uart.h"
#include "wt-gpio.h"

#define ITM_DEBUG 0
#if ITM_DEBUG == 1
#define ITM_Port8(n)    (*((volatile unsigned char *)(0xE0000000+4*n)))
#define ITM_Port16(n)   (*((volatile unsigned short*)(0xE0000000+4*n)))
#define ITM_Port32(n)   (*((volatile unsigned long *)(0xE0000000+4*n)))

#define DEMCR           (*((volatile unsigned long *)(0xE000EDFC)))
#define TRCENA          0x01000000

struct __FILE { int handle; /* Add whatever you need here */ };
FILE __stdout;
FILE __stdin;

int fputc(int ch, FILE *f) {
  if (DEMCR & TRCENA) {
    while (ITM_Port32(0) == 0);
    ITM_Port8(0) = ch;
  }
  return(ch);
}
#else


int fputc(int ch, FILE *f)
{ 	
	//HAL_NVIC_DisableIRQ(UART4_IRQn);
    while((UART4->ISR&0X40)==0);//ѭ������,ֱ���������
    UART4->TDR = (uint8_t) ch;

//HAL_NVIC_EnableIRQ(UART4_IRQn);
    return ch;
}
#endif


int (* Send_Data_Func)(uint8_t * tx_buf, uint32_t len);
UART_HandleTypeDef * send_port;

//վ����Ϣ

uint8_t g_pcmAmplifier = 1;

WT_Header pkt_header;

//Get building time and show the message when boot system��������������
#define YEAR ((((__DATE__ [7] - '0') * 10 + (__DATE__ [8] - '0')) * 10 \
    + (__DATE__ [9] - '0')) * 10 + (__DATE__ [10] - '0'))

#define MONTH (__DATE__ [2] == 'n' ? (__DATE__ [1] == 'a' ? 0 : 5)  \
    : __DATE__ [2] == 'b' ? 1 \
    : __DATE__ [2] == 'r' ? (__DATE__ [0] == 'M' ? 2 : 3) \
    : __DATE__ [2] == 'y' ? 4 \
    : __DATE__ [2] == 'l' ? 6 \
    : __DATE__ [2] == 'g' ? 7 \
    : __DATE__ [2] == 'p' ? 8 \
    : __DATE__ [2] == 't' ? 9 \
    : __DATE__ [2] == 'v' ? 10 : 11)

#define DAY ((__DATE__ [4] == ' ' ? 0 : __DATE__ [4] - '0') * 10 \
    + (__DATE__ [5] - '0'))

#define DATE_AS_INT (((YEAR - 2000) * 12 + MONTH) * 31 + DAY)

#define VERSION "1.2"
void show_version()
{
    printf("version:%s   \r\n", VERSION);
    printf("build time:%d-%02d-%02d %s\r\n",YEAR, MONTH + 1, DAY, __TIME__);
}

/*****************************************************************************
 * Function      : Set_Pkt_Header
 * Description   : ��ʼ����Ϣͷ��
 * Input         : WT_Header * hdr_ptr  
                char * timestr       	ʱ�䴮
                uint8_t MsgID        ��Ϣ��ID
                uint32_t data_Size   ���ݳ���
 * Output        : None
 * Return        : 
 * Others        : 
 * Record
 * 1.Date        : 20201211
 *   Author      : zhangwh
 *   Modification: Created function

*****************************************************************************/
void Set_Pkt_Header(WT_Header * hdr_ptr, char * timestr, uint8_t MsgID, uint32_t data_Size)
{
	//WT_Header * hdr_ptr = &header;
	
	sprintf((char *)(hdr_ptr->magic), "XXXX");		
	sprintf((char *)(hdr_ptr->end), "XX");
	snprintf((char *)(hdr_ptr->time), 13, "%s", timestr);
	snprintf((char *)(hdr_ptr->station), 5, "ST%02d", g_StationID);	
	sprintf((char *)(hdr_ptr->msgType), "%02d", MsgID);
	hdr_ptr->len = data_Size;
}

/*****************************************************************************
 * Function      : Send_Header
 * Description   : �������ݱ�ͷ
 * Input         : uint8_t MsgID       
                uint32_t data_Size  
 * Output        : None
 * Return        : 
 * Others        : 
 * Record
 * 1.Date        : 20201211
 *   Author      : zhangwh
 *   Modification: Created function

*****************************************************************************/
void Send_Header(uint8_t MsgID, uint32_t data_Size)
{
	char timest[13];
	WT_RTC_GetTime(timest);
	Set_Pkt_Header(&pkt_header, timest, MsgID, data_Size);
	printf("header == %s", (uint8_t *)&pkt_header);
	Send_Data_Func((uint8_t *)&pkt_header, sizeof(pkt_header));
	return;
}

void Send_Header_With_Time(uint8_t MsgID, uint32_t data_Size, char * timest)
{
	Set_Pkt_Header(&pkt_header, timest, MsgID, data_Size);
	printf("header == %s", (uint8_t *)&pkt_header);
	Send_Data_Func((uint8_t *)&pkt_header, sizeof(pkt_header));
	return;
}

	
#define GAIN_DEGRADE(a) (~((a << 1) - 1) & 0xff)
#define GAIN_INGRADE(a) ((a) << 1)

//After power on, need to read setting for module
WT_Module_Info module_info;
uint8_t g_StationID = 41;

#ifdef STATION_SETTING_V2
/*************************************************************
�µ�վ�����ó�ʼ������
**************************************************************/
const uint32_t g_setting_address = (FLASH_BANK1_END + 1) - FLASH_PAGE_SIZE;;


WT_Station_Setting stn_setting;

/*****************************************************************************
 * Function      : wt_read_setting
 * Description   : ��flash���ж�ȡվ��������Ϣ
 * Input         : WT_Station_Setting * stn_info  
 * Output        : None
 * Return        : 
 * Others        : 
 * Record
 * 1.Date        : 20201211
 *   Author      : zhangwh
 *   Modification: Created function

*****************************************************************************/
void wt_read_setting(WT_Station_Setting * stn_info){
	WT_Station_Setting *ptr = (WT_Station_Setting *)g_setting_address;
	memcpy(stn_info, ptr, sizeof(WT_Station_Setting));
	return;
//	stn_info->stn_id =  ptr->stn_id;
//  strcpy(stn_info->stn_name, stn_info->stn_name);
//  strcpy(stn_info->stm32_id, stn_info->stm32_id);
//  stn_info->jinDu = stn_info->jinDu;
//  stn_info->jinFen = stn_info->jinFen;
//  stn_info->weiDu = stn_info->weiDu;
//  stn_info->weiFen = stn_info->weiFen;
//  memset(stn_info->dev.comm_id, 0, sizeof(stn_info->dev.comm_id));
//  strcpy(stn_info->dev.comm_id , stn_info->dev.comm_id);
//  memset(stn_info->dev.hydro_id, 0, sizeof(stn_info->dev.hydro_id));
//  strcpy(stn_info->dev.hydro_id , stn_info->dev.hydro_id);
//  memset(stn_info->dev.pressure_id, 0, sizeof(stn_info->dev.pressure_id));
//  strcpy(stn_info->dev.pressure_id , stn_info->dev.pressure_id);
//  memset(stn_info->dev.sensor2_id, 0, sizeof(stn_info->dev.sensor2_id));
//  strcpy(stn_info->dev.sensor2_id , stn_info->dev.sensor2_id);
//  memset(stn_info->dev.sensor3_id, 0, sizeof(stn_info->dev.sensor3_id));
//  strcpy(stn_info->dev.sensor3_id , stn_info->dev.sensor3_id);
//  memset(stn_info->dev.sensor4_id, 0, sizeof(stn_info->dev.sensor4_id));
//  strcpy(stn_info->dev.sensor4_id , stn_info->dev.sensor4_id);
//  stn_info->setting.hydro_sample_interval = stn_info->setting.hydro_sample_interval;
//  stn_info->setting.pressure_sample_interval = stn_info->setting.pressure_sample_interval;
//  stn_info->setting.sensors_sample_interval = stn_info->setting.sensors_sample_interval;
//  stn_info->setting.sensors_sample_interval = stn_info->setting.sensors_sample_interval;
//  stn_info->setting.sensors_sample_interval = stn_info->setting.sensors_sample_interval;
//  stn_info->setting.sensors_send_interval = stn_info->setting.sensors_send_interval;
//  stn_info->setting.sensors_send_interval = stn_info->setting.sensors_send_interval;
//  stn_info->setting.hydro_gain = stn_info->setting.hydro_gain;
//  stn_info->setting.HYDRO_sample_rate = stn_info->setting.HYDRO_sample_rate;
//  stn_info->setting.hydro_sample_length = stn_info->setting.hydro_sample_length;
	
}

/*****************************************************************************
 * Function      : wt_save_setting
 * Description   : ����վ�����õ�flash��
 * Input         : const WT_Station_Setting * stn_info  
 * Output        : None
 * Return        : 
 * Others        : 
 * Record
 * 1.Date        : 20201211
 *   Author      : zhangwh
 *   Modification: Created function

*****************************************************************************/
void wt_save_setting(const WT_Station_Setting * stn_info)
{
	flash_status_t st;
	//first erase the page 
	if(Flash_If_Erase_Pages(g_setting_address, 1) != FLASH_OK)
		return;
	//write data into page
	st = Flash_If_Write((uint8_t *)stn_info, (uint8_t*)g_setting_address, 
				sizeof(WT_Station_Setting));
	return;
	
}

#else

#endif




void WT_Init_Setting_ID(uint8_t stID) {
	g_StationID = stID;
	snprintf((char *)(module_info.station), 5, "ST%02d", g_StationID);			
	printf("!!!!!Set Station Name == %s\r\n", (uint8_t *)module_info.station);
	module_info.pcmAmplifier = 0;
	module_info.HYDRO_sample = 30; 			//minutes
	module_info.pressure_sample = 1;
	module_info.sensors_sample = 15; 		//sec
	module_info.send_data_interval = 5; //minut
	module_info.rtc_sync_time = 7; 			//8 clock
	module_info.lte_Port = 8801;
	WT_Get_STM_ID();
	printf("!!!!!HYDRO_sample == %d\r\n", module_info.HYDRO_sample);
	printf("!!!!!pressure_sample == %d\r\n", module_info.pressure_sample);
	printf("!!!!!sensors_sample == %d\r\n", module_info.sensors_sample);
	printf("!!!!!send_data_interval == %d\r\n", module_info.send_data_interval);
	printf("!!!!!rtc_sync_time == %d\r\n", module_info.rtc_sync_time);
	return ;	
}

//��ȡSTM32 L4ΨһID: 12 
void WT_Get_STM_ID(void)
{
    uint8_t* temp = module_info.stm32_id;
    uint32_t temp0,temp1,temp2;
    temp0=*(__IO uint32_t*)(ID_ADDR1); //��ƷΨһ���ݱ�ʶ�Ĵ�����96λ��
    temp1=*(__IO uint32_t*)(ID_ADDR1+4);
    temp2=*(__IO uint32_t*)(ID_ADDR1+8);
    temp[0] = (uint8_t)(temp0 & 0x000000FF);
    temp[1] = (uint8_t)((temp0 & 0x0000FF00)>>8);
    temp[2] = (uint8_t)((temp0 & 0x00FF0000)>>16);
    temp[3] = (uint8_t)((temp0 & 0xFF000000)>>24);
    temp[4] = (uint8_t)(temp1 & 0x000000FF);
    temp[5] = (uint8_t)((temp1 & 0x0000FF00)>>8);
    temp[6] = (uint8_t)((temp1 & 0x00FF0000)>>16);
    temp[7] = (uint8_t)((temp1 & 0xFF000000)>>24);
    temp[8] = (uint8_t)(temp2 & 0x000000FF);
    temp[9] = (uint8_t)((temp2 & 0x0000FF00)>>8);  
    temp[10] = (uint8_t)((temp2 & 0x00FF0000)>>16);
    temp[11] = (uint8_t)((temp2 & 0xFF000000)>>24);
		printf("ID: %.2X%.2X%.2X%.2X%.2X%.2X%.2X%.2X%.2X%.2X%.2X%.2X",
						temp[0],temp[1],temp[2],temp[3],temp[4],temp[5],
						temp[6],temp[7],temp[8],temp[9],temp[10],temp [11]);
    return;
}
