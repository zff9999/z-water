/*
 * Texas Instruments PCM186x Universal Audio ADC
 *
 * Copyright (C) 2015-2017 Texas Instruments Incorporated - http://www.ti.com
 *	Andreas Dannenberg <dannenberg@ti.com>
 *	Andrew F. Davis <afd@ti.com>
 */
#include "pcm186x.h"
#include "wt-common.h"

//the value of input channel sel [0-5]; 
//used by register: ADC1 0x6 and 0x7; adc2 0x8 and 0x9
static const unsigned int pcm186x_adc_input_channel_sel_value[] = {
	0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07,
	0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f,
	0x10, 0x20, 0x30
};

//����ͨ������
enum { IN_NO, 
			IN_L1, 
			IN_L2, IN_L12, 
			IN_L3, IN_L31, IN_L32, IN_L321,
			IN_L4, IN_L41, IN_L42, IN_L421, IN_L43, IN_L431, IN_L432, IN_L4321,
			IN_1PM, IN_4PM, IN_1PM_4PM 
};

static char * pcm186x_adcl_input_channel_sel_text[] = {
	"No Select",
	"VINL1[SE]",					/* Default for ADC1L */
	"VINL2[SE]",					/* Default for ADC2L */
	"VINL2[SE] + VINL1[SE]",
	"VINL3[SE]",
	"VINL3[SE] + VINL1[SE]",
	"VINL3[SE] + VINL2[SE]",
	"VINL3[SE] + VINL2[SE] + VINL1[SE]",
	"VINL4[SE]",
	"VINL4[SE] + VINL1[SE]",
	"VINL4[SE] + VINL2[SE]",
	"VINL4[SE] + VINL2[SE] + VINL1[SE]",
	"VINL4[SE] + VINL3[SE]",
	"VINL4[SE] + VINL3[SE] + VINL1[SE]",
	"VINL4[SE] + VINL3[SE] + VINL2[SE]",
	"VINL4[SE] + VINL3[SE] + VINL2[SE] + VINL1[SE]",
	"{VIN1P, VIN1M}[DIFF]",
	"{VIN4P, VIN4M}[DIFF]",
	"{VIN1P, VIN1M}[DIFF] + {VIN4P, VIN4M}[DIFF]"
};

static char * pcm186x_adcr_input_channel_sel_text[] = {
	"No Select",
	"VINR1[SE]",					/* Default for ADC1R */
	"VINR2[SE]",					/* Default for ADC2R */
	"VINR2[SE] + VINR1[SE]",
	"VINR3[SE]",
	"VINR3[SE] + VINR1[SE]",
	"VINR3[SE] + VINR2[SE]",
	"VINR3[SE] + VINR2[SE] + VINR1[SE]",
	"VINR4[SE]",
	"VINR4[SE] + VINR1[SE]",
	"VINR4[SE] + VINR2[SE]",
	"VINR4[SE] + VINR2[SE] + VINR1[SE]",
	"VINR4[SE] + VINR3[SE]",
	"VINR4[SE] + VINR3[SE] + VINR1[SE]",
	"VINR4[SE] + VINR3[SE] + VINR2[SE]",
	"VINR4[SE] + VINR3[SE] + VINR2[SE] + VINR1[SE]",
	"{VIN2P, VIN2M}[DIFF]",
	"{VIN3P, VIN3M}[DIFF]",
	"{VIN2P, VIN2M}[DIFF] + {VIN3P, VIN3M}[DIFF]"
};
//���ڶ����Ƿ�ʹ���˷Ŵ��·�������ϵ�����������
//#define AMPLIFY_SIGNAL 1

// 8bit slv addr
uint8_t pcm186x_addr = 0x4A << 1;

//I2C��handler������дcodec�Ĵ���
extern I2C_HandleTypeDef hi2c1;
I2C_HandleTypeDef *phi2c = &hi2c1;


//д�Ĵ���
uint8_t pcm186x_write_reg(uint16_t reg, uint8_t data)
{
  //uint8_t re;
	HAL_Delay(10);
	//printf("scan_pcm1862\n");    

	// set page
	uint8_t page = reg >> 8;
	if(HAL_I2C_Mem_Write(phi2c, pcm186x_addr, PCM186X_PAGE, I2C_MEMADD_SIZE_8BIT, &page, 1, 0x10) != HAL_OK)
	{
		//printf("\r\nSelect page ERROR ===>0x%x\r\n", 0);
		return HAL_ERROR;
	}
	
	if ((reg & 0xff) == 0)
		return HAL_OK;
	if(HAL_I2C_Mem_Write(phi2c, pcm186x_addr, reg & 0xff, I2C_MEMADD_SIZE_8BIT, &data, 1, 0x10) != HAL_OK)
	{
		//printf("\r\nWrite page ERROR ===>0x%x\r\n", reg & 0xff);
		return HAL_ERROR;
	}
	HAL_Delay(10);

	return HAL_OK;
}

//�Ĵ����������޸ļĴ���
uint8_t pcm186x_update_reg(uint16_t reg, uint8_t mask, uint8_t val)
{
  //uint8_t re;
	uint8_t temp = 0x0;
	HAL_Delay(10);
	//printf("scan_pcm1862\n");    

	// set page
	uint8_t page = reg >> 8;
	if(HAL_I2C_Mem_Write(phi2c, pcm186x_addr, PCM186X_PAGE, I2C_MEMADD_SIZE_8BIT, &page, 1, 0x10) != HAL_OK)
	{
		//printf("\r\nSelect page ERROR ===>0x%x\r\n", page);
		return HAL_ERROR;
	}
	//re = HAL_I2C_Mem_Read(&hi2c1, (0x4A << 1)+1 , i, I2C_MEMADD_SIZE_8BIT, data, 1, 0xff);
	if(HAL_I2C_Mem_Read(phi2c, pcm186x_addr, reg & 0xff, I2C_MEMADD_SIZE_8BIT, &temp, 1, 0x10) != HAL_OK)
	{
		//printf("\r\nRead page ERROR ===>0x%x\r\n", reg & 0xff);
		return HAL_ERROR;
	}
	temp = temp & ~(mask);
	temp = temp | val;
	if(HAL_I2C_Mem_Write(phi2c, pcm186x_addr, reg & 0xff, I2C_MEMADD_SIZE_8BIT, &temp, 1, 0x10) != HAL_OK)
	{
		//printf("\r\nWrite page ERROR ===>0x%x\r\n", reg & 0xff);
		return HAL_ERROR;
	}
	HAL_Delay(10);

	return HAL_OK;
}


uint8_t pcm186x_read_reg(uint16_t reg, uint8_t * data)
{
  //uint8_t re;
	HAL_Delay(10);
	//printf("scan_pcm1862\n");    

	// set page
	uint8_t page = reg >> 8;
	if(HAL_I2C_Mem_Write(phi2c, pcm186x_addr, PCM186X_PAGE, I2C_MEMADD_SIZE_8BIT, &page, 1, 0x10) != HAL_OK)
	{
		//printf("\r\nSelect page ERROR ===>0x%x\r\n", page);
		return HAL_ERROR;
	}
	//re = HAL_I2C_Mem_Read(&hi2c1, (0x4A << 1)+1 , i, I2C_MEMADD_SIZE_8BIT, data, 1, 0xff);
	if(HAL_I2C_Mem_Read(phi2c, pcm186x_addr, reg & 0xff, I2C_MEMADD_SIZE_8BIT, data, 1, 0x10) != HAL_OK)
	{
		//printf("\r\nRead page ERROR ===>0x%x\r\n", reg & 0xff);
		return HAL_ERROR;
	}
	HAL_Delay(10);
	
	return HAL_OK;
}

///////////////////////////////////////////////////////////////////////////
// ������
///////////////////////////////////////////////////////////////////////////
//����codec������ʼ��
int pcm186x_set_clk(void)
{
	uint8_t clk_ctrl = 0;
	//uint8_t pcm_cfg = 0;

	//dev_dbg(component->dev, "%s() format=0x%x\n", __func__, format);

	/* set master/slave audio interface */
	//master mode clock
	//operating in master mode requires sysclock to be configured
		clk_ctrl = PCM186X_CLK_CTRL_SCK_XI_SEL0 	| PCM186X_CLK_CTRL_CLKDET_EN;
	//		priv->is_master_mode = true;


	/* set interface polarity */
	//switch (format & SND_SOC_DAIFMT_INV_MASK) {


	/* set interface format */
	//switch (format & SND_SOC_DAIFMT_FORMAT_MASK) {
	//case SND_SOC_DAIFMT_I2S:
	//case SND_SOC_DAIFMT_LEFT_J:   
	//left justified!!!!
		//pcm_cfg = PCM186X_PCM_CFG_FMT_LEFTJ;


	pcm186x_update_reg(PCM186X_CLK_CTRL, PCM186X_CLK_CTRL_MST_MODE |
											PCM186X_CLK_CTRL_SCK_XI_SEL1 | PCM186X_CLK_CTRL_SCK_XI_SEL0 |
											PCM186X_CLK_CTRL_CLKDET_EN, clk_ctrl);

	//pcm186x_write_reg(PCM186X_TDM_TX_OFFSET, priv->tdm_offset);

	//pcm186x_update_reg(PCM186X_PCM_CFG, PCM186X_PCM_CFG_FMT_MASK, pcm_cfg);

	return 0;
}

//����codec�����ݿ����Լ����ݸ�ʽ
static int pcm186x_hw_params(unsigned int width, uint8_t fmt)
{
	//unsigned int div_lrck;
	//unsigned int div_bck;
	//u8 tdm_tx_sel = 0;
	uint8_t pcm_cfg = 0;

	pcm_cfg = fmt; //PCM186X_PCM_CFG_FMT_I2S;
	//printf("%s() rate=%u format=0x%x width=%u channels=%u\n",
	//	__func__, rate, format, width, channels);

	switch (width) {
	case 16:
		pcm_cfg = PCM186X_PCM_CFG_RX_WLEN_16 <<
			  PCM186X_PCM_CFG_RX_WLEN_SHIFT |
			  PCM186X_PCM_CFG_TX_WLEN_16 <<
			  PCM186X_PCM_CFG_TX_WLEN_SHIFT;
		break;
	case 20:
		pcm_cfg = PCM186X_PCM_CFG_RX_WLEN_20 <<
			  PCM186X_PCM_CFG_RX_WLEN_SHIFT |
			  PCM186X_PCM_CFG_TX_WLEN_20 <<
			  PCM186X_PCM_CFG_TX_WLEN_SHIFT;
		break;
	case 24:
		pcm_cfg = PCM186X_PCM_CFG_RX_WLEN_24 <<
			  PCM186X_PCM_CFG_RX_WLEN_SHIFT |
			  PCM186X_PCM_CFG_TX_WLEN_24 <<
			  PCM186X_PCM_CFG_TX_WLEN_SHIFT;
		break;
	case 32:
		pcm_cfg = PCM186X_PCM_CFG_RX_WLEN_32 <<
			  PCM186X_PCM_CFG_RX_WLEN_SHIFT |
			  PCM186X_PCM_CFG_TX_WLEN_32 <<
			  PCM186X_PCM_CFG_TX_WLEN_SHIFT;
		break;
	default:
		return HAL_ERROR;
	}

	pcm_cfg = pcm_cfg | fmt;
	
	pcm186x_update_reg(PCM186X_PCM_CFG,
			    PCM186X_PCM_CFG_RX_WLEN_MASK |
			    PCM186X_PCM_CFG_TX_WLEN_MASK |
			    PCM186X_PCM_CFG_FMT_MASK,
			    pcm_cfg);

	return 0;
}


static int pcm186x_set_ctrl(void)
{
	uint8_t pcm_ctrl = 0;

	pcm_ctrl = PCM186X_PGA_CTRL_SMOOTH | PCM186X_PGA_CTRL_DPGA_CLIP_EN |
							PCM186X_PGA_CTRL_START_ATT_MASK;
	//PCM186X_PGA_CTRL_START_ATT_MASK | PCM186X_PGA_CTRL_AGC_EN;
	printf("PCM186X_PGA_CTRL_SMOOTH:0x%x\r\n", PCM186X_PGA_CTRL_SMOOTH);
	printf("PCM186X_PGA_CTRL_START_ATT_MASK:0x%x\r\n", PCM186X_PGA_CTRL_START_ATT_MASK);
	printf("====>pcm_ctrl 0x%x ==> 0x%x \r\n", pcm_ctrl, PCM186X_PGA_CTRL);
	pcm186x_write_reg(PCM186X_PGA_CTRL, pcm_ctrl);
	
	return 0;
}


static int pcm_select_input(uint8_t lrchannel, uint8_t index)
{
	uint16_t reg = 0;
	char * str = 0;
	uint8_t data = 0;
	if (lrchannel == 1){		//left channel
		reg = PCM186X_ADC1_INPUT_SEL_L;
		str = pcm186x_adcl_input_channel_sel_text[index];
		data = pcm186x_adc_input_channel_sel_value[index];
	}
	else if (lrchannel == 2){	//right chaneel
		reg = PCM186X_ADC1_INPUT_SEL_R;
		str = pcm186x_adcr_input_channel_sel_text[index];
		data = pcm186x_adc_input_channel_sel_value[index];
	}
	data = data | BIT(6);
	printf("Select [%s] reg:[0x%x] with [0x%x]\r\n", str, reg, data);

	pcm186x_write_reg(reg, data);
		return 0;
}


static int pcm186x_power_on_off(uint8_t onoff)
{
	if (onoff == 1)
		pcm186x_update_reg(PCM186X_POWER_CTRL, PCM186X_PWR_CTRL_PWRDN, 0);
	else
		pcm186x_update_reg(PCM186X_POWER_CTRL, PCM186X_PWR_CTRL_PWRDN, PCM186X_PWR_CTRL_PWRDN);
	return 0;
}

//��ʼ����ԴGPIO
void HYDRO_GPIO_Init(void)
{
	//PE0   ------> OUTPUT
	GPIO_InitTypeDef GPIO_InitStruct = {0};
  GPIO_InitStruct.Pin = HYD_POWER_EN_PE0_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
  HAL_GPIO_Init(HYD_POWER_EN_PE0_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : PtPin */
  GPIO_InitStruct.Pin = HYD_POWER_ST_PB5_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
  HAL_GPIO_Init(HYD_POWER_ST_PB5_GPIO_Port, &GPIO_InitStruct);
	
	HAL_GPIO_WritePin(HYD_POWER_EN_PE0_GPIO_Port, HYD_POWER_EN_PE0_Pin, GPIO_PIN_RESET);
}

void HYDRO_POWER_ONOFF(uint8_t onoff)
{
	if (onoff == 1)
			HAL_GPIO_WritePin(HYD_POWER_EN_PE0_GPIO_Port, HYD_POWER_EN_PE0_Pin, GPIO_PIN_SET);
	else
			HAL_GPIO_WritePin(HYD_POWER_EN_PE0_GPIO_Port, HYD_POWER_EN_PE0_Pin, GPIO_PIN_RESET);
}

void PCM186X_DPGA_Gain_Manual_Enable(uint8_t enable)
{
	uint16_t reg = PCM186X_DPGA_GAIN_CTRL;
	uint8_t data = PCM186X_DPGA_GAIN_CTRL_DCH1_R |
									PCM186X_DPGA_GAIN_CTRL_DCH1_L | 
									PCM186X_DPGA_GAIN_CTRL_ACH1_R |
									PCM186X_DPGA_GAIN_CTRL_ACH1_L;
	if(enable == 1)	
		//manual gain
		pcm186x_update_reg(reg, data, data);
	else
		//auto gain!!!!
		pcm186x_update_reg(reg, data, 0);
	return;

}

//����mixer���μ��ֲ�
void pcm186x_set_mixer(uint32_t val)
{
	uint8_t data;
	//switch to page1
	pcm186x_write_reg(0x100, 0x0);
	pcm186x_write_reg(0x100, 0x0);
	pcm186x_read_reg(0x100, &data);
	printf("page: %x\r\n", data);
	printf("Write data 0x%08x to 0x%x\r\n", (val >> 8), (val & 0xff));
	//set vir address
	pcm186x_write_reg(0x102, val & 0xff);
	//write data to vir address
	pcm186x_write_reg(0x104, (val >> 24) & 0xff);
	pcm186x_write_reg(0x105, (val >> 16) & 0xff);
	pcm186x_write_reg(0x106, (val >> 8) & 0xff);
	//exe write op
	pcm186x_write_reg(0x101, 0x1);
	HAL_Delay(10);
	printf("%s ===Done\n", __FUNCTION__);
	
}

//��ȡmixer�����ã�
void pcm186x_get_mixer(uint8_t reg)
{
	uint8_t data;
	//printf("%s ===Start: 0x%x\r\n", __FUNCTION__, reg);
	//switch to page1
	pcm186x_write_reg(0x100, 0x0);
	pcm186x_write_reg(0x100, 0x0);
	pcm186x_read_reg(0x100, &data);
	//printf("page: %x\r\n", data);

	//set vir address
	pcm186x_write_reg(0x102, reg & 0xff);

	//exe read op
	pcm186x_write_reg(0x101, 0x2);
	HAL_Delay(10);
	//write data to vir address
	pcm186x_read_reg(0x108, &data);
	//printf("0x108: %02x-", data);
	pcm186x_read_reg(0x109, &data);
	//printf("-%02x", data);
	pcm186x_read_reg(0x10a, &data);
	//printf("-%02x\r\n", data);
	//printf("%s ===Done\n", __FUNCTION__);
	
}

//#define MIXER_VAL(r, v1, v2, v3) ( (r) & 0xff) | (v1 & 0xff) << 8 | (v2 & 0xff) << 16 | (v2 & 0xff) << 24
//[V3][V2][V1][REG]
void pcm186x_set_dout(void)
{
	//mixer1
	pcm186x_set_mixer(0x7f17af00);	//MIXER1 CH1L 18DB
	pcm186x_set_mixer(0x00000101);
	pcm186x_set_mixer(0x00000104);
	pcm186x_set_mixer(0x00000105);
	//mixer2
	pcm186x_set_mixer(0x00000106);
	pcm186x_set_mixer(0x00000107);
	pcm186x_set_mixer(0x0000010A);
	pcm186x_set_mixer(0x0000010B);
	
		//Energ sense TH
	pcm186x_set_mixer(0x0147AE2D);
	pcm186x_set_mixer(0x0003462C);
}

void pcm186x_get_dout(uint8_t reg)
{
	//mixer1
	pcm186x_set_mixer(0x10000000);
	pcm186x_set_mixer(0x00000A01);
	pcm186x_set_mixer(0x00000A04);
	pcm186x_set_mixer(0x00000A05);
	//mixer2
	pcm186x_set_mixer(0x00000A06);
	pcm186x_set_mixer(0x10000007);
	pcm186x_set_mixer(0x00000A0A);
	pcm186x_set_mixer(0x00000A0B);
	
		//Energ sense TH
	pcm186x_set_mixer(0x0147AE2D);
	pcm186x_set_mixer(0x0003462C);
}


void pcm186x_set_gain(uint8_t ch, uint8_t val)
{
	uint8_t reg = PCM186X_PGA_VAL_CH1_L + ch;
	uint8_t data;
	pcm186x_write_reg(reg, val);
	printf("reg[0x%x]::::[0x%x]  ", reg, val);
	pcm186x_read_reg(reg , &data);
	printf("reg[0x%x]::::[0x%x]  ", reg, data);
}

void pcm186x_mute_channel(uint8_t ch, uint8_t on)
{
	uint16_t reg = PCM186X_FILTER_MUTE_CTRL;
	uint8_t mask = PCM186X_FILTER_MUTE_CTRL_CH(ch);
	uint8_t val = PCM186X_FILTER_MUTE_CTRL_CH(ch);
	if (on == 0)
		val = 0;
	pcm186x_update_reg(reg, mask, val);
	return;
}

void Check_reg_val(void)
{
	uint16_t reg[] = {PCM186X_MEM_RDATA0, PCM186X_MEM_RDATA1, PCM186X_MEM_RDATA2, PCM186X_MEM_RDATA3,0xff};
	uint8_t i = 0;
	uint8_t data;
	while(1){
		if (reg[i] == 0xff)
			break;
		pcm186x_read_reg(reg[i] , &data);
		printf("reg[0x%x]::::[0x%x]  ", reg[i], data);
		i++;
		if (i % 4 == 0)
			printf("\r\n");
		}
	printf("\r\n");
	return;
}

void set_gain(void)
{
	static uint8_t gain = 0;
	
	pcm186x_set_gain(CH1L, gain);

	printf("!!!!!!Set Gain:0x%x!!!!!!!\r\n", gain);
	gain++;
	if(gain > 0x50)
		gain = 0x0;
	
}

void pcm186x_dump_status(void)
{
	uint16_t reg = PCM186X_DEVICE_STATUS;
	uint8_t data = 0;
	uint8_t i =0;

	//set_gain();
	printf("\n===DUMP REGS====\n");
	for(i = 0; i <= 4; i++){
		pcm186x_read_reg(reg + i , &data);
		printf("reg[0x%x]::::[0x%x]  ", reg+i, data);
	}
	printf("================\r\n");

	Check_reg_val();
	return;
}
//CODEC��ʼ��
void pcm186x_init(void)
{
	pcm186x_set_ctrl();
	pcm186x_set_dout();
	pcm_select_input(1, IN_L1); 
	pcm_select_input(2, IN_L43); 
	PCM186X_DPGA_Gain_Manual_Enable(1);
	pcm186x_hw_params(16, PCM186X_PCM_CFG_FMT_LEFTJ);
	pcm186x_set_clk();
	
}


#define DEGRADE(a) (~((a << 1) - 1) & 0xff)
#define INGRADE(a) ((a) << 1)

extern WT_Module_Info module_info;

#ifdef AMPLIFY_SIGNAL
#define PCM_GAIN DEGRADE(12)		//-12db
#else
#define PCM_GAIN INGRADE(30)		//30db
#endif
/*****************************************************************************
 * Function      : pcm_init
 * Description   : ��ʼ��pcm1862������ͨ��������
 //���������С(0-40dB),��Ӧ�ļĴ���ֵΪ*2
 //(-12dB-0) ��Ӧ��ֵ��~(0-24)
 //û�зŴ��·���þ���������棬�зŴ��·��ʹ��С����
 * Input         : void  
 * Output        : None
 * Return        : 
 * Others        : 
 * Record
 * 1.Date        : 20200707
 *   Author      : zhangwh
 *   Modification: Created function

*****************************************************************************/
void pcm_init(void)
{
	uint8_t vGain = PCM_GAIN;
	HYDRO_GPIO_Init();
	HYDRO_POWER_ONOFF(1);
	pcm186x_init();
	pcm186x_mute_channel(CH1L,0);
	pcm186x_mute_channel(CH1R,1);
	pcm186x_mute_channel(CH2L,1);
	pcm186x_mute_channel(CH2R,1);
	if(module_info.pcmAmplifier == 1){
		vGain = DEGRADE(12);
		printf("=====!!!!! PCM: USING AMPLIFY CIRCUIT!!!!!======\r\n");
		}
	else{
		vGain = INGRADE(30);
		printf("=====!!!!! PCM: USING GENERAL CIRCUIT!!!!!======\r\n");
	}
	printf("=PCM GAIN==========>>>>%x\r\n", vGain);
	pcm186x_set_gain(CH1L, vGain);
	pcm186x_set_gain(CH1R, 0);
}

void pcm_reg_test(void)
{
#if DEBUG_MODE == 1
	uint16_t reg = PCM186X_PGA_VAL_CH1_L;
	uint8_t data = 0;
	uint8_t re = 0;
	printf("\r\n===PCM1862 REGS====\r\n");
	for(uint8_t i = 0; i <= 0x8f; i++)
	{
		pcm186x_read_reg(reg + i, &data);
			if ( i % 8 == 0)
				printf("\r\n");
			if(re == HAL_OK)
				printf("[%04x 0x%02x]", reg + i, data);         
			else 
				printf(".");
	}
	reg = PCM186X_PAGE_BASE(1);
	printf("\r\nFrom: 0x%0x\r\n", reg);
	for(uint8_t i = 1; i <= 11; i++)
	{
		pcm186x_read_reg(reg + i, &data);
			if ( i % 8 == 0)
				printf("\r\n");
			if(re == HAL_OK)
				printf("[%04x 0x%02x]", reg + i, data);         
			else 
				printf(".");
	}
	
	reg = PCM186X_OSC_PWR_DOWN_CTRL;
	printf("\r\nFrom: 0x%0x\r\n", reg);
	pcm186x_read_reg(reg , &data);
	printf("[%04x 0x%02x] ", reg, data);
	reg = PCM186X_MIC_BIAS_CTRL;	
	pcm186x_read_reg(reg , &data);
	printf("[%04x 0x%02x]", reg, data);

	reg = PCM186X_CURR_TRIM_CTRL;
	pcm186x_read_reg(reg, &data);
	printf("\r\nFrom: 0x%0x\r\n", reg);
	printf("[%04x 0x%02x]", reg, data);
	printf("\r\n");
	
	pcm186x_get_mixer(0x00);
	pcm186x_get_mixer(0x2d);
#endif
	return;
}


