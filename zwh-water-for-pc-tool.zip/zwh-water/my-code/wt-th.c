/**
  ******************************************************************************
  * File Name          : wt-th.c
  * Description        : This file provides code for temp and hum module
  *                      
	******************************************************************************
 *
 **/
//#include "wt-th.h"
#include "wt-common.h"
#include "i2c.h"

static uint8_t th_slave = 0x40;
static uint8_t th_reg[32];  

void Hdc_GPIO_Init(void)
{
  /*Configure GPIO pin : OUTPUT */
	GPIO_InitTypeDef GPIO_InitStruct = {0};

  GPIO_InitStruct.Pin = TH_POWER_PE1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
  HAL_GPIO_Init(TH_POWER_PE1_GPIO_Port, &GPIO_InitStruct);
	
	HAL_GPIO_WritePin(TH_POWER_PE1_GPIO_Port, TH_POWER_PE1_Pin, GPIO_PIN_SET);

  /*Configure GPIO pin : PtPin */
  GPIO_InitStruct.Pin = TH_INT_PD13_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  HAL_GPIO_Init(TH_INT_PD13_GPIO_Port, &GPIO_InitStruct);
  /* EXTI interrupt init*/
	// for PD13 interrupt
  HAL_NVIC_SetPriority(EXTI15_10_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI15_10_IRQn);

	return;
}

static void Hdc_Power(uint8_t onOff)
{
	if (onOff == 1)
		HAL_GPIO_WritePin(TH_POWER_PE1_GPIO_Port, TH_POWER_PE1_Pin, GPIO_PIN_SET);
	else
		HAL_GPIO_WritePin(TH_POWER_PE1_GPIO_Port, TH_POWER_PE1_Pin, GPIO_PIN_RESET);
}

static uint8_t Hdc_I2C_Read(uint8_t reg, uint8_t *data)
{
	uint8_t re = HAL_OK;
	re = HAL_I2C_Mem_Read(&hi2c2, th_slave << 1 , reg, I2C_MEMADD_SIZE_8BIT, data, 1, 0xff);
	if (re != HAL_OK) {
		printf("%s:: 0x%x [0x%x] ERROR!!\n", __FUNCTION__, reg, th_slave << 1);
		return HAL_ERROR;
	}
	return HAL_OK;
}


//the code is OK!!!!!!!
static uint8_t Hdc_I2C_Write(uint16_t reg, uint8_t data)
{
	// set page
	printf("%s  [0x%x] 0x%x 0x%x \n", __FUNCTION__, th_slave << 1, reg, data);
	if(HAL_I2C_Mem_Write(&hi2c2, th_slave << 1, reg, I2C_MEMADD_SIZE_8BIT, &data, 1, 0x10) != HAL_OK)
	{
		printf("\r\nWrite ERROR ===>0x%x\r\n", reg);
		return HAL_ERROR;
	}
	HAL_Delay(10);

	return HAL_OK;
}

uint16_t Hdc_reg_read_test(uint8_t reg, uint16_t *data)
{
	if (HAL_I2C_Master_Receive(&hi2c2, th_slave, th_reg, 32, 1000) != HAL_OK) {
		return HAL_ERROR;
	}
	//Dump_Fm_Regs(th_reg);
	return HAL_OK;
}

/****************************************************
* �� �� ��: Hdc_Init(void)()
* ��������: HDC2010��ʼ��
* ��ڲ���: void
* ��    ��: viod
****************************************************/
void Hdc_Init(void)
{
  u8 data = 0x57;
  Hdc_I2C_Write(0x0e,data);       //HDC�����ж�ʹ��
	data = 0xf8;
  Hdc_I2C_Write(0x07,data);       //�������ж�
	data = 1;
  Hdc_I2C_Write(0x0f,data);       //HDC��������,��ʼ����
  printf("HDC2010��ʼ�����\n");
}

/****************************************************
* �� �� ��: Hdc_Gettemperature()
* ��������: ��HDC2010��ȡ�¶���Ϣ
* ��ڲ���: void
* ��    ��: viod
****************************************************/
u32 Hdc_Gettemperature(void)
{
  u8 tlow=0,thigh=0;
  u16 ttemp=0;
  u32 temp=0;
  Hdc_I2C_Read(0x00, &tlow);     //��ȡ�¶ȵ�8λ����
  Hdc_I2C_Read(0x01, &thigh);    //��ȡ�¶ȸ�8λ����
  ttemp=(thigh << 8) | tlow;      //���¶ȸߵ�λ�ϳ�
  temp=((ttemp*165)/65536)-40;      //�����¶�ֵ
  return temp;
}


/****************************************************
* �� �� ��: Hdc_Gethumidity()
* ��������: ��HDC2010��ȡʪ����Ϣ
* ��ڲ���: void
* ��    ��: viod
****************************************************/
u32 Hdc_Gethumidity(void)
{
  u8 hlow=0,hhigh=0;
  u16 htemp=0;
  u32 humidity=0;
  Hdc_I2C_Read(0x02,&hlow);     //��ȡʪ�ȵ�8λ����
  Hdc_I2C_Read(0x03,&hhigh);    //��ȡʪ�ȸ�8λ����
  htemp=(hhigh << 8)| hlow;    //��ʪ�ȸߵ�λ�ϳ�
  humidity=(htemp*100)/65536;            //����ʪ��ֵ
  return humidity;
}

/****************************************************
* �� �� ��: Hdc_Getdata()
* ��������: ��HDC2010��ȡ�¶���ʪ����Ϣ
* ��ڲ���: void
* ��    ��: viod
****************************************************/
void Hdc_Getdata(void)
{
	u32 humidity=0;
  u32 temp=0;

  temp = Hdc_Gettemperature();
  humidity = Hdc_Gethumidity();

	printf("T:0x%x H:0x%x\n", temp, humidity);
	return;
}

u8 Hdc_Get_ID(void)
{
	u8 reg = 0xfc;
	u8 id = 0;
	u8 i = 0;
	printf("%s\n", __FUNCTION__);
	reg = 0;
	for(; i < 0xf; i++){
		if (Hdc_I2C_Read(reg + i, &id) != HAL_OK)     //ID
			return HAL_ERROR;
		
  	printf("0x%x: 0x%x\n", reg + i, id);
	}

	reg = 0xfc;
	for(i = 0; i < 0x4; i++){
		if (Hdc_I2C_Read(reg + i, &id) != HAL_OK)     //ID
			return HAL_ERROR;
		
  	printf("0x%x: 0x%x\n", reg + i, id);
	}	
	return HAL_OK;
}

static __IO uint8_t g_s_th_status = 0;

void TH_Start(void)
{
	g_s_th_status = 1;
	return;
}

void TH_Handle(void)
{
	switch (g_s_th_status)
	{
		case 1:	//power on TH switch to get data
		{
			Hdc_Power(1);
			g_s_th_status = 2;
			break;
		}
		case 2:	//get data , then switch to power down
		{
			Hdc_Getdata();
			g_s_th_status = 3;
			break;
		}
		case 3:	//power down; stop get DATA
		{
			Hdc_Power(0);
			g_s_th_status = 0;
			break;
		}
	}
	return;
}
void Hdc_Test(void)
{
	Hdc_GPIO_Init();
	HAL_Delay(100);
	Hdc_Get_ID();

	Hdc_Init();

	HAL_Delay(100);
	Hdc_Getdata();
	
}

