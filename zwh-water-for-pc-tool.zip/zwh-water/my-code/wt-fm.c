/**
  ******************************************************************************
  * File Name          : wt-fm.c
  * Description        : This file provides code for fm module
  ******************************************************************************
	
	WT_FM_Init()   : ��ʼ�����ϵ�
	tune_test() : ��̨��������һ���ѵ���Ƶ����������ֱ�ӵ���
	uart_cmd(uint8_t *cmd)  : Uart4 �ж�������ã�cmdΪ���ڽ��յ��� ��\r\n ��β������
  	FM init\r\n     ���ڳ�ʼ��  
		FM up\r\n       �ϵ�					
		FM down\r\n     �ϵ�
		FM seek\r\n     ��̨
		FM tune x\r\n   ����ĳ��Ƶ�� 
		FM vol x\r\n    ������������ x Ϊ0~15֮���ֵ
		FM mono 0\r\n   ������
		FM mono 1\r\n   ������
		
  fm_powerdown()  : �ϵ磬ֱ�ӵ���
	* FM�Ķ�д˵����
	*		�����ݵ�ʱ���Ǵ�0xA�Ĵ�����ʼ��ȡ��ʱ����ÿ�ζ��ǽ�0xA��ֵ�ȷ�����Ȼ�����η���0xB-0xC-0xD-0xE-0xF-0x1-0x2......
	*		д���������Ǵ�0x2��ʼ����д��ģ�����дһ���Ĵ��������뽫0x2-0x3-xxxxx-0xx�ļĴ�����дһ��
	* ��д���Ǹ�λ�ȣ���λ�󡣶����8bit������������ż���Ķ��Ǹ�8bit,�����ǵ�8bit
 ******************************************************************************
 *
**/
#include "wt-fm.h"
#include "wt-common.h"

uint8_t slave_addr = 0x10 << 1;
uint8_t fm_reg[32];  				//�洢��ȡ�ļĴ�����ֵ
//uint8_t uartcmd[BUF_LEN];   //�洢���ڵ�����

//FM ��ʼ��
void WT_FM_Init(void)
{
	uint8_t i;
	
	for(i = 0; i < 32; i++)
	{
		fm_reg[i] = 0;
	}
	FM_GPIO_Init();
	FM_Reset();
	
//	fm_encrystal();  //ʹ�ܾ���
//	HAL_Delay(600);
//	
	fm_powerup();   //�ϵ�
	HAL_Delay(500);

	fm_reg_read(fm_reg, 32);
	Dump_Fm_Regs(fm_reg);
}

//��̨��������һ���ѵ���Ƶ��
void tune_test(void)
{
	uint8_t i, freq_count = 0, seeked = 0, res;
	uint16_t chan_seeked[100]; //�洢�ѵ���Ƶ��
	freq_count = fm_seek(chan_seeked); //����Ƶ��
	if(freq_count != 0)
	{
		for(i = 0; i < freq_count; i++)
		{
			// 8950 ��ʾ�ѵ� 89.5MHz 
			printf("seeked : %f MHz \r\n", chan_seeked[i] /100.0);
		}
		seeked = 1;
	}
	else 
		seeked = 0;
	
	if(seeked == 1)
	{
		res = fm_tune(chan_seeked[0]); //������������һ��Ƶ��
		if(res == HAL_OK)
			printf("tune : %f MHz \r\n", chan_seeked[0] /100.0);
		else
			printf("tune failed");
	}
	else 
	{
		printf(" no valid station! ");
	}
}

//Set the XOSCEN bit to power up the crystal.
//reg 07h(D15) : XOSCEN = 1
void fm_encrystal(void)
{
	uint8_t data[12] = {0x00, 0x00, 0x80, 0x00, 0x08, 0x80, 0x00, 0x00, 0x00, 0x00, 0x81, 0x00};
	fm_reg_write(data, 12);
}

// Powerup
// reg 02h��(D14)DMUTE=1(Mute disable.), (D10)SKMODE=1, (D6)DISABLE=0, (D0)ENABLE=1
// reg 05h��(D15:D8)SEETH=0x0c, (D7:D6)BAND=00(87.5�C108 MHz), (D5:D4)SPACE=01(100 kHz), (D3:0)VOLUME=1011
// reg 06h��(D7:D4)SKSNR=0100, (D3:D0)SKCNT=1000
void fm_powerup(void)
{
	uint8_t fm_powerup[10] = {0x44, 0x01, 0x00, 0x00, 0x00, 0x00, 0x0C, 0x1B, 0x00, 0x48};									
	fm_reg_write(fm_powerup, 10);
}

// Powerdown
// reg 02h��(D6)DISABLE=1, (D0)ENABLE=1
// reg 04h��(D5:D4)GPIO3=10(low), (D1:D0)GPIO1=10(low)
void fm_powerdown(void)
{
	uint16_t flag;
	uint8_t fm_powerdown[12] = {0x00, 0x41, 0x00, 0x00, 0x00, 0x2A, 0x00, 0x00, 0x00, 0x00, 0x7C, 0x04};
	fm_reg_write(fm_powerdown, 12);
		
	FM_Power_down(); //����PA8Ϊ���룬PD7 reset
}

// seek through entire band from 87.5 MHZ to 108 MHZ
// band:
//    00 = 87.5�C108 MHz (USA, Europe) (Default).
//	  01 = 76�C108 MHz (Japan wide band).
//	  10 = 76�C90 MHz (Japan).
//band���ϵ�ʱ�Ѿ�����Ϊ 00
int8_t fm_seek(uint16_t chan_seeked[])
{
	int8_t freq_count = 0, flag1, flag2 = 1;
	uint8_t seek_start[2] = {0x47, 0x01};  // SKMODE=1,SEEKUP=1,SEEK=1
	uint8_t seek_stop[2] = {0x04, 0x01};   // SEEK=0,ֹͣ����
	uint8_t seek_chan[4] = {0x44, 0x01, 0x00, 0x00};  // CHAN=00
	
	fm_reg_write(seek_chan,4);
	HAL_Delay(500);

	while(flag2)
	{
		fm_reg_write(seek_start, 2);
		HAL_Delay(500);
		
		do{
			fm_reg_read(fm_reg, 2);           //�� 0A �Ĵ���
		}while((fm_reg[0] & 0x40) == 0);    //�� STC=1 ���һ������
		
		HAL_Delay(500);
		// �� SF/BL=0 ��ʾ �����ɹ���SF/BL=1 ��ʾ����ʧ�ܻ��߳�����̨��Χ
		flag1 = fm_reg[0] & 0x20;				//store the status of SF/BL  bit

		fm_reg_write(seek_stop, 2);
		HAL_Delay(500);
		
		do{
			fm_reg_read(fm_reg, 2);
		}while(fm_reg[0] & 0x40);    //��seek=0,ֹͣ������ STC=0
	
		if(flag1)
		{
			flag2 = 0;
		}
		else 
		{
			fm_reg_read(fm_reg, 4);
			//�Ĵ��� 0B[D9:D0], ���磬������ 89.5MHz���Ĵ����ﱣ�����0x14 (20)
			//ת���� 20 * 10 + 8750 = 8950 
			chan_seeked[freq_count] = fm_reg[3] * 10 + 8750; // store READCHAN as a valid station
			freq_count++;
		}
	}
	return freq_count;    //return the valid station number
}


// convert frequency to channel value
// ���磬Ҫ���� 89.5MHz���Ĵ����ﱣ����� ��8950 -8750��/10��0x14
// 8750 ��ʾ 87.5MHz
uint8_t freq_chan(uint16_t freq)    
{
	uint8_t chan;
	chan = (freq - 8750) / 10;
	return chan;
}

// TUNE a station
// eg.freq=8750,frequency=87.5 MHZ
int8_t fm_tune(uint16_t freq)
{
	uint8_t temp;
	uint8_t channel[4] = {0x44, 0x01 ,0x80, 0x05};
	uint8_t clr_stc[3] = {0x44, 0x01, 0x00};
	
	temp = freq_chan(freq);
	channel[3] = temp;
	fm_reg_write(channel, 4);
	HAL_Delay(500);
	
	fm_reg_read(fm_reg, 32);
	
	do{
		fm_reg_read(fm_reg, 2);
	}while((fm_reg[0] & 0x40) == 0);    //�� TUNE=1ʱ��STC=1
	
	fm_reg_write(clr_stc, 3);   //���� TUNE=0 ��� STC
		
	do{
		fm_reg_read(fm_reg, 2);
	}while(fm_reg[0] & 0x40);    //wait STC=0
	
	return HAL_OK;
}

// Set the volume and mute/unmute status    
// Inputs:   
//      volume: a 4-bit volume value    
// reg 05h��VOLUME[3:0]  
void fm_set_volume(uint8_t volume)   
{   
	uint8_t is_mute;
	uint8_t vol[8]= {0x44, 0x01, 0x00, 0x00, 0x00, 0x00, 0x0C, 0x1B}; 
	
//	fm_reg_read(fm_reg,18);
//	is_mute = fm_reg[16] & 0x40;  //read 02h(D14) mute:0,dmute:1

	//[0:3] vol; [4-5] space01
  vol[7] = (vol[7] & ~(0x3f)) | 0x10 | volume;
	fm_reg_write(vol, 8); 
}   
 
// Forces mono mode or enables stereo mode    
// Inputs:   
//      mono: 0 = stereo mode enabled   
//            1 = mono mode forced   
// reg 02h��MONO(D13) 
void fm_set_mono(uint8_t mono)   
{   
	uint8_t mode[1];
	if(mono)   
		mode[0] = 0x64;   
	else
		mode[0] = 0x44;  
  fm_reg_write(mode, 1); 
}  

// get the stereo condition of the station
// reg 0Ah. ST(D8) ��0 = MONO, 1 = STEREO
uint8_t fm_is_mono(void)
{
	fm_reg_read(fm_reg, 1);
	if(fm_reg[0] & 0x01)
	{
		return 1;     //stereo
	}
	else
	{
		return 0;    //mono
	}
}

void Dump_Fm_Regs(uint8_t *addr)
{
	printf("=====Dump_Regs FM======\r\n");
	for(uint8_t i = 0; i < 32; i++)    
	{ 
		if ( i % 8 == 0)
			printf("\r\n%02d :", i);
		printf(" [%02x] ", addr[i]);         
	}
	printf("\r\n");	
}

uint16_t fm_reg_read(uint8_t *data,  uint16_t size)
{
	uint8_t re;
	re = HAL_I2C_Master_Receive(&hi2c2, slave_addr, data, size ,1000);
	if (re != HAL_OK) {
		return HAL_ERROR;
	}
	return HAL_OK;
}
uint16_t fm_reg_write(uint8_t *data, uint16_t size)
{
	uint8_t re;
	re = HAL_I2C_Master_Transmit(&hi2c2, slave_addr, data, size ,1000);
	if (re != HAL_OK) {
		return HAL_ERROR;
	}
	return HAL_OK;
}

void fm_handle_cmd(uint8_t *cmd)
{
	uint8_t len = strlen(cmd);
	uint16_t data=0;
	uint8_t str[len];
	uint8_t i,j=0;
	for(i=3; i< len - 2; i++)
	{
		if(cmd[i] == ' ') break;
		str[j++]= cmd[i];
	}
  printf("cmd:%s \r\n" , str);
	for(i=i+1; i< len - 2; i++)
	{
		if(cmd[i] == ' ') break;
		data = data * 10 + cmd[i] -48;
	}
	printf("data:%d \r\n" , data);
	if(strstr((const char*)str, (const char*)"up"))
	{
		HAL_GPIO_WritePin(FM_RESET_PD7_GPIO_Port, FM_RESET_PD7_Pin, GPIO_PIN_SET);
		fm_powerup();   
		HAL_Delay(500);
	}
	if(strstr((const char*)str, (const char*)"down"))
		fm_powerdown();
	if(strstr((const char*)str, (const char*)"init"))
		WT_FM_Init();
	if(strstr((const char*)str, (const char*)"seek"))
	{
		uint16_t freq_count=0;
		uint16_t chan_seeked[100]; //�洢�ѵ���Ƶ��
		freq_count = fm_seek(chan_seeked);
		if(freq_count != 0)
		{
			for(i = 0; i < freq_count; i++)
			{
				printf("seeked : %f MHz \r\n", chan_seeked[i] /100.0);
			}
		}
		else 
		{
			printf(" no valid station! ");
		}
	}
	if(strstr((const char*)str, (const char*)"tune"))
	{
		uint8_t res;
		res = fm_tune(data);
		if(res == HAL_OK)
			printf("tune : %f MHz \r\n", data /100.0);
		else
			printf("tune failed");
	}
	if(strstr((const char*)str, (const char*)"vol"))
		fm_set_volume(data);
	if(strstr((const char*)str, (const char*)"mono"))
		fm_set_mono(data);
	
	HAL_Delay(500);
	fm_reg_read(fm_reg, 32);
	Dump_Fm_Regs(fm_reg);
}

void FM_GPIO_Init(void)
{
	//PA8   ------> RCC_MCO
	GPIO_InitTypeDef GPIO_InitStruct = {0};
  GPIO_InitStruct.Pin = FM_MCO_PA8_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  GPIO_InitStruct.Alternate = GPIO_AF0_MCO;
  HAL_GPIO_Init(FM_MCO_PA8_GPIO_Port, &GPIO_InitStruct);
	//�������Ҫ���ó�32.768K

  /*Configure GPIO pin : PtPin */
  GPIO_InitStruct.Pin = FM_RESET_PD7_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
  HAL_GPIO_Init(FM_RESET_PD7_GPIO_Port, &GPIO_InitStruct);
	
	HAL_GPIO_WritePin(FM_RESET_PD7_GPIO_Port, FM_RESET_PD7_Pin, GPIO_PIN_SET);
}

//����PA8Ϊ���룬PD7 reset
void FM_Power_down(void)
{
	GPIO_InitTypeDef GPIO_InitStruct = {0};
  GPIO_InitStruct.Pin = FM_MCO_PA8_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(FM_MCO_PA8_GPIO_Port, &GPIO_InitStruct);
	
	HAL_GPIO_WritePin(FM_RESET_PD7_GPIO_Port, FM_RESET_PD7_Pin, GPIO_PIN_RESET);
}
void FM_Reset(void)
{
	HAL_GPIO_WritePin(FM_RESET_PD7_GPIO_Port, FM_RESET_PD7_Pin, GPIO_PIN_SET);
	HAL_Delay(100);
	HAL_GPIO_WritePin(FM_RESET_PD7_GPIO_Port, FM_RESET_PD7_Pin, GPIO_PIN_RESET);
	HAL_Delay(100);
	HAL_GPIO_WritePin(FM_RESET_PD7_GPIO_Port, FM_RESET_PD7_Pin, GPIO_PIN_SET);
	HAL_Delay(100);
}

uint8_t fm_mfg_test(void)
{
	uint8_t re;
	FM_GPIO_Init();
	FM_Reset();
	re = HAL_I2C_Master_Receive(&hi2c2, slave_addr, fm_reg, 32, 1000);
	if (re != HAL_OK) {
		return HAL_ERROR;
	}
	Dump_Fm_Regs(fm_reg);
	//check ID
	if (fm_reg[12] != 0x12 || fm_reg[13] != 0x42){
		printf("Failed to get ID!\nPlease check FM salve addr or others!!\n");
		return HAL_ERROR;
	}
	else{
		printf("Get FM IC: 0x1242!!!\n");
	}
	//////////////////////////////
	return HAL_OK;
}
