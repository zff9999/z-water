/**
  ******************************************************************************
  * File Name          : ADC.c
  * Description        : This file provides code for the configuration
  *                      of the ADC instances.
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under Ultimate Liberty license
  * SLA0044, the "License"; You may not use this file except in compliance with
  * the License. You may obtain a copy of the License at:
  *                             www.st.com/SLA0044
  *
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "adc.h"


/* USER CODE BEGIN 0 */

int Pressure_Int_handle(void);
/*****************************************************************************
 * Function      : enable_calibrate
 * Description   : ����ADC��У��
 * Input         : ADC_TypeDef *Instance  
 * Output        : None
 * Return        : 
 * Others        : 
 * Record
 * 1.Date        : 20200614
 *   Author      : zhangwh
 *   Modification: Created function

*****************************************************************************/
void enable_calibrate(ADC_TypeDef *Instance)
{
	uint32_t val = 0;
	CLEAR_BIT(Instance->CR ,ADC_CR_ADCALDIF);
	SET_BIT(Instance->CR ,ADC_CR_ADCAL);
	while(READ_BIT(Instance->CR, ADC_CR_ADCAL));
	val = READ_BIT(Instance->CALFACT, ADC_CALFACT_CALFACT_S);
	printf("Calibrate Fact: 0x%08x\r\n", val);
	return;
}
/* USER CODE END 0 */

ADC_HandleTypeDef hadc1;
ADC_HandleTypeDef hadc2;
ADC_HandleTypeDef hadc3;
//SAVE DATA IN BUFFER THROUGH DMA
DMA_HandleTypeDef hdma_adc1;
DMA_HandleTypeDef hdma_adc2;
DMA_HandleTypeDef hdma_adc3;
/* ADC1 init function */
void MX_ADC1_Init(void)
{
  ADC_MultiModeTypeDef multimode = {0};
  ADC_ChannelConfTypeDef sConfig = {0};

  /** Common config 
  */
  hadc1.Instance = ADC1;
  hadc1.Init.ClockPrescaler = ADC_CLOCK_ASYNC_DIV2;
  hadc1.Init.Resolution = ADC_RESOLUTION_12B;
  hadc1.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hadc1.Init.ScanConvMode = ADC_SCAN_ENABLE;
  hadc1.Init.EOCSelection = ADC_EOC_SINGLE_CONV;
  hadc1.Init.LowPowerAutoWait = DISABLE;
  hadc1.Init.ContinuousConvMode = ENABLE;
  hadc1.Init.NbrOfConversion = 5;
  hadc1.Init.DiscontinuousConvMode = DISABLE;
  hadc1.Init.NbrOfDiscConversion = 1;
  hadc1.Init.ExternalTrigConv = ADC_SOFTWARE_START;
  hadc1.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
  hadc1.Init.DMAContinuousRequests = ENABLE;
  hadc1.Init.Overrun = ADC_OVR_DATA_PRESERVED;
  hadc1.Init.OversamplingMode = DISABLE;
  if (HAL_ADC_Init(&hadc1) != HAL_OK)
  {
    Error_Handler();
  }
  /** Configure the ADC multi-mode 
  */
  multimode.Mode = ADC_MODE_INDEPENDENT;
  if (HAL_ADCEx_MultiModeConfigChannel(&hadc1, &multimode) != HAL_OK)
  {
    Error_Handler();
  }
  /** Configure Regular Channel 
  */
  //ADC1 9 flow sensor 30 sec sample
  sConfig.Channel = ADC_CHANNEL_9;
  sConfig.Rank = ADC_REGULAR_RANK_1;
  sConfig.SamplingTime = ADC_SAMPLETIME_6CYCLES_5;
  sConfig.SingleDiff = ADC_SINGLE_ENDED;
  sConfig.OffsetNumber = ADC_OFFSET_NONE;
  sConfig.Offset = 0;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /** Configure Regular Channel 
  */
  //Sensor2 ADC  TO BE DETERMin  30 Sec
  sConfig.Channel = ADC_CHANNEL_10;
  sConfig.Rank = ADC_REGULAR_RANK_2;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /** Configure Regular Channel 
  */
  //Sensor4 ADC  TO BE DETERMin  30 Sec
  sConfig.Channel = ADC_CHANNEL_11;
  sConfig.Rank = ADC_REGULAR_RANK_3;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /** Configure Regular Channel 
  */
  //VOLTAGE Sensor2 ADC  30 Sec
  sConfig.Channel = ADC_CHANNEL_12;
  sConfig.Rank = ADC_REGULAR_RANK_4;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /** Configure Regular Channel 
  */
  //Sensor2 ADC  TO BE DETERMin  30 Sec
  sConfig.Channel = ADC_CHANNEL_15;
  sConfig.Rank = ADC_REGULAR_RANK_5;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
	enable_calibrate(ADC1);
}
/* ADC2 init function */

void MX_ADC2_Init(void)
{
  ADC_ChannelConfTypeDef sConfig = {0};

  /** Common config 
  */
  hadc2.Instance = ADC2;
  hadc2.Init.ClockPrescaler = ADC_CLOCK_ASYNC_DIV2;
  hadc2.Init.Resolution = ADC_RESOLUTION_12B;
  hadc2.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hadc2.Init.ScanConvMode = ADC_SCAN_DISABLE;
  hadc2.Init.EOCSelection = ADC_EOC_SINGLE_CONV;
  hadc2.Init.LowPowerAutoWait = DISABLE;
  hadc2.Init.ContinuousConvMode = DISABLE;
  hadc2.Init.NbrOfConversion = 1;
  hadc2.Init.DiscontinuousConvMode = DISABLE;
  hadc2.Init.NbrOfDiscConversion = 1;
  hadc2.Init.ExternalTrigConv = ADC_SOFTWARE_START;
  hadc2.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
  hadc2.Init.DMAContinuousRequests = DISABLE;
  hadc2.Init.Overrun = ADC_OVR_DATA_PRESERVED;
  hadc2.Init.OversamplingMode = DISABLE;
  if (HAL_ADC_Init(&hadc2) != HAL_OK)
  {
    Error_Handler();
  }
  /** Configure Regular Channel 
  */
  sConfig.Channel = ADC_CHANNEL_9;
  sConfig.Rank = ADC_REGULAR_RANK_1;
  sConfig.SamplingTime = ADC_SAMPLETIME_2CYCLES_5;
  sConfig.SingleDiff = ADC_SINGLE_ENDED;
  sConfig.OffsetNumber = ADC_OFFSET_NONE;
  sConfig.Offset = 0;
  if (HAL_ADC_ConfigChannel(&hadc2, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
	enable_calibrate(ADC2);
}

/* ADC3 init function */
//ADC3����ѹ��������������
void MX_ADC3_Init(void)
{
  ADC_ChannelConfTypeDef sConfig = {0};

  /** Common config 
  */
  hadc3.Instance = ADC3;
  hadc3.Init.ClockPrescaler = ADC_CLOCK_ASYNC_DIV2;
  hadc3.Init.Resolution = ADC_RESOLUTION_12B;
  hadc3.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hadc3.Init.ScanConvMode = ADC_SCAN_ENABLE;
  hadc3.Init.EOCSelection = ADC_EOC_SINGLE_CONV;
  hadc3.Init.LowPowerAutoWait = DISABLE;
  hadc3.Init.ContinuousConvMode = ENABLE;
  hadc3.Init.NbrOfConversion = 1;
  hadc3.Init.DiscontinuousConvMode = DISABLE;
  hadc3.Init.NbrOfDiscConversion = 1;
  hadc3.Init.ExternalTrigConv = ADC_SOFTWARE_START;
  hadc3.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
  hadc3.Init.DMAContinuousRequests = ENABLE;
  hadc3.Init.Overrun = ADC_OVR_DATA_PRESERVED;
  hadc3.Init.OversamplingMode = DISABLE;
  if (HAL_ADC_Init(&hadc3) != HAL_OK)
  {
    Error_Handler();
  }
  /** Configure Regular Channel 
  */
  sConfig.Channel = ADC_CHANNEL_4;
  sConfig.Rank = ADC_REGULAR_RANK_1;
  sConfig.SamplingTime = ADC_SAMPLETIME_6CYCLES_5;
  sConfig.SingleDiff = ADC_SINGLE_ENDED;
  sConfig.OffsetNumber = ADC_OFFSET_NONE;
  sConfig.Offset = 0;
  if (HAL_ADC_ConfigChannel(&hadc3, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
	enable_calibrate(ADC3);
}

static uint32_t HAL_RCC_ADC_CLK_ENABLED=0;

void HAL_ADC_MspInit(ADC_HandleTypeDef* adcHandle)
{

  GPIO_InitTypeDef GPIO_InitStruct = {0};
  if(adcHandle->Instance==ADC1)
  {
  /* USER CODE BEGIN ADC1_MspInit 0 */

  /* USER CODE END ADC1_MspInit 0 */
    /* ADC1 clock enable */
    HAL_RCC_ADC_CLK_ENABLED++;
    if(HAL_RCC_ADC_CLK_ENABLED==1){
      __HAL_RCC_ADC_CLK_ENABLE();
    }
  
    __HAL_RCC_GPIOA_CLK_ENABLE();
    __HAL_RCC_GPIOB_CLK_ENABLE();
    /**ADC1 GPIO Configuration    
    PA4     ------> ADC1_IN9		//Sensor1
    PA5     ------> ADC1_IN10		//Sensor2
    PA6     ------> ADC1_IN11		//Sensor4
    PA7     ------> ADC1_IN12		//Battery
    PB0     ------> ADC1_IN15 	//Sensor3
    */
    GPIO_InitStruct.Pin = GPIO_PIN_4|GPIO_PIN_5|GPIO_PIN_6|GPIO_PIN_7;
    GPIO_InitStruct.Mode = GPIO_MODE_ANALOG_ADC_CONTROL;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

    GPIO_InitStruct.Pin = GPIO_PIN_0;
    GPIO_InitStruct.Mode = GPIO_MODE_ANALOG_ADC_CONTROL;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

    /* ADC1 DMA Init */
    /* ADC1 Init */
    hdma_adc1.Instance = DMA1_Channel1;
    hdma_adc1.Init.Request = DMA_REQUEST_0;
    hdma_adc1.Init.Direction = DMA_PERIPH_TO_MEMORY;
    hdma_adc1.Init.PeriphInc = DMA_PINC_DISABLE;
    hdma_adc1.Init.MemInc = DMA_MINC_ENABLE;
    hdma_adc1.Init.PeriphDataAlignment = DMA_PDATAALIGN_HALFWORD;
    hdma_adc1.Init.MemDataAlignment = DMA_MDATAALIGN_HALFWORD;
    hdma_adc1.Init.Mode = DMA_NORMAL;
    hdma_adc1.Init.Priority = DMA_PRIORITY_LOW;
    if (HAL_DMA_Init(&hdma_adc1) != HAL_OK)
    {
      Error_Handler();
    }

    __HAL_LINKDMA(adcHandle,DMA_Handle,hdma_adc1);

  /* USER CODE BEGIN ADC1_MspInit 1 */

  /* USER CODE END ADC1_MspInit 1 */
  }
  else if(adcHandle->Instance==ADC2)
  {
  /* USER CODE BEGIN ADC2_MspInit 0 */

  /* USER CODE END ADC2_MspInit 0 */
    /* ADC2 clock enable */
    HAL_RCC_ADC_CLK_ENABLED++;
    if(HAL_RCC_ADC_CLK_ENABLED==1){
      __HAL_RCC_ADC_CLK_ENABLE();
    }
  
    __HAL_RCC_GPIOA_CLK_ENABLE();
    __HAL_RCC_GPIOB_CLK_ENABLE();
    /**ADC2 GPIO Configuration    
    PA4     ------> ADC2_IN9
    PA5     ------> ADC2_IN10
    PA6     ------> ADC2_IN11
    PA7     ------> ADC2_IN12
    PB0     ------> ADC2_IN15 
    */
    GPIO_InitStruct.Pin = GPIO_PIN_4|GPIO_PIN_5|GPIO_PIN_6|GPIO_PIN_7;
    GPIO_InitStruct.Mode = GPIO_MODE_ANALOG_ADC_CONTROL;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

    GPIO_InitStruct.Pin = GPIO_PIN_0;
    GPIO_InitStruct.Mode = GPIO_MODE_ANALOG_ADC_CONTROL;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

    /* ADC2 DMA Init */
    /* ADC2 Init */
    hdma_adc2.Instance = DMA1_Channel2;
    hdma_adc2.Init.Request = DMA_REQUEST_0;
    hdma_adc2.Init.Direction = DMA_PERIPH_TO_MEMORY;
    hdma_adc2.Init.PeriphInc = DMA_PINC_DISABLE;
    hdma_adc2.Init.MemInc = DMA_MINC_ENABLE;
    hdma_adc2.Init.PeriphDataAlignment = DMA_PDATAALIGN_HALFWORD;
    hdma_adc2.Init.MemDataAlignment = DMA_MDATAALIGN_HALFWORD;
    hdma_adc2.Init.Mode = DMA_NORMAL;
    hdma_adc2.Init.Priority = DMA_PRIORITY_LOW;
    if (HAL_DMA_Init(&hdma_adc2) != HAL_OK)
    {
      Error_Handler();
    }

    __HAL_LINKDMA(adcHandle,DMA_Handle,hdma_adc2);

  /* USER CODE BEGIN ADC2_MspInit 1 */
	
  /* USER CODE END ADC2_MspInit 1 */
  }
  else if(adcHandle->Instance==ADC3)
  {
  /* USER CODE BEGIN ADC3_MspInit 0 */

  /* USER CODE END ADC3_MspInit 0 */
    /* ADC3 clock enable */
    HAL_RCC_ADC_CLK_ENABLED++;
    if(HAL_RCC_ADC_CLK_ENABLED==1){
      __HAL_RCC_ADC_CLK_ENABLE();
    }
  
    __HAL_RCC_GPIOC_CLK_ENABLE();
    /**ADC3 GPIO Configuration    
    PC3     ------> ADC3_IN4 
    */
    GPIO_InitStruct.Pin = GPIO_PIN_3;
    GPIO_InitStruct.Mode = GPIO_MODE_ANALOG_ADC_CONTROL;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

    /* ADC3 DMA Init */
    /* ADC3 Init */
		//DMA1_CHA3��uart3 rx��ADC3���õ�
    hdma_adc3.Instance = DMA1_Channel3;
    hdma_adc3.Init.Request = DMA_REQUEST_0;
    hdma_adc3.Init.Direction = DMA_PERIPH_TO_MEMORY;
    hdma_adc3.Init.PeriphInc = DMA_PINC_DISABLE;
    hdma_adc3.Init.MemInc = DMA_MINC_ENABLE;
    hdma_adc3.Init.PeriphDataAlignment = DMA_PDATAALIGN_HALFWORD;
    hdma_adc3.Init.MemDataAlignment = DMA_MDATAALIGN_HALFWORD;
    hdma_adc3.Init.Mode = DMA_CIRCULAR;
    hdma_adc3.Init.Priority = DMA_PRIORITY_HIGH;
    if (HAL_DMA_Init(&hdma_adc3) != HAL_OK)
    {
      Error_Handler();
    }

    __HAL_LINKDMA(adcHandle,DMA_Handle,hdma_adc3);

  /* USER CODE BEGIN ADC3_MspInit 1 */

  /* USER CODE END ADC3_MspInit 1 */
  }
}

void HAL_ADC_MspDeInit(ADC_HandleTypeDef* adcHandle)
{

  if(adcHandle->Instance==ADC1)
  {
  /* USER CODE BEGIN ADC1_MspDeInit 0 */

  /* USER CODE END ADC1_MspDeInit 0 */
    /* Peripheral clock disable */
    HAL_RCC_ADC_CLK_ENABLED--;
    if(HAL_RCC_ADC_CLK_ENABLED==0){
      __HAL_RCC_ADC_CLK_DISABLE();
    }
  
    /**ADC1 GPIO Configuration    
    PA4     ------> ADC1_IN9
    PA5     ------> ADC1_IN10
    PA6     ------> ADC1_IN11
    PA7     ------> ADC1_IN12
    PB0     ------> ADC1_IN15 
    */
    HAL_GPIO_DeInit(GPIOA, GPIO_PIN_4|GPIO_PIN_5|GPIO_PIN_6|GPIO_PIN_7);

    HAL_GPIO_DeInit(GPIOB, GPIO_PIN_0);

    /* ADC1 DMA DeInit */
    HAL_DMA_DeInit(adcHandle->DMA_Handle);
  /* USER CODE BEGIN ADC1_MspDeInit 1 */

  /* USER CODE END ADC1_MspDeInit 1 */
  }
  else if(adcHandle->Instance==ADC2)
  {
  /* USER CODE BEGIN ADC2_MspDeInit 0 */

  /* USER CODE END ADC2_MspDeInit 0 */
    /* Peripheral clock disable */
    HAL_RCC_ADC_CLK_ENABLED--;
    if(HAL_RCC_ADC_CLK_ENABLED==0){
      __HAL_RCC_ADC_CLK_DISABLE();
    }
  
    /**ADC2 GPIO Configuration    
    PA4     ------> ADC2_IN9
    PA5     ------> ADC2_IN10
    PA6     ------> ADC2_IN11
    PA7     ------> ADC2_IN12
    PB0     ------> ADC2_IN15 
    */
    HAL_GPIO_DeInit(GPIOA, GPIO_PIN_4|GPIO_PIN_5|GPIO_PIN_6|GPIO_PIN_7);

    HAL_GPIO_DeInit(GPIOB, GPIO_PIN_0);

    /* ADC2 DMA DeInit */
    HAL_DMA_DeInit(adcHandle->DMA_Handle);
  /* USER CODE BEGIN ADC2_MspDeInit 1 */

  /* USER CODE END ADC2_MspDeInit 1 */
  }
  else if(adcHandle->Instance==ADC3)
  {
  /* USER CODE BEGIN ADC3_MspDeInit 0 */

  /* USER CODE END ADC3_MspDeInit 0 */
    /* Peripheral clock disable */
    HAL_RCC_ADC_CLK_ENABLED--;
    if(HAL_RCC_ADC_CLK_ENABLED==0){
      __HAL_RCC_ADC_CLK_DISABLE();
    }
  
    /**ADC3 GPIO Configuration    
    PC3     ------> ADC3_IN4 
    */
    HAL_GPIO_DeInit(GPIOC, GPIO_PIN_3);

    /* ADC3 DMA DeInit */
    HAL_DMA_DeInit(adcHandle->DMA_Handle);
  /* USER CODE BEGIN ADC3_MspDeInit 1 */

  /* USER CODE END ADC3_MspDeInit 1 */
  }
} 

/* USER CODE BEGIN 1 */
/*
һ����5����������ÿ������������5�����ݣ�����ƽ��ֵ
*/
//sample 5 times
uint16_t ADC1_Value[5 * 5];

static uint8_t pre_first_sample = 1;		//ADC3
static uint8_t sensor_first_sample = 1;	//ADC1
//ADC3 ѹ��������
uint16_t ADC3_PRESSURE_Value[5];
//�ж�ADC�Ĳ����Ƿ����
uint8_t data_rdy;
uint8_t data2_rdy;
uint8_t data3_rdy;

extern void Sensors_PowerOn(uint8_t sensors, GPIO_PinState enable);

static __IO uint32_t Sensor_Delay = 0;

//���ڼ�¼ÿ�β�����ʼ��ʱ�䣻���ʱ����Ϊʱ������͸����ݿ�
//��Ϊ���������棬��Ҫ�л���ÿ���л���ʱ����Ǽ�¼��һ�η������ݵ�ʱ���
static char pre_sample_time_1[13];
static char pre_sample_time_2[13];
static char *pre_sample_time = NULL;

static char sensor_sample_time_1[13];
static char sensor_sample_time_2[13];
static char *sensor_sample_time = NULL;


void start_ADC1(void)
{
	data_rdy = 0;

	HAL_ADC_Start_DMA(&hadc1, (uint32_t*)&ADC1_Value, 25);
	if(sensor_first_sample == 1){
		//������һ�δ���������ʱ�������
		WT_RTC_GetTime(sensor_sample_time_1);
		WT_RTC_GetTime(sensor_sample_time_2);
		sensor_sample_time = sensor_sample_time_1;
		sensor_first_sample = 0;
		}

}

void stop_ADC1(void)
{
	HAL_ADC_Stop_DMA(&hadc1);
}

void start_ADC2(void)
{
	data2_rdy = 0;

	HAL_ADC_Start_DMA(&hadc2, (uint32_t*)&ADC3_PRESSURE_Value, 5);
}

void stop_ADC2(void)
{
	HAL_ADC_Start_IT(&hadc2);
}

void Start_Pressure(void);
void start_ADC3(void)
{
	data3_rdy = 0;
	HAL_ADC_Start_DMA(&hadc3, (uint32_t*)&ADC3_PRESSURE_Value, 5);
	if(pre_first_sample == 1){
		WT_RTC_GetTime(pre_sample_time_1);
		WT_RTC_GetTime(pre_sample_time_2);
		pre_sample_time = pre_sample_time_1;
		pre_first_sample = 0;
		}

}

void stop_ADC3(void)
{
	HAL_ADC_Start_IT(&hadc3);
}

/*****************************************************************************
 * Function      : HAL_ADC_ConvCpltCallback
 * Description   : ADC����DMA��ɵĻص�����,����ֻ��һ��
 * Input         : ADC_HandleTypeDef *hadc  
 * Output        : None
 * Return        : 
 * Others        : 
 * Record
 * 1.Date        : 20200614
 *   Author      : zhangwh
 *   Modification: Created function
*****************************************************************************/
void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef *hadc)
{
	if(hadc->Instance==ADC1)
	{
		data_rdy = 1;
		//printf("ADC1 DONE!\n");
			HAL_ADC_Stop_DMA(hadc);
	}
	else if(hadc->Instance==ADC3)
	{
		data3_rdy = 1;
		//printf("PRESS DONE!\n");
		//�˴�ֱ�Ӷ����ݴ�����������while�д���
		if(Pressure_Int_handle() != 0)
			return;
					HAL_ADC_Stop_DMA(hadc);
	}

}

/*****************************************************************************
 * Function      : Calc_Voltage
 * Description   : �����ѹֵ��ref vol��3.272
 * Input         : uint16_t adcVal  
 * Output        : None
 * Return        : 
 * Others        : 
 * Record
 * 1.Date        : 20200614
 *   Author      : zhangwh
 *   Modification: Created function

*****************************************************************************/
void Calc_Voltage(uint16_t adcVal)
{
	float fcont = 6.231;
	// (78k / 10k) * 3.272v * ADC / 2 ^ 12 = 0.006231 * ADC
	//float val = fcont * adcVal /1000 + 0.36;
	float val = fcont * adcVal /1000;
	printf("\r\nVoltage: [0x%x] %.3f\r\n", adcVal, val);
	return;
}
#define PRE_BUFF_LEN 15*1024
//ÿ5���ӷ���һ������,���ݵĻ��� 15K * 2B,ÿ�η��͵Ļ�ֻ����һ�룬��������˫����
static uint16_t m_pressure_buff1[PRE_BUFF_LEN/2];
static uint16_t m_pressure_buff2[PRE_BUFF_LEN/2];
static uint16_t *m_pre_send_addr = m_pressure_buff1;
static __IO uint32_t m_pressure_len = 0;
static uint16_t *m_pre_save_addr = m_pressure_buff1;
//��¼������ʹ�õ���λ��
static __IO uint32_t Pressure_Buff_Pos = 0;
//����ѹ��������������
//�ɼ�����/���ӣ�����5��������Ȼ����
#define SENSOR_BUFF_LEN (2*5*4*5)
static uint16_t m_sensors_buff1[SENSOR_BUFF_LEN/2];
static uint16_t m_sensors_buff2[SENSOR_BUFF_LEN/2];
static uint16_t *m_sensor_send_addr = m_sensors_buff1;
static __IO uint32_t m_sensor_len = 0;
static uint16_t *m_sensor_save_addr = m_sensors_buff1;
//��¼������ʹ�õ���λ��
static __IO uint32_t Sensor_Buff_Pos = 0;


void Calc_Current(uint16_t adcVal)
{
	float fcont = 5.33619;
	float fact = 0;	
	// 3.272v * ADC / 3 / 49.9 / 2 ^ 12 * 1000 = 0.00532641 * ADC
	//float val = fcont * (adcVal + 159 + fact) /1000*0.99 - 0.5;
	float val = fcont * (adcVal)/1000;
	
	//��������Ĺ�ʽ���� fact;//����ƫ��У�飺ѹ����������Ĭ��Ϊ4mA
	//450000/99/fcont - ADC - 159�õ���׼���� fact;�����Ϊsetting
	//printf("\nCurrent: [0x%x] %.3f(mA)\n", adcVal, val);
	return;
}

static __IO uint32_t Pre_Delay = 0;

extern int (* Send_Data_Func)(uint8_t * tx_buf, uint32_t len);
extern UART_HandleTypeDef * send_port;
//extern char * WT_RTC_GetTime(char * tmStmp);
extern void Set_Pkt_Header(WT_Header * hdr_ptr, char * timestr, uint8_t MsgID, uint32_t data_Size);
WT_Header pkg_header;



void Send_Header_Handle(void)
{
	uint8_t len = sizeof(pkg_header);
	Send_Data_Func((uint8_t *)&pkg_header, len);
	//�л���ͬ��buff
}


/////////////Pressure route/////////////////////////
//����1��ʱ��.��ʾ��ǰû�����ݣ�������
uint8_t Send_Pressure_Get_Data_Info(void)
{
	char pressure_time[12];
	printf("!!!!!!!!!!!!!!Pressure_Buff_Pos:0x%x\r\n", Pressure_Buff_Pos);
	if(Pressure_Buff_Pos == 0)
		return 1;
	//��һ���Ƿ��͵���ʼ���ǻ�����׵�ַ,��ʾ��һ���Ƿ��͵��°������
	//���η�����������Ӧ�ôӻ������ʼ��ַ��ʼ��¼�����Խ�pos��Ϊ0
	m_pre_send_addr = m_pre_save_addr; 
	m_pressure_len = Pressure_Buff_Pos;
	
	//�����л��洢��ַ
	if( m_pre_save_addr == m_pressure_buff1){
		m_pre_save_addr = m_pressure_buff2;
		WT_RTC_GetTime(pre_sample_time_2);	
		pre_sample_time = pre_sample_time_1;
	}
	else{
		m_pre_save_addr = m_pressure_buff1;
		WT_RTC_GetTime(pre_sample_time_1);	
		pre_sample_time = pre_sample_time_2;
	}
	Pressure_Buff_Pos = 0;
	WT_RTC_GetTime((char *)pressure_time);
	printf("%s:Set packet header:%s\r\n", __FUNCTION__, pressure_time);
	Set_Pkt_Header(&pkg_header, pressure_time, TYPE_PRESSURE, m_pressure_len * 2);
	printf("===return ==0\r\n");
	return 0;
}

/*****************************************************************************
 * Function      : Start_Pressure
 * Description   : ��ʼѹ������������֮ǰ,��Ҫ�ϵ���ӳ�8-
                   ms��Ȼ��Ŵ������ݲɼ�(ADC)
 * Input         : void  
 * Output        : None
 * Return        : 
 * Others        : 
 * Record
 * 1.Date        : 20200614
 *   Author      : zhangwh
 *   Modification: Created function

*****************************************************************************/
void Start_Pressure(void)
{
	Pre_Delay = HAL_GetTick()+8;	//Delay 8ms
	//power on pressure sensor
	//printf("======>%d\n\n", Pre_Delay);
	Sensors_PowerOn(0x1, GPIO_PIN_SET);

	return;
}

/*****************************************************************************
 * Function      : Start_Sensors
 * Description   : ����Sensor1-5�ĵ�Դ������������ʱ1ms
 * Input         : void  
 * Output        : None
 * Return        : 
 * Others        : 
 * Record
 * 1.Date        : 20200615
 *   Author      : zhangwh
 *   Modification: Created function

*****************************************************************************/
void Start_Sensors(void)
{
	//Power on Sensor1 /2-4
	Sensors_PowerOn(0x2, GPIO_PIN_SET);
	Sensors_PowerOn(0x4, GPIO_PIN_SET);
	Sensor_Delay = HAL_GetTick() + 8;	//Delay 8ms
	
	return;
}

/*****************************************************************************/
int Pressure_Int_handle(void)
{	
	uint32_t tick = HAL_GetTick();
	//printf("%d ===%d\r\n",tick , Pre_Delay );
	if(Pre_Delay == 0)
		return 0;
	if(tick <= Pre_Delay){
		return -1; //����-1��ʾSensor����power on//�����ȴ������������ж�
	}
	//��ʼ����
	{
		uint8_t i = 0;
		uint16_t preSum = 0;
		//printf("![%d]\r\n", HAL_GetTick());
		//power down pressure sensor!!!!
		Sensors_PowerOn(0x1, GPIO_PIN_RESET);
		for(; i < 5; i ++)
		{
			preSum = preSum + ADC3_PRESSURE_Value[i];
			//printf("[0x%x]: 0x%x ", i, ADC3_PRESSURE_Value[i]);
		}
		//Save data to buff
		//printf("===>>>>>>%d\n", Pressure_Buff_Pos);
		m_pre_save_addr[Pressure_Buff_Pos++] = preSum / 5;
		Calc_Current(preSum / 5);
	}	
	Pre_Delay = 0;
	return 0;
}



/*****************************************************************************
 * Function      : Pressure_Handle_Data
 * Description   : ����ѹ�������������ݲɼ����̣����ж�?-
                   ?��ʱ���Ƿ��ˣ����˾ʹ���ADC����adc��?-
                   ??��ɺ󽫵�Դ�رգ�������ƽ��ֵ������-
                   ����
 * Input         : void  
 * Output        : None
 * Return        : 
 * Others        : 
 * Record
 * 1.Date        : 20200614
 *   Author      : zhangwh
 *   Modification: Created function

*****************************************************************************/
void Pressure_Handle_Data(void)
{	
	uint32_t tick = HAL_GetTick();
	if(data3_rdy == 0)
	{
		if(Pre_Delay == 0)
			return;
		if(tick >= Pre_Delay){
			//Sensor�ϵ�8ms���ȶ����Դ���ADC
			start_ADC3();
			Pre_Delay = 0;
		}
	}
	else if(data3_rdy == 1){
		uint8_t i = 0;
		uint16_t preSum = 0;
		//printf("![%d]\n", HAL_GetTick());
		//power down pressure sensor!!!!
		Sensors_PowerOn(0x1, GPIO_PIN_RESET);
		for(; i < 5; i ++)
		{
			preSum = preSum + ADC3_PRESSURE_Value[i];
			//printf("[0x%x]: 0x%x ", i, ADC3_PRESSURE_Value[i]);
		}
		//Save data to buff
		//printf("===>>>>>>%d\n", Pressure_Buff_Pos);
		m_pre_save_addr[Pressure_Buff_Pos++] = preSum / 5;
		Calc_Current(preSum / 5);
		
		data3_rdy = 0;
	}	
	return;
}

void print_Pre_Cnt(void){
	printf("Pressure_Buff_Pos:%d\r\n", Pressure_Buff_Pos);
	printf("Sensor_Buff_Pos:%d\r\n", Sensor_Buff_Pos);
}
//0:idle 1: send header 2: sending header 3: send data 4: sending data
static __IO uint32_t pressure_send_st = 0;



////////////////Sensors route/////////////////
/*****************************************************************************
 * Function      : Send_Sensor_Get_Data_Info
 * Description   : ��ȡ���ݻ����ָ�룬���ݳ��ȡ�����heade-
                   r���л�����ָ�뵽��һ��
 * Input         : void  
 * Output        : None
 * Return        : ����1��ʱ��.��ʾ��ǰû�����ݣ�������
 * Others        : 
 * Record
 * 1.Date        : 20200614
 *   Author      : zhangwh
 *   Modification: Created function

*****************************************************************************/
uint8_t Send_Sensor_Get_Data_Info(void)
{
	char time_str[12];
	WT_Header header;

	if(Sensor_Buff_Pos == 0)
		return 1;
	//��һ���Ƿ��͵���ʼ���ǻ�����׵�ַ,��ʾ��һ���Ƿ��͵��°������
	//���η�����������Ӧ�ôӻ������ʼ��ַ��ʼ��¼�����Խ�pos��Ϊ0
	m_sensor_send_addr = m_sensor_save_addr; 
	m_sensor_len = Sensor_Buff_Pos;
	
	//�����л��洢��ַ
	if( m_sensor_save_addr == m_sensors_buff1)
		m_sensor_save_addr = m_sensors_buff2;
	else
		m_sensor_save_addr = m_sensors_buff1;
	Sensor_Buff_Pos = 0;
	WT_RTC_GetTime((char *)time_str);
	Set_Pkt_Header(&header, time_str, TYPE_SENSORS, m_sensor_len * 2);

	return 0;
}

extern uint8_t Check_Uart_Send_Done(UART_HandleTypeDef * huart);
//0:idle 1: send header 2: sending header 3: send data 4: sending data
static uint8_t sensors_send_st = 0;

/*****************************************************************************
 * Function      : Send_Pressure_Handle
 * Description   : �������������ݷ��ͣ�Ϊ�˲���ʱ��ȴ�?-
                   ?������״̬�����л������������͵�����
                   
 * Input         : void  
 * Output        : None
 * Return        : 
 * Others        : 
 * Record
 * 1.Date        : 20200614
 *   Author      : zhangwh
 *   Modification: Created function

*****************************************************************************/
//0��dma idle; 1:g_sai_status 2:dma_busy; 3:delay(10s) 4:send data
//typedef enum {
//	SAI_ST_IDLE = 0x0,
//	SAI_ST_START = 0x1,
//	SAI_ST_BUSY = 0x2,
//  
//	SAI_ST_DELAY = 0x3,
//	SAI_ST_SEND = 0x4,
//} E_SAI_STATUS;
//static __IO E_SAI_STATUS g_sai_status = SAI_ST_IDLE;
typedef enum {
	ADC_ST_IDLE = 0x0,
	ADC_ST_START = 0x1,
	ADC_ST_BUSY = 0x2,
	ADC_ST_DELAY = 0x3,
	ADC_ST_SEND = 0x4,
} E_ADC_STATUS;

static __IO E_ADC_STATUS g_pre_status = ADC_ST_IDLE;
static __IO E_ADC_STATUS g_sns_status = ADC_ST_IDLE;

/******************************
* ��ȡѹ����������ǰ�����ݻ��档���л�����һ����ȥ
* ��¼��ǰ��ʱ�����Ϊ��һ�����ݷ��͵�ʱ���
*******************************/
void ADC_Get_Data_Len(void)
	{
	//�����л��洢��ַ
	m_pre_send_addr = m_pre_save_addr;
	if( m_pre_save_addr == m_pressure_buff1){
		m_pre_save_addr = m_pressure_buff2;
		pre_sample_time = pre_sample_time_1;
		WT_RTC_GetTime(pre_sample_time_2);	
	}
	else{
		m_pre_save_addr = m_pressure_buff1;
		pre_sample_time = pre_sample_time_2;
		WT_RTC_GetTime(pre_sample_time_1);	
	}

  m_pressure_len = Pressure_Buff_Pos * 2;
	Pressure_Buff_Pos = 0;

	
	//�����л��洢��ַ
	m_sensor_send_addr = m_sensor_save_addr;
	if( m_sensor_save_addr == m_sensors_buff1) {
		m_sensor_save_addr = m_sensors_buff2;
		sensor_sample_time = sensor_sample_time_1;
		WT_RTC_GetTime(sensor_sample_time_2); 
	}
	else {
		sensor_sample_time = sensor_sample_time_2;
		m_sensor_save_addr = m_sensors_buff1;
		WT_RTC_GetTime(sensor_sample_time_1); 
	}
	
	m_sensor_len = Sensor_Buff_Pos * 2;
	Sensor_Buff_Pos = 0;
}
	
//ͨ�����ڷ������ݸ�PC��
uint8_t ADC_send_data_2_pc(E_ADC_STATUS curSt, uint8_t * addr, uint32_t *datalen)
{
	uint8_t * flash_addr = (uint8_t *)addr;
	static uint32_t send_bytes = 0;		//�ۼƷ��ͳ�ȥ������������Ϊflash��ƫ��
	static uint32_t uart_wait_time = 50;
	//��ȡ�ڲ�flash�ĵ�ַ
	uint32_t start_time = HAL_GetTick();
	uint32_t bytes = 0x8000;	//ÿ��ֻ����0x2000�����ݳ�ȥ
	//dma����0��ʱ�򣬿��Է�������
	if(curSt != ADC_ST_SEND){
		send_bytes = 0;
		return 0;
	}
	//�Ƿ�����total_size�����������ֵ�������ݴ洢������
	if(*datalen){
		//check if data send over!!!!!!!
		if(Check_Uart_Send_Done(send_port) != 1){
			//printf("Data didn't send OVER YET!!!!!\n");
			return 1;
		}
		if(uart_wait_time > 0){ 
			//delay some time to wait uart tx done and ready!!!!
			uart_wait_time --;
			return 2;
		}
		//���õȴ�ʱ�䣻������ѭ�����ú���60��
		uart_wait_time = 50;
		//�ж��Ƿ������һ�����ݰ�����Ҫȷ���·��͵ĳ���
		if (bytes > *datalen)
			bytes = *datalen;
		printf("Will send 0x%x([0x%x]) bytes from 0x%x!!!\r\n", bytes, *datalen, flash_addr + send_bytes);
		Send_Data_Func((uint8_t *)flash_addr + send_bytes, bytes);
		//update the flogs
		send_bytes = send_bytes + bytes;
		*datalen = *datalen - bytes;
		//�жϷ��ͽ�������send_bytes��
		if(*datalen == 0)
			send_bytes = 0;
	}
	else{
		return 4;
	}

	return 0;
}

/*****************************************************************************
 * Function      : Start_Send_Pressure_Data
 * Description   : ��ʼѹ�������������ݷ���
 * Input         : void  
 * Output        : None
 * Return        : 
 * Others        : 
 * Record
 * 1.Date        : 20200614
 *   Author      : zhangwh
 *   Modification: Created function

*****************************************************************************/
void Start_Send_Pressure_Data(void)
{
		g_pre_status = ADC_ST_START;
	return;
}

void Start_Send_Sensors_Data(void)
{


		g_sns_status = ADC_ST_START;
	return;
}

static uint32_t	Send_Delay = 0;

void WT_Pressure_Handle_Data(void)
{
	static uint32_t start_tick = 0;

	switch (g_pre_status)
	{
		case ADC_ST_IDLE:
			break;
		case ADC_ST_START:
			ADC_Get_Data_Len();
			if(m_pressure_len > 0) {
				if(Check_Uart_Send_Done(send_port) == 0)
					return;
				printf("=====SEND====PRESSURE==START========\r\n");
				if(LTE_Get_Connect_Mutex() == 0) {
					g_pre_status = ADC_ST_SEND;
					Send_Header_With_Time(TYPE_PRESSURE, m_pressure_len, pre_sample_time);
				}
			}
			else
				g_pre_status = ADC_ST_IDLE;
			break;
		case ADC_ST_SEND:
			if (m_pressure_len > 0)
				ADC_send_data_2_pc(ADC_ST_SEND, (uint8_t *)m_pre_send_addr, &m_pressure_len);
			else {
				if(Check_Uart_Send_Done(send_port) == 1) {
					printf("=====SEND==PRESSURE==DONE======\r\n");
					g_pre_status = ADC_ST_IDLE;
					//����ѹ��������������
					Send_Delay = HAL_GetTick() + 1000;	//Delay 8ms
					LTE_Release_Connect_Mutex();
					Start_Send_Sensors_Data();
				}
			}
			break;
	}
	return;
}


void WT_Sensors_Handle_Data(void)
{
	//static uint32_t delay = 10000;
	uint32_t tick = HAL_GetTick();
	switch (g_sns_status)
	{
		case ADC_ST_IDLE:
			break;
		case ADC_ST_START:
			if(Send_Delay == 0)
				return;
			if(tick <= Send_Delay){	
				break;
			}
			Send_Delay = 0;
			//ADC_Get_Data_Len();
 			if(m_sensor_len > 0){
				if(Check_Uart_Send_Done(send_port) == 0)
					return;
				if(LTE_Get_Connect_Mutex() == 0){				
					printf("#######SEND===SENSORS==START========\r\n");
					g_sns_status = ADC_ST_SEND;
					Send_Header_With_Time(TYPE_SENSORS, m_sensor_len, sensor_sample_time);
				}
			}
			else{
				g_sns_status = ADC_ST_IDLE;
			}
			break;
		case ADC_ST_SEND:
			if (m_sensor_len > 0)
				ADC_send_data_2_pc(ADC_ST_SEND, (uint8_t *)m_sensor_send_addr, &m_sensor_len);
			else{
				if(Check_Uart_Send_Done(send_port) == 1){
					LTE_Release_Connect_Mutex();
					printf("########SEND===SENSORS==DONE========\r\n");
					g_sns_status = ADC_ST_IDLE;
				}
			}
			break;
	}
	return;
}




//void Send_Pressure_Handle(void)
//{
//	switch (pressure_send_st)
//	{
//		case 10:	//׼�������ݰ�ͷ��Ϣ�����ͳ�ȥ
//			if(Send_Pressure_Get_Data_Info())
//			{
//				//pressure_send_st = 0;
//				//��ѹ�����������������ݣ��ͷ�������������������
//				sensors_send_st = 1;
//				//break;
//			}
//			pressure_send_st = 2;
//			printf("pressure_send_st:%d\r\n", pressure_send_st);
// 			Send_Header_Handle();
//						printf("pressure_send_st:%d\r\n", pressure_send_st);
//						pressure_send_st = 2;
//			break;
//		case 2:	//�ȴ����ݰ�ͷ�ķ������
//			printf("Check Send_Done!!!!!\r\n");
//			if(Check_Uart_Send_Done(send_port))
//				pressure_send_st = 3;
//			break;
//		case 3:	//��ʼ����������
//			if(Check_Uart_Send_Done(send_port))
//			{	
//				//��Ϊѹ�����ݴ�С<64k,����һ���Է��꣬�͵���һ�ξͿ�����
//				Send_Data_Func((uint8_t *)m_pre_send_addr, m_pressure_len);
//				pressure_send_st = 4;
//			}
//			break;
//		case 4: //�ȴ����ݷ��ͽ���
//			if(Check_Uart_Send_Done(send_port))
//				pressure_send_st = 0;
//			break;
//	}
//	if(pressure_send_st != 0)
//				printf("pressure_send_st 3 :%d\n", pressure_send_st);
//	return;
//}


/*****************************************************************************
 * Function      : Send_Sensors_Handle
 * Description   : �������������ݷ��ͣ�Ϊ�˲���ʱ��ȴ�?-
                   ?������״̬�����л������������͵�����
                   
 * Input         : void  
 * Output        : None
 * Return        : 
 * Others        : 
 * Record
 * 1.Date        : 20200614
 *   Author      : zhangwh
 *   Modification: Created function

*****************************************************************************/
//void Send_Sensor_Handle(void)
//{
//	switch (sensors_send_st)
//	{
//		case 1:	//׼�������ݰ�ͷ��Ϣ�����ͳ�ȥ
//			if(Send_Sensor_Get_Data_Info())  //����1,����û������
//			{
//				sensors_send_st = 0;
//				break;
//			}
//			sensors_send_st = 2;
// 			Send_Header_Handle();
//			break;
//		case 2:	//�ȴ����ݰ�ͷ�ķ������
//			if(Check_Uart_Send_Done(send_port))
//				sensors_send_st = 3;
//			break;
//		case 3:	//��ʼ����������
//			if(Check_Uart_Send_Done(send_port))
//			{	
//				//��Ϊѹ�����ݴ�С<64k,����һ���Է��꣬�͵���һ�ξͿ�����
//				Send_Data_Func((uint8_t *)m_sensor_send_addr, m_sensor_len);
//				sensors_send_st = 4;
//			}
//			break;
//		case 4: //�ȴ����ݷ��ͽ���
//			if(Check_Uart_Send_Done(send_port))
//				sensors_send_st = 0;
//			break;
//	}
//	
//	return;
//}

/*****************************************************************************
 * Function      : Sensors_Handle_Data
 * Description   : ����������1-5��DMA������
 * Input         : void  
 * Output        : None
 * Return        : 
 * Others        : 
 * Record
 * 1.Date        : 20200614
 *   Author      : zhangwh
 *   Modification: Created function

*****************************************************************************/
void Sensors_Handle_Data(void)
{
	uint8_t i = 0;
	uint16_t volsum[5] = {0,0,0,0,0};

		uint32_t tick = HAL_GetTick();
	if(data_rdy == 0)
	{
		if(Sensor_Delay == 0)
			return;
		if(tick >= Sensor_Delay){
			//Sensor�ϵ�8ms���ȶ����Դ���ADC
			start_ADC1();
			Sensor_Delay = 0;
		}
	}
	else if(data_rdy == 1){

			for(; i < 25; i += 5)
			{
				volsum[0] = volsum[0] + ADC1_Value[i + 0];
				volsum[1] = volsum[1] + ADC1_Value[i + 1];
				volsum[2] = volsum[2] + ADC1_Value[i + 2];
				volsum[3] = volsum[3] + ADC1_Value[i + 3];
				volsum[4] = volsum[4] + ADC1_Value[i + 4];
			}
			for(i = 0; i < 5; i++)
			{
				//������ADC��index����Ӧ��ͬ��sensor
				uint16_t val = (volsum[i] / 5) | (i << 12);
				//�������ݵ�������
				m_sensor_save_addr[Sensor_Buff_Pos++] = val;
				//�����ѹ�����������㷨�����ϲ�Ӧ��ʹ��
				//printf("%d  ==> ", Sensor_Buff_Pos);
				if ( i == 3)	//index 3 is battery, Voltage!!!
					Calc_Voltage(volsum[i] / 5);
				else					//Others is current
					Calc_Current(volsum[i] / 5);					
			}
			data_rdy = 0;
			Sensors_PowerOn(0x2, GPIO_PIN_RESET);
			Sensors_PowerOn(0x4, GPIO_PIN_RESET);
	}
	return;
}

void ADC_Handle_Data(void)
{
	//Pressure_Handle_Data();
	Sensors_Handle_Data();
	return;
}

void ADC_Send_Handle(void)
{
	//ѹ�������������ݺ����������������ݲ��ܻ췢
	//if(sensors_send_st == 0)
		WT_Pressure_Handle_Data();
		WT_Sensors_Handle_Data();
	//if(pressure_send_st == 0)
	//	Send_Sensor_Handle();
	return;
}


void ADC_main_while(void)
{
	start_ADC1();
	start_ADC3();
	while(1)
	{
		ADC_Handle_Data();
		HAL_Delay(500);
		start_ADC1();
		start_ADC3();

	}

}

/* USER CODE END 1 */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
