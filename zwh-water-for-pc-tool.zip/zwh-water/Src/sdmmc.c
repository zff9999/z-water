/********************************************************************************
  * File Name          : SDMMC.c
  * Description        : This file provides code for the configuration
  *                      of the SDMMC instances.
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under Ultimate Liberty license
  * SLA0044, the "License"; You may not use this file except in compliance with
  * the License. You may obtain a copy of the License at:
  *                             www.st.com/SLA0044
  *
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "sdmmc.h"

/* USER CODE BEGIN 0 */
#include "wt-common.h"
extern void EMMC_GPIO_Init(void);
	//send a reset pulse
extern void	EMMC_Reset(void);

/* USER CODE END 0 */

MMC_HandleTypeDef hmmc1;

#define USE_ONE_CHANNEL

#ifdef USE_ONE_CHANNEL
DMA_HandleTypeDef hdma_sdmmc1;
#else
DMA_HandleTypeDef hdma_sdmmc1_tx;
DMA_HandleTypeDef hdma_sdmmc1_rx;
#endif

/* SDMMC1 init function */

void MX_SDMMC1_MMC_Init(void)
{
	//WT_DEBUG("=entry==");
  hmmc1.Instance = SDMMC1;
  hmmc1.Init.ClockEdge = SDMMC_CLOCK_EDGE_RISING;
  hmmc1.Init.ClockBypass = SDMMC_CLOCK_BYPASS_DISABLE;
  hmmc1.Init.ClockPowerSave = SDMMC_CLOCK_POWER_SAVE_DISABLE;
  hmmc1.Init.BusWide = SDMMC_BUS_WIDE_1B;
  hmmc1.Init.HardwareFlowControl = SDMMC_HARDWARE_FLOW_CONTROL_DISABLE;
  hmmc1.Init.ClockDiv = 1;
  if (HAL_MMC_Init(&hmmc1) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_MMC_ConfigWideBusOperation(&hmmc1, SDMMC_BUS_WIDE_8B) != HAL_OK)
  {
    //Error_Handler();
  }

}
/***** config all of pins for SDMMC1 */
void HAL_MMC_MspInit(MMC_HandleTypeDef* mmcHandle)
{
			//WT_DEBUG("=entry==");
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  if(mmcHandle->Instance==SDMMC1)
  {
  /* USER CODE BEGIN SDMMC1_MspInit 0 */

  /* USER CODE END SDMMC1_MspInit 0 */
    /* SDMMC1 clock enable */
    __HAL_RCC_SDMMC1_CLK_ENABLE();
  
    __HAL_RCC_GPIOC_CLK_ENABLE();
    __HAL_RCC_GPIOD_CLK_ENABLE();
    __HAL_RCC_GPIOB_CLK_ENABLE();
    /**SDMMC1 GPIO Configuration    
    PC6     ------> SDMMC1_D6
    PC7     ------> SDMMC1_D7
    PC8     ------> SDMMC1_D0
    PC9     ------> SDMMC1_D1
    PC10     ------> SDMMC1_D2
    PC11     ------> SDMMC1_D3
    PC12     ------> SDMMC1_CK
    PD2     ------> SDMMC1_CMD
    PB8     ------> SDMMC1_D4
    PB9     ------> SDMMC1_D5 
    */
    GPIO_InitStruct.Pin = GPIO_PIN_6|GPIO_PIN_7|GPIO_PIN_8|GPIO_PIN_9 
                          |GPIO_PIN_10|GPIO_PIN_11|GPIO_PIN_12;
    GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Pull = GPIO_PULLUP;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_MEDIUM;
    GPIO_InitStruct.Alternate = GPIO_AF12_SDMMC1;
    HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

    GPIO_InitStruct.Pin = GPIO_PIN_12;
    GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_MEDIUM;
    GPIO_InitStruct.Alternate = GPIO_AF12_SDMMC1;
    HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);
	
    GPIO_InitStruct.Pin = GPIO_PIN_2;
    GPIO_InitStruct.Mode = GPIO_MODE_AF_OD;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_MEDIUM;
    GPIO_InitStruct.Alternate = GPIO_AF12_SDMMC1;
    HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);

    GPIO_InitStruct.Pin = GPIO_PIN_8|GPIO_PIN_9;
    GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Pull = GPIO_PULLUP;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_MEDIUM;
    GPIO_InitStruct.Alternate = GPIO_AF12_SDMMC1;
    HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

    /* SDMMC1 DMA Init */
    /* SDMMC1 Init */
#ifdef USE_ONE_CHANNEL
    hdma_sdmmc1.Instance = DMA2_Channel4;
    hdma_sdmmc1.Init.Request = DMA_REQUEST_7;
    hdma_sdmmc1.Init.Direction = DMA_PERIPH_TO_MEMORY;
    hdma_sdmmc1.Init.PeriphInc = DMA_PINC_DISABLE;
    hdma_sdmmc1.Init.MemInc = DMA_MINC_ENABLE;
    hdma_sdmmc1.Init.PeriphDataAlignment = DMA_PDATAALIGN_WORD;
    hdma_sdmmc1.Init.MemDataAlignment = DMA_MDATAALIGN_WORD;
    hdma_sdmmc1.Init.Mode = DMA_NORMAL;
    hdma_sdmmc1.Init.Priority = DMA_PRIORITY_LOW;
    if (HAL_DMA_Init(&hdma_sdmmc1) != HAL_OK)
    {
      Error_Handler();
    }

    /* Several peripheral DMA handle pointers point to the same DMA handle.
     Be aware that there is only one channel to perform all the requested DMAs. */
    /* Be sure to change transfer direction before calling
     HAL_SD_ReadBlocks_DMA or HAL_SD_WriteBlocks_DMA. */
    __HAL_LINKDMA(mmcHandle,hdmarx,hdma_sdmmc1);
    __HAL_LINKDMA(mmcHandle,hdmatx,hdma_sdmmc1);
#else
    /* SDMMC1_RX Init */
    hdma_sdmmc1_rx.Instance = DMA2_Channel4;
    hdma_sdmmc1_rx.Init.Request = DMA_REQUEST_7;
    hdma_sdmmc1_rx.Init.Direction = DMA_PERIPH_TO_MEMORY;
    hdma_sdmmc1_rx.Init.PeriphInc = DMA_PINC_DISABLE;
    hdma_sdmmc1_rx.Init.MemInc = DMA_MINC_ENABLE;
    hdma_sdmmc1_rx.Init.PeriphDataAlignment = DMA_PDATAALIGN_WORD;
    hdma_sdmmc1_rx.Init.MemDataAlignment = DMA_MDATAALIGN_WORD;
    hdma_sdmmc1_rx.Init.Mode = DMA_NORMAL;
    hdma_sdmmc1_rx.Init.Priority = DMA_PRIORITY_LOW;
    if (HAL_DMA_Init(&hdma_sdmmc1_rx) != HAL_OK)
    {
      Error_Handler();
    }

    __HAL_LINKDMA(mmcHandle,hdmarx,hdma_sdmmc1_rx);

    /* SDMMC1_TX Init */
    hdma_sdmmc1_tx.Instance = DMA2_Channel5;
    hdma_sdmmc1_tx.Init.Request = DMA_REQUEST_7;
    hdma_sdmmc1_tx.Init.Direction = DMA_MEMORY_TO_PERIPH;
    hdma_sdmmc1_tx.Init.PeriphInc = DMA_PINC_DISABLE;
    hdma_sdmmc1_tx.Init.MemInc = DMA_MINC_ENABLE;
    hdma_sdmmc1_tx.Init.PeriphDataAlignment = DMA_PDATAALIGN_WORD;
    hdma_sdmmc1_tx.Init.MemDataAlignment = DMA_MDATAALIGN_WORD;
    hdma_sdmmc1_tx.Init.Mode = DMA_NORMAL;
    hdma_sdmmc1_tx.Init.Priority = DMA_PRIORITY_LOW;
    if (HAL_DMA_Init(&hdma_sdmmc1_tx) != HAL_OK)
    {
      Error_Handler();
    }

    __HAL_LINKDMA(mmcHandle,hdmatx,hdma_sdmmc1_tx);
#endif
    /* SDMMC1 interrupt Init */
    HAL_NVIC_SetPriority(SDMMC1_IRQn, 0, 0);
    HAL_NVIC_EnableIRQ(SDMMC1_IRQn);
  /* USER CODE BEGIN SDMMC1_MspInit 1 */
	//init reset pin
	EMMC_GPIO_Init();
	//send a reset pulse
	EMMC_Reset();
  /* USER CODE END SDMMC1_MspInit 1 */
  }
}
//HAL_SD_CardInfoTypedef
void HAL_MMC_MspDeInit(MMC_HandleTypeDef* mmcHandle)
{
			//WT_DEBUG("=entry==");
  if(mmcHandle->Instance==SDMMC1)
  {
  /* USER CODE BEGIN SDMMC1_MspDeInit 0 */

  /* USER CODE END SDMMC1_MspDeInit 0 */
    /* Peripheral clock disable */
    __HAL_RCC_SDMMC1_CLK_DISABLE();
  
    /**SDMMC1 GPIO Configuration    
    PC6     ------> SDMMC1_D6
    PC7     ------> SDMMC1_D7
    PC8     ------> SDMMC1_D0
    PC9     ------> SDMMC1_D1
    PC10     ------> SDMMC1_D2
    PC11     ------> SDMMC1_D3
    PC12     ------> SDMMC1_CK
    PD2     ------> SDMMC1_CMD
    PB8     ------> SDMMC1_D4
    PB9     ------> SDMMC1_D5 
    */
    HAL_GPIO_DeInit(GPIOC, GPIO_PIN_6|GPIO_PIN_7|GPIO_PIN_8|GPIO_PIN_9 
                          |GPIO_PIN_10|GPIO_PIN_11|GPIO_PIN_12);

    HAL_GPIO_DeInit(GPIOD, GPIO_PIN_2);

    HAL_GPIO_DeInit(GPIOB, GPIO_PIN_8|GPIO_PIN_9);

    /* SDMMC1 DMA DeInit */
    HAL_DMA_DeInit(mmcHandle->hdmarx);
    HAL_DMA_DeInit(mmcHandle->hdmatx);

    /* SDMMC1 interrupt Deinit */
    HAL_NVIC_DisableIRQ(SDMMC1_IRQn);
  /* USER CODE BEGIN SDMMC1_MspDeInit 1 */

  /* USER CODE END SDMMC1_MspDeInit 1 */
  }
} 

/* USER CODE BEGIN 1 */
void MMC_To_PP(void)
{
			//WT_DEBUG("=entry==");
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* USER CODE BEGIN SDMMC1_MspInit 0 */

  /* USER CODE END SDMMC1_MspInit 0 */
    /* SDMMC1 clock enable */

    __HAL_RCC_GPIOC_CLK_ENABLE();

    /**SDMMC1 GPIO Configuration    
    PC6     ------> SDMMC1_D6
    PC7     ------> SDMMC1_D7
    PC8     ------> SDMMC1_D0
    PC9     ------> SDMMC1_D1
    PC10     ------> SDMMC1_D2
    PC11     ------> SDMMC1_D3
    PC12     ------> SDMMC1_CK
    PD2     ------> SDMMC1_CMD
    PB8     ------> SDMMC1_D4
    PB9     ------> SDMMC1_D5 
    */
    GPIO_InitStruct.Pin = GPIO_PIN_6|GPIO_PIN_7|GPIO_PIN_8|GPIO_PIN_9 
                          |GPIO_PIN_10|GPIO_PIN_11;
    GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Pull = GPIO_PULLUP;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_MEDIUM;
    GPIO_InitStruct.Alternate = GPIO_AF12_SDMMC1;
    HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

    GPIO_InitStruct.Pin = GPIO_PIN_2;
    GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_MEDIUM;
    GPIO_InitStruct.Alternate = GPIO_AF12_SDMMC1;
    HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);

    GPIO_InitStruct.Pin = GPIO_PIN_8|GPIO_PIN_9;
    GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Pull = GPIO_PULLUP;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_MEDIUM;
    GPIO_InitStruct.Alternate = GPIO_AF12_SDMMC1;
    HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);
}


/*****************************************************************************
 * Function      : MMC_DMAConfigRxTx
 * Description   : ����uart4 ��RX��DMA ��SD��TX DMAʹ��ͬһ��ͨ�����Ϳ���������
 *									���ԣ�EMMC��TX��RX����һ��DMA����������Ҫ���л�
 * Input         : MMC_HandleTypeDef * mmcHandle  
                		uint8_t bTxRx        ָ�����ͻ��ǽ���
 * Output        : None
 * Return        : 
 * Others        : 
 * Record
 * 1.Date        : 20200717
 *   Author      : zhangwh
 *   Modification: Created function
*****************************************************************************/
HAL_StatusTypeDef MMC_DMAConfigRxTx(MMC_HandleTypeDef * mmcHandle, uint8_t bTxRx)
{
	HAL_StatusTypeDef status = HAL_ERROR;
	//use 2 DMA channels , needn't to change channel

	hdma_sdmmc1.Instance = DMA2_Channel4;
	hdma_sdmmc1.Init.Request = DMA_REQUEST_7;
	
	if (bTxRx == MMC_RX)
		hdma_sdmmc1.Init.Direction = DMA_PERIPH_TO_MEMORY;
	else
		// TX ==> write data into emmc
		hdma_sdmmc1.Init.Direction = DMA_MEMORY_TO_PERIPH;
	
	hdma_sdmmc1.Init.PeriphInc = DMA_PINC_DISABLE;
	hdma_sdmmc1.Init.MemInc = DMA_MINC_ENABLE;
	hdma_sdmmc1.Init.PeriphDataAlignment = DMA_PDATAALIGN_WORD;
	hdma_sdmmc1.Init.MemDataAlignment = DMA_MDATAALIGN_WORD;
	hdma_sdmmc1.Init.Mode = DMA_NORMAL;
	hdma_sdmmc1.Init.Priority = DMA_PRIORITY_LOW;
	
	/* Stop any ongoing transfer and reset the state*/
	HAL_DMA_Abort(&hdma_sdmmc1);

	/* Deinitialize the Channel for new transfer */
	HAL_DMA_DeInit(&hdma_sdmmc1);
	
	/* Configure the DMA Channel */
	if (HAL_DMA_Init(&hdma_sdmmc1) != HAL_OK)
	{
		status = HAL_ERROR;
	}

	/* Several peripheral DMA handle pointers point to the same DMA handle.
	Be aware that there is only one channel to perform all the requested DMAs. */
	/* Be sure to change transfer direction before calling
	HAL_SD_ReadBlocks_DMA or HAL_SD_WriteBlocks_DMA. */
	__HAL_LINKDMA(mmcHandle,hdmarx,hdma_sdmmc1);
	__HAL_LINKDMA(mmcHandle,hdmatx,hdma_sdmmc1);

	/* SDMMC1 interrupt Init */
	HAL_NVIC_SetPriority(SDMMC1_IRQn, 0, 0);
	HAL_NVIC_EnableIRQ(SDMMC1_IRQn);
	
	return status;
}


//HAL_StatusTypeDef eMMC_Init(void)
//{
//	HAL_StatusTypeDef EMMC_Status;
//  hmmc1.Instance = SDMMC1;
//  hmmc1.Init.ClockEdge = SDMMC_CLOCK_EDGE_RISING;
//  hmmc1.Init.ClockBypass = SDMMC_CLOCK_BYPASS_DISABLE;
//  hmmc1.Init.ClockPowerSave = SDMMC_CLOCK_POWER_SAVE_DISABLE;
//  hmmc1.Init.BusWide = SDMMC_BUS_WIDE_4B;
//  hmmc1.Init.HardwareFlowControl = SDMMC_HARDWARE_FLOW_CONTROL_DISABLE;
//  hmmc1.Init.ClockDiv = 1;
//  if (HAL_MMC_Init(&hmmc1) != HAL_OK)
//  {
//	  return EMMC_Status;
//    //Error_Handler();
//  }
//  if (HAL_MMC_ConfigWideBusOperation(&hmmc1, SDMMC_BUS_WIDE_4B) != HAL_OK)
//  {
//	  return EMMC_Status;
//    //Error_Handler();
//  }
//	return HAL_OK;
//}

/*****************************************************************************
 * Function      : WT_EMMC_Info
 * Description   : ��ӡ��EMMC��������Ϣ
 * Input         : void  
 * Output        : None
 * Return        : 
 * Others        : 
 * Record
 * 1.Date        : 20200717
 *   Author      : zhangwh
 *   Modification: Created function

*****************************************************************************/
void WT_EMMC_Info(void)
{
	printf("==============INFO==============\r\n");
	/*!< Specifies the card Type                         */
  printf("=CardType:%d\r\n",	hmmc1.MmcCard.CardType);
	/*!< Specifies the class of the card class           */
  printf("=Class:%d\r\n",	hmmc1.MmcCard.Class);
	/*!< Specifies the Relative Card Address             */
  printf("=RelCardAdd:%d\r\n",	hmmc1.MmcCard.RelCardAdd);
	/*!< Specifies the Card Capacity in blocks           */
  printf("=BlockNbr:%d[0x%08x]\r\n",	hmmc1.MmcCard.BlockNbr, hmmc1.MmcCard.BlockNbr);
	/*!< Specifies one block size in bytes               */
  printf("=BlockSize:%d[0x%08x]\r\n",	hmmc1.MmcCard.BlockSize, hmmc1.MmcCard.BlockSize);
	/*!< Specifies the Card logical Capacity in blocks   */
  printf("=LogBlockNbr:%d[0x%08x]\r\n",	hmmc1.MmcCard.LogBlockNbr, hmmc1.MmcCard.LogBlockNbr);
	/*!< Specifies logical block size in bytes           */
  printf("=LogBlockSize:%d[0x%08x]\r\n",	hmmc1.MmcCard.LogBlockSize, hmmc1.MmcCard.LogBlockSize);
	printf("==============================\r\n");
	return;
}


#ifdef WT_EMMC
void WT_EMMC_Init(void)
{
	MX_SDMMC1_MMC_Init();
	//WT_Get_EMMC_Info();
	WT_EMMC_Info();
	return;
}
#else
void WT_EMMC_Init(void)
{
	return;
}
#endif

//void WT_Get_EMMC_Info(void)
//{
//	HAL_MMC_CardCSDTypeDef CSD;
//	HAL_MMC_CardCIDTypeDef CID;
//	void *p = &CID.ProdName1;
//	char *pd = p;
//	char name[7] = {0};
//	if (HAL_MMC_GetCardCID(&hmmc1, &CID) != HAL_OK){

//	}
//	name[0] = pd[3];
//	name[1] = pd[2];
//	name[2] = pd[1];
//	name[3] = pd[0];
//	name[4] = CID.ProdName2;
//	name[5] = CID.ProdRev;
//	//memcpy(name, p, 6);
//	printf("EMMC Card Info:\r\n");
//	printf("\bManufacturerID:0x%x\r\n", CID.ManufacturerID);
//	printf("\bOEM_AppliID:0x%x\r\n", CID.OEM_AppliID);
//	printf("\bProdName1:0x%x [0x%x] [0x%x] ProdName2:0x%x\r\n", 
//				CID.ProdName1, pd[0], pd[1], CID.ProdName2);
//	printf("\b\b===>%s\r\n", name);
//	printf("\bManufactDate:0x%x", CID.ManufactDate);

//	
//	//if (HAL_MMC_GetCardCSD(&hmmc1, &CSD) != HAL_OK)
//	{
//		//return hmmc1.hmmc1ErrorCode;
//	}
//	printf("EMMC Card Info:\r\n");
//	printf("\bDevice Size :0x%x\r\n", CSD.DeviceSize);
//	printf("\bSD structure:0x%x\r\n", CSD.CSDStruct);
//	return;
//}

/* USER CODE END 1 */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
