/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "adc.h"
#include "dma.h"
#include "fatfs.h"
#include "i2c.h"
#include "iwdg.h"
#include "rtc.h"
#include "sai.h"
#include "sdmmc.h"
#include "tim.h"
#include "usb_host.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "wt-common.h"

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
void MX_USB_HOST_Process(void);

/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
extern void Set_Pkt_Header(WT_Header * hdr_ptr, char * timestr, uint8_t MsgID, uint32_t data_Size);
extern void ADC_Handle_Data(void);
extern __IO uint8_t tim15m;
extern void ADC_Handle_Data(void);
extern void TH_Handle(void);
extern void WT_SAI_Handle_Data(void);
extern void Send_Pressure_Data(void);
extern uint8_t Check_Uart_Send_Done(UART_HandleTypeDef * huart);
static uint8_t start_send = 0;

extern int (* Send_Data_Func)(uint8_t * tx_buf, uint32_t len);
extern UART_HandleTypeDef * send_port;
extern int LTE_Send_Data(uint8_t *data ,uint32_t len);
extern void ADC_Send_Handle(void);
void start_send_data(void){
	start_send = 1;
	return;
}

void Send_Data_Handle(void)
{
	ADC_Send_Handle();

}


void Set_Send_Func_and_Port(uint8_t index)
{
	if(index == 4){
		Send_Data_Func = WT_Debug_Port_Send;
		send_port = &huart4;
	}else if(index == 1){
		Send_Data_Func = LTE_Send_Data;
		send_port = &huart1;
	}
}

void Self_Main_Loop(void)
{

	uint8_t enable_iwch = 1;
	uint8_t comm_port = 1;
	uint32_t print_delay;//HAL_GetTick() + 1000;	//Delay 8ms				

	//��ʼ��ADC
	MX_ADC1_Init();
	MX_ADC3_Init();
	//FM�ĳ�ʼ��
	WT_GPIO_Init();
	//RTC�ĳ�ʼ��
	MX_RTC_Init();


	MX_TIM1_Init();
	//��ʼ��I2C2:FM����ʪ��
	MX_I2C2_Init();
	//��ʼ��IIS��PCM
	WT_SAI_PCM_Init();
	//GPS��ʼ����У��RTCʱ��
	WT_GPS_Init();
	//ͬ��GPS����RTC����
	WT_Set_Update();
	//��ʼ��LTE��ʹ��LTE������������
	WT_LTE_Init();
	//ָ���������ݵĽӿںͶ˿�
	Set_Send_Func_and_Port(comm_port);
	//������ʱ��
	WT_Tim_start_IT();
	//����RTC�����Timer counter
	WT_Tim_Update_Cnt();
	//��ʼ��watchdog
	if(enable_iwch == 1)
		MX_IWDG_Init();
	//while��ĺ������ܹ����ռ��CPU��������״̬���л�
	//����ÿ������ģ���ܹ�ƽʹ��ϵͳ��Դ
	print_delay = HAL_GetTick() + 1000;
	while(1){
		//����ADC������
		ADC_Handle_Data();
		//����IIS�����ݣ������ʹ洢
		WT_SAI_Handle_Data();
		//��ʪ�ȴ�����
		TH_Handle();
		//��������
		Send_Data_Handle();
		//��GPS���ݴ���
		WT_GPS_Data_Handle();
		//����LTE���յ�����Ϣ
		WT_LTE_Data_Handle();
				
		if(enable_iwch == 1)
			WT_IWDG_Feed();
			if(WT_LTE_Get_Connect_status() == 0)
			//WT_IWDG_Feed();
			//else
			{
				if(print_delay < HAL_GetTick()){
					printf("No connect!!!\r\n");
					print_delay = HAL_GetTick() + 1000;
				}
			}
			
	}
}

int main_emmc_loop(void)
{
	uint32_t address = 0x100000;
	int factor = 0x10;
	printf("====>>>MEEC<<<======\n");
	WT_EMMC_Init();  
	WT_EMMC_Test(address);
	
	//init_tx_data();
	while(1){
		if(WT_EMMC_Test(address))
			factor = factor * -1;
		address = address + factor;
		if(address < 0x100000)
			factor = factor * -1;
	}
}
extern void Set_Experiment_GPS(uint16_t jinDu, uint16_t jinFen, uint16_t weiDu, uint16_t weiFen);
extern uint8_t g_StationID;
/* USER CODE END 0 */
#if 1
int main(void)
{
  /* USER CODE BEGIN 1 */
	uint8_t loop_test = 0x1; 	//1: main work 2: emmc 3: GPS test

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();
	/* Configure the system clock */
  SystemClock_Config();
  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  //MX_UART4_Init();
  MX_I2C1_Init();
  MX_I2C2_Init();
	WT_GPIO_Init();
	//���ڵĳ�ʼ��
	WT_Init_Uarts_DMA_Port();
	show_version();
	//����վ����
	//g_StationID = 31;
	WT_Init_Setting_ID(g_StationID);

	

	//����һ���̶���GPS��������վ�㡣
	//�����һ��������0�Ļ������Ƿ�����ʵ����
	/* HUNAN UNI 
	myGPS.JingDu_Du = 121;
	myGPS.JingDu_Fen = 524437;
	myGPS.WeiDu_Du = 31;
	myGPS.WeiDu_Fen = 233456;
	*/
	Set_Experiment_GPS(121, 524437, 31, 233456);

	switch (loop_test){
		case 1:
		{
			Self_Main_Loop();
			break;
		}
		case 2:
		{
			main_emmc_loop();
			break;
		}
		case 3:	//GPS TEST
		{
			WT_GPS_Test();
		}
	}
	
	while(1);
}

#else
/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)

{
  /* USER CODE BEGIN 1 */
	uint32_t address = 0x100;
	uint8_t loop_test = 0x0;
	
  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();
	
  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  //MX_UART4_Init();
  MX_I2C1_Init();
  MX_I2C2_Init();
	WT_GPIO_Init();
	//WT_GPIO_Init();
	//#ifdef WT_PCM186x

  //#endif
  //while(1)
	//  printf("====\n");
//  /*
//  MX_LPUART1_UART_Init();
//  MX_ADC1_Init();
//  MX_ADC2_Init();
//  MX_ADC3_Init();
//  MX_I2C1_Init();
//  MX_I2C2_Init();
//  MX_USART1_UART_Init();
//  MX_USART2_UART_Init();
//  MX_USART3_UART_Init();
  MX_RTC_Init();
//  MX_SAI1_Init();
//  MX_SDMMC1_MMC_Init();
  //timer for trige sensors
	if (loop_test)
		Self_Main_Loop();
	WT_Init_Uarts_DMA_Port();	
  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
	//MX_IWDG_Init();
	//HAL_IWDG_Start(&hiwdg);
	
	//while(1){
	//	printf("%d\r\n", HAL_GetTick());
	//}
//  //MX_FATFS_Init();
		//fm_reg_read_test(0x0, 0);
		//I2C_Test();
		//fm_mfg_test();
//  //MX_USB_HOST_Init();
//  	*/
  /* USER CODE BEGIN 2 */
	DGB_printf("=====1212112\r\n");
	#ifdef WT_EMMC1
		printf("====>>>MEEC<<<======\n");
		WT_EMMC_Init();  
		WT_EMMC_Test(address);
		init_tx_data();
	#endif
	//��ʼ��UART4
	WT_Init_Uarts_DMA_Port();

	//WT_Debug_Port_Text();
	
	//MX_ADC1_Init();
	//ADC_main_while();
	//HAL_Delay(1000);
	#ifdef WT_LTE
		extern void wt_lte_tcp_test(void);
		wt_lte_tcp_test();
	#endif
  //MMC_EraseTest();
	#ifdef WT_PCM186x
		uint8_t IIS_DMA = 1;
		//iis_send_data_2_pc_loop();
		//return 0;
		WT_SAI_PCM_Init();
		HAL_Delay(1000);
		iis_pcm_start_capture_and_send_out(IIS_DMA);
		return 0;
	#endif
  //MMC_Test(address);

	#ifndef WT_TH
		//TH_GPIO_Init();
	#endif
	#ifdef WT_GPS_1PPS
		WT_GPS_PMTK_Init();
	#endif
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
	MX_IWDG_Init();
	//HAL_IWDG_Start(&hiwdg);
	
  while (1)
  {
		address++;
		
			//DGB_printf("=====1212112\r\n");
    /* USER CODE END WHILE */
    //MX_USB_HOST_Process();

    /* USER CODE BEGIN 3 */
		//WT_Uart_MainLoop_Test();	  
		//MMC_Write_Test(0x200, 1);
  /* ������ݵ�д���� */
		#ifdef WT_EMMC1
			HAL_Delay(1000);
			WT_EMMC_Test(address);
			//MMC_Test(address);
			address = address + 0x1;
			//MMC_Read_Test(0x200, + 0x10; 1);
			//HAL_Delay(2000);
		#endif
		#ifndef WT_FM
		fm_reg_read_test(0x0, 0);
		//I2C_Test();
		fm_mfg_test();
		#endif
		#ifdef WT_PCM186x1
			if (address % 10 == 100000)
			{
				//pcm186x_dump_status();
				pcm_reg_test();
				Dump_IIS_Reg();
				Check_reg_val();
				if (Check_Done() == 0)
				{
					if (IIS_Stop == 1)
						dump_buff();
					IIS_Stop++;
					if (IIS_Stop == 100)
					{
						Restart_IIS(100);
						IIS_Stop = 0;
					}
				}
				Dump_Data();
			}
			if(IIS_DMA != 1)
				SAI_Receive_Test();
			else
				Save_Data();
		#endif
		#ifdef WT_TH
		I2C_Test();
		Hdc_Test();
		#endif
		HAL_Delay(100);
		#ifdef WT_EMMC1
			MMC_Read_Test(address, 1);
			HAL_Delay(300);
			MMC_DUMP();
		#endif
		//test uart4(debug port)
		//WT_Uart_MainLoop_Test();	

  }
  /* USER CODE END 3 */
}
#endif

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};

  /** Initializes the CPU, AHB and APB busses clocks 
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI|RCC_OSCILLATORTYPE_LSI
                              |RCC_OSCILLATORTYPE_HSE | RCC_OSCILLATORTYPE_LSE;
 //                             |RCC_OSCILLATORTYPE_HSE|RCC_OSCILLATORTYPE_LSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_BYPASS;
	//for MCO 32.768KHZ the clock used by FM PA8
  RCC_OscInitStruct.LSEState = RCC_LSE_BYPASS;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.LSIState = RCC_LSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 6;
  RCC_OscInitStruct.PLL.PLLN = 40;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = RCC_PLLQ_DIV2;
  RCC_OscInitStruct.PLL.PLLR = RCC_PLLR_DIV2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the CPU, AHB and APB busses clocks 
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_4) != HAL_OK)
  {
    Error_Handler();
  }
  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_RTC|RCC_PERIPHCLK_USART1
                              |RCC_PERIPHCLK_USART2|RCC_PERIPHCLK_USART3
                              |RCC_PERIPHCLK_UART4|RCC_PERIPHCLK_LPUART1
                              |RCC_PERIPHCLK_SAI1|RCC_PERIPHCLK_I2C1
                              |RCC_PERIPHCLK_I2C2|RCC_PERIPHCLK_USB
                              |RCC_PERIPHCLK_SDMMC1|RCC_PERIPHCLK_ADC;
  PeriphClkInit.Usart1ClockSelection = RCC_USART1CLKSOURCE_PCLK2;
  PeriphClkInit.Usart2ClockSelection = RCC_USART2CLKSOURCE_PCLK1;
  PeriphClkInit.Usart3ClockSelection = RCC_USART3CLKSOURCE_PCLK1;
  PeriphClkInit.Uart4ClockSelection = RCC_UART4CLKSOURCE_PCLK1;
  PeriphClkInit.Lpuart1ClockSelection = RCC_LPUART1CLKSOURCE_HSI;
  PeriphClkInit.I2c1ClockSelection = RCC_I2C1CLKSOURCE_PCLK1;
  PeriphClkInit.I2c2ClockSelection = RCC_I2C2CLKSOURCE_PCLK1;
  PeriphClkInit.Sai1ClockSelection = RCC_SAI1CLKSOURCE_PLLSAI2;
  PeriphClkInit.AdcClockSelection = RCC_ADCCLKSOURCE_PLLSAI1;
  PeriphClkInit.RTCClockSelection = RCC_RTCCLKSOURCE_LSE;
  PeriphClkInit.UsbClockSelection = RCC_USBCLKSOURCE_PLLSAI1;
  PeriphClkInit.Sdmmc1ClockSelection = RCC_SDMMC1CLKSOURCE_PLLSAI1;
  PeriphClkInit.PLLSAI2.PLLSAI2Source = RCC_PLLSOURCE_HSE;
  PeriphClkInit.PLLSAI2.PLLSAI2M = 6;
  PeriphClkInit.PLLSAI2.PLLSAI2N = 86;
  PeriphClkInit.PLLSAI2.PLLSAI2P = RCC_PLLP_DIV7;
  PeriphClkInit.PLLSAI2.PLLSAI2R = RCC_PLLR_DIV2;
  PeriphClkInit.PLLSAI2.PLLSAI2ClockOut = RCC_PLLSAI2_SAI2CLK;
  PeriphClkInit.PLLSAI1.PLLSAI1Source = RCC_PLLSOURCE_HSE;
  PeriphClkInit.PLLSAI1.PLLSAI1M = 6;
  PeriphClkInit.PLLSAI1.PLLSAI1N = 24;
  PeriphClkInit.PLLSAI1.PLLSAI1P = RCC_PLLP_DIV2;
  PeriphClkInit.PLLSAI1.PLLSAI1Q = RCC_PLLQ_DIV2;
  PeriphClkInit.PLLSAI1.PLLSAI1R = RCC_PLLR_DIV2;
  PeriphClkInit.PLLSAI1.PLLSAI1ClockOut = RCC_PLLSAI1_48M2CLK|RCC_PLLSAI1_ADC1CLK;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    Error_Handler();
  }
	//for MCO 32.768KHZ the clock used by FM PA8
  HAL_RCC_MCOConfig(RCC_MCO1, RCC_MCO1SOURCE_LSI, RCC_MCODIV_1);
  /** Configure the main internal regulator output voltage 
  */
  if (HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
	printf("!!!!!!!!!!!!!!!ERROR!!!!!!!!!!!!!!\n");
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{ 
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     tex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
