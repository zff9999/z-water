/******************************************************************************\
  ******************************************************************************
  * File Name          : wt-keyValue.c
  * Description        : ���ڴ�����ֵ�ԣ� "key1":"val1",......
  ******************************************************************************
  ******************************************************************************
\******************************************************************************/
#include <stdio.h>
#include <string.h>

/***************************************************/
//ȥ���ո�
void noSpace (char *strIn, char *strOutn){
    char *start, *end, *temp;
    temp = strIn;
    
    while (*temp == ' ') {
        temp ++;
    }
    start =temp;
    
    temp = strIn + strlen(strIn) - 1;
    
    while (*temp == ' ') {
        --temp;
    }
    end = temp;
    
    for (strIn = start; strIn <= end; ) {
        *strOutn++ = *strIn++;
    }
    
    *strOutn = '\0';
		return;
}

//
void getvalueForKey(char *keyValue, char *key, char *value){
    //
    char *p = keyValue;
    //�ж��Ƿ����key
    p = strstr(p, key);
    if (p == NULL) {
        printf("û�ж�Ӧ��key");
        
        return;

				
    }
    
    //ָ��ָ��key֮��
    p = p + strlen(key);
    noSpace(p, value);
    //��λ"="λ��
    
    p = strstr(p, "=");
    if (p == NULL) {
        printf("û��=��");
        return;
    }
    //ָ��ָ��Ⱥ�֮��
    p = p + strlen("=");
    noSpace(p, value);
    //
    p = strstr(value, "=");
    if(p != NULL){
        printf("�����=\n");
        return;
    }
    p = value;
    noSpace(p, value);
    
    
    
}


