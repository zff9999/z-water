/**
  ******************************************************************************
  * File Name          : RTC.c
  * Description        : This file provides code for the configuration
  *                      of the RTC instances.
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under Ultimate Liberty license
  * SLA0044, the "License"; You may not use this file except in compliance with
  * the License. You may obtain a copy of the License at:
  *                             www.st.com/SLA0044
  *
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "rtc.h"

/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

RTC_HandleTypeDef hrtc;

/* RTC init function */
void MX_RTC_Init(void)
{
  RTC_TimeTypeDef sTime = {0};
  RTC_DateTypeDef sDate = {0};

  /** Initialize RTC Only 
  */
  hrtc.Instance = RTC;
  hrtc.Init.HourFormat = RTC_HOURFORMAT_24;
  hrtc.Init.AsynchPrediv = 127;
  hrtc.Init.SynchPrediv = 255;
  hrtc.Init.OutPut = RTC_OUTPUT_DISABLE;
  hrtc.Init.OutPutRemap = RTC_OUTPUT_REMAP_NONE;
  hrtc.Init.OutPutPolarity = RTC_OUTPUT_POLARITY_HIGH;
  hrtc.Init.OutPutType = RTC_OUTPUT_TYPE_OPENDRAIN;
  if (HAL_RTC_Init(&hrtc) != HAL_OK)
  {
    Error_Handler();
  }
	//return;
  /* USER CODE BEGIN Check_RTC_BKUP */
    
  /* USER CODE END Check_RTC_BKUP */

  /** Initialize RTC and set the Time and Date 
  */
//  sTime.Hours = 11;
//  sTime.Minutes = 59;
//  sTime.Seconds = 20;
//	//ime.TimeFormat = 
//  sTime.DayLightSaving = RTC_DAYLIGHTSAVING_NONE;
//  sTime.StoreOperation = RTC_STOREOPERATION_RESET;
//  if (HAL_RTC_SetTime(&hrtc, &sTime, RTC_FORMAT_BIN) != HAL_OK)
//  {
//    Error_Handler();
//  }
//  sDate.WeekDay = RTC_WEEKDAY_MONDAY;
//  sDate.Month = RTC_MONTH_JANUARY;
//  sDate.Date = 0x4;
//  sDate.Year = 0x5;

//  if (HAL_RTC_SetDate(&hrtc, &sDate, RTC_FORMAT_BIN) != HAL_OK)
//  {
//    Error_Handler();
//  }

}

void HAL_RTC_MspInit(RTC_HandleTypeDef* rtcHandle)
{

  if(rtcHandle->Instance==RTC)
  {
  /* USER CODE BEGIN RTC_MspInit 0 */

  /* USER CODE END RTC_MspInit 0 */
    /* RTC clock enable */
    __HAL_RCC_RTC_ENABLE();
  /* USER CODE BEGIN RTC_MspInit 1 */

  /* USER CODE END RTC_MspInit 1 */
  }
}

void HAL_RTC_MspDeInit(RTC_HandleTypeDef* rtcHandle)
{

  if(rtcHandle->Instance==RTC)
  {
  /* USER CODE BEGIN RTC_MspDeInit 0 */

  /* USER CODE END RTC_MspDeInit 0 */
    /* Peripheral clock disable */
    __HAL_RCC_RTC_DISABLE();
  /* USER CODE BEGIN RTC_MspDeInit 1 */

  /* USER CODE END RTC_MspDeInit 1 */
  }
} 

/* USER CODE BEGIN 1 */
//ar timest[13];
void WT_RTC_GetTime(char * tmStmp)
{
	RTC_DateTypeDef sdate;
	RTC_TimeTypeDef stime;

	/* Get the RTC current Time ,must get time first*/
	HAL_RTC_GetTime(&hrtc, &stime, RTC_FORMAT_BIN);
	/* Get the RTC current Date */
	HAL_RTC_GetDate(&hrtc, &sdate, RTC_FORMAT_BIN);
	if(tmStmp != 0){
		tmStmp[0] = sdate.Year;
		tmStmp[1] = sdate.Month;
		tmStmp[2] = sdate.Date;
		tmStmp[3] = stime.Hours;
		tmStmp[4] = stime.Minutes;
		tmStmp[5] = stime.Seconds;
	
		snprintf(tmStmp, 13, "%02d%02d%02d%02d%02d%02d",
							 sdate.Year, sdate.Month, sdate.Date
							,stime.Hours, stime.Minutes, stime.Seconds);
		printf("====%s\r\n",tmStmp);
	}
	/* Display date Format : yy/mm/dd */
	printf("%02d/%02d/%02d %02d:%02d:%02d\r\n",
						2000 + sdate.Year, sdate.Month, sdate.Date
						,stime.Hours, stime.Minutes, stime.Seconds);

}

/*****************************************************************************
 * Function      : WT_Check_RTC_Update
 * Description   : ���ڼ�鵱ǰʱ���Ƿ���hour1/hour2:00:00
 * Input         : uint8_t hour1, uint8_t hour2
 * Output        : 
 * Return        : uint8_t: 1:�������㣻 0:������
 * Others        : 
 * Record
 * 1.Date        : 20200620
 *   Author      : zhangwh
 *   Modification: Created function
*****************************************************************************/
uint8_t WT_Check_RTC_Update( uint8_t hour1, uint8_t hour2)
{
	RTC_TimeTypeDef stime;

	WT_RTC_GetTime(NULL);

	/* Get the RTC current Time ,must get time first*/
	HAL_RTC_GetTime(&hrtc, &stime, RTC_FORMAT_BIN);
	if(stime.Hours == hour1 || stime.Hours == hour2)
		if(stime.Minutes == 1 && stime.Seconds < 10 )
		//if(stime.Minutes % 5 == 0 && stime.Seconds % 40 == 0)
			return 1;
	return 0;
}

//mode: 0: h & m  1: h 2: m 3: sec 4: m/s
//return 0: matched 
//			others: not matched
uint8_t WT_Check_RTC_With_HMS( uint8_t mode, uint8_t hour, uint8_t minute, uint8_t sec)
{
	RTC_TimeTypeDef stime;

	WT_RTC_GetTime(NULL);

	/* Get the RTC current Time ,must get time first*/
	HAL_RTC_GetTime(&hrtc, &stime, RTC_FORMAT_BIN);
	switch(mode){
		case 0:	//check hour and minute
			if(stime.Hours == hour && stime.Minutes == minute && stime.Seconds == sec)
				return 0;
			break;
		case 1:	//only check hour
			if(hour == 0){
				if(stime.Hours == 0)
					return 1;
				}
			else{
				if(stime.Hours % hour == 0)
					return 1;
				}
			break;
		case 2:	//only minute
			if(minute == 0){
				if(stime.Minutes == 0)
					return 1;
				}
			else {
				//printf("Minute:%d\r\n", minute);
				if(stime.Minutes % minute == 0)
					return 1;
				}
			//printf("======>Minute:%d\r\n", minute);

			break;
		case 3: //only minute
			{
			if(stime.Seconds % sec == 0)
				return 1;
			break;
			}
		case 4:
			{
				if(stime.Seconds == sec){
					if(minute == 0){
						if(stime.Minutes == 0)
							return 1;
						}
					else {
						//printf("Minute:%d\r\n", minute);
						if(stime.Minutes != 0)
							if(stime.Minutes % minute == 0)
								return 1;
						}			
					}
				break;
			}
				
		}

	return 0;
}


/* USER CODE END 1 */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
