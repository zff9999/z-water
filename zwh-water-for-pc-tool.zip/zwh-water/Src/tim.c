/**
  ******************************************************************************
  * File Name          : TIM.c
  * Description        : This file provides code for the configuration
  *                      of the TIM instances.
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under Ultimate Liberty license
  * SLA0044, the "License"; You may not use this file except in compliance with
  * the License. You may obtain a copy of the License at:
  *                             www.st.com/SLA0044
  *
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "tim.h"
#include "rtc.h"

/* USER CODE BEGIN 0 */
__IO uint32_t tim_count = 0;
__IO uint8_t tim15s = 0;
__IO uint8_t tim25ms = 0;
__IO uint8_t tim15m = 0;

void WT_Tim_Update_Cnt(void);
/* USER CODE END 0 */

TIM_HandleTypeDef htim1;

/* TIM1 init function */
//sysclock 80mHZ, TIM1 set to 40ms, 25HZ(80000000/20000/160=25HZ
void MX_TIM1_Init(void)
{
  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  htim1.Instance = TIM1;
  htim1.Init.Prescaler = 20000-1;
  htim1.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim1.Init.Period = 160-1;
  htim1.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim1.Init.RepetitionCounter = 0;
  htim1.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim1) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim1, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterOutputTrigger2 = TIM_TRGO2_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim1, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }

}

void HAL_TIM_Base_MspInit(TIM_HandleTypeDef* tim_baseHandle)
{

  if(tim_baseHandle->Instance==TIM1)
  {
  /* USER CODE BEGIN TIM1_MspInit 0 */

  /* USER CODE END TIM1_MspInit 0 */
    /* TIM1 clock enable */
    __HAL_RCC_TIM1_CLK_ENABLE();

    /* TIM1 interrupt Init */
    HAL_NVIC_SetPriority(TIM1_UP_TIM16_IRQn, 0, 0);
    HAL_NVIC_EnableIRQ(TIM1_UP_TIM16_IRQn);
  /* USER CODE BEGIN TIM1_MspInit 1 */
	
  /* USER CODE END TIM1_MspInit 1 */
  }
}

void HAL_TIM_Base_MspDeInit(TIM_HandleTypeDef* tim_baseHandle)
{

  if(tim_baseHandle->Instance==TIM1)
  {
  /* USER CODE BEGIN TIM1_MspDeInit 0 */

  /* USER CODE END TIM1_MspDeInit 0 */
    /* Peripheral clock disable */
    __HAL_RCC_TIM1_CLK_DISABLE();

    /* TIM1 interrupt Deinit */
    HAL_NVIC_DisableIRQ(TIM1_UP_TIM16_IRQn);
  /* USER CODE BEGIN TIM1_MspDeInit 1 */

  /* USER CODE END TIM1_MspDeInit 1 */
  }
} 

/* USER CODE BEGIN 1 */
void Start_Tim1_25MS(void)
{
	HAL_TIM_Base_Start_IT(&htim1);
}



//40�ļ���Ϊ1 Sec
#define TIM1S_CNT	25
//ѹ�������� 25ms һ��
//Sensors 15��һ��
#define TIM15S_CNT 	(TIM1S_CNT * 15) 				//(600)
#define TIM30M_CNT 	(TIM1S_CNT * 60 * 30) 	//ʵ��ʱ��2���ӽ���һ��SAI�����ݲɼ�
#define ADC3_CNT 		(TIM1S_CNT * 2)
//ˮ����30����
#define HYDRO_CNT(minute) 	(TIM1S_CNT * 60 * (minute))
//ѹ��������(ADC3) 40ms һ��
#define PRES_CNT(cnt) 		(cnt)

#define SEND_CNT(cnt) 		(TIM1S_CNT * 60 * (cnt))
#define SENSOR_CNT(cnt)		(TIM1S_CNT * (cnt))


extern void start_ADC1(void);
extern void start_ADC3(void);
extern void SAI_Start_Rec(void);
extern void TH_Start(void);
extern void WT_RTC_GetTime(char * str);
extern void SAI_Set_DMA_Flag(uint8_t DMA_flag);
extern void Start_Pressure(void);
extern void Start_Sensors(void);
extern void WT_GPS_Init_With_Sync_RTC();
void Start_Send_Pressure_Data(void);

//����RTC��ʱ������timer�ļ���
void WT_Tim_Update_Cnt(void){ 
	extern RTC_HandleTypeDef hrtc;
	RTC_TimeTypeDef stime;
	/* Get the RTC current Time ,must get time first*/
	HAL_RTC_GetTime(&hrtc, &stime, RTC_FORMAT_BIN);
	tim_count = (stime.Minutes * 60 + stime.Seconds) * TIM1S_CNT;
	printf("min:%d sec:%d ===>%d\r\n", stime.Minutes ,stime.Seconds, tim_count);
}

extern WT_Module_Info module_info;

__IO uint32_t HYDRO_sample = 1;
__IO uint32_t pressure_sample = 1;
__IO uint32_t sensors_sample = 1;
__IO uint32_t send_data_interval = 1;
__IO uint32_t rtc_sync_hour = 1;

void WT_Tim_init_interval_var(void){
	HYDRO_sample = HYDRO_CNT(module_info.HYDRO_sample);
	pressure_sample = PRES_CNT(module_info.pressure_sample);
	sensors_sample = SENSOR_CNT(module_info.sensors_sample);
	send_data_interval = SEND_CNT(module_info.send_data_interval);
	rtc_sync_hour = module_info.rtc_sync_time % 12;
	printf("====>HYDRO_sample: %d\r\n", HYDRO_sample);
	printf("====>pressure_sample: %d\r\n", pressure_sample);
	printf("====>sensors_sample: %d\r\n", sensors_sample);
	printf("====>send_data_interval: %d\r\n", send_data_interval);
	printf("====>rtc_sync_hour: %d\r\n", rtc_sync_hour);
}

void WT_Tim_start_IT(void){
	HAL_TIM_Base_Start_IT(&htim1);
	WT_Tim_init_interval_var();
}

void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim){
	if(htim->Instance == TIM1)
	{
 		tim_count++;
 		if(tim_count % TIM1S_CNT == 0){
			if(WT_Check_RTC_With_HMS(0, rtc_sync_hour, 12, 11) || 
					WT_Check_RTC_With_HMS(0, rtc_sync_hour + 12, 12, 11)){
			//if(WT_Check_RTC_With_HMS(4, 0, rtc_sync_hour, 0)){	
				WT_GPS_Init_With_Sync_RTC();
			}
		}

		if(tim_count != 0 && (tim_count % HYDRO_CNT(module_info.HYDRO_sample)) == 0){
			printf("START IIS\n");
			//��������
			tim_count = 0;
			SAI_Set_DMA_Flag(1);
			//��ʼ�������ݣ�//�����Ĳ�����ͣ����//רעˮ�����Ĳ���
			//return;
		}

		if((tim_count % SENSOR_CNT(15)) == 0)
		{
			Start_Sensors();
			//enable sensor 205 ADC sample
		}
		//ѹ���������ϵ���Ҫ8ms����ʱ�����ȶ����ȵ�����
		if(tim_count % PRES_CNT(1) == 0){
			Start_Pressure();
			//����while(1)��һЩ�ķ�ʱ��Ĳ��������pressure���жϲ��ܵõ�������Ӧ
			//�˴�ֱ�ӿ�ʼADC��ѹ����������������������ֱ�����жϺ����н������ݴ���
			start_ADC3();
		}
		
		if(tim_count % SEND_CNT(5) == 0){
			Start_Send_Pressure_Data();
			printf("SEND PRESS DATA: [%d]\n", HAL_GetTick());
		}
		
	}
	return;
}
/* USER CODE END 1 */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
